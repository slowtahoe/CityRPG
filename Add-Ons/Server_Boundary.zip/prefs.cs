if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	RTB_registerPref("Enabled","Boundary","$Pref::Boundary::Enabled","bool","Server_Boundary",1,0,0);
	RTB_registerPref("Message","Boundary","$Pref::Boundary::Message","string 255","Server_Boundary","<color:FF0000><font:arial bold:32>Return to the Battlefield!<font:arial bold:20>",0,0);
	RTB_registerPref("Center","Boundary","$Pref::Boundary::Center","string 12","Server_Boundary","0 0 0",0,0);
	RTB_registerPref("Type","Boundary","$Pref::Boundary::Type","list Circle 1 Box 0","Server_Boundary",1,0,0);
	RTB_registerPref("Warn Time (Sec)","Boundary","$Pref::Boundary::WarnTime","int 3 30","Server_Boundary",5,0,0);
	RTB_registerPref("Warn Radius","Boundary","$Pref::Boundary::WarnRadius","int 0 5000","Server_Boundary",1000,0,0);
	RTB_registerPref("Kill Radius","Boundary","$Pref::Boundary::KillRadius","int 0 5000","Server_Boundary",1500,0,0);
}
else
{
	$Pref::Boundary::Enabled = 1;
	$Pref::Boundary::Message = "<color:FF0000><font:arial bold:32>Return to the Battlefield!<font:arial bold:20>";
	$Pref::Boundary::Center = "0 0 0";
	$Pref::Boundary::Type = 1;
	$Pref::Boundary::WarnTime = 5;
	$Pref::Boundary::WarnRadius = 1000;
	$Pref::Boundary::KillRadius = 1500;
}

$Pref::Boundary::SafeZone = 50;