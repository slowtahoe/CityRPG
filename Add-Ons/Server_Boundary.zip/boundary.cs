package Boundary
{
	function GameConnection::spawnPlayer(%client)
	{
		%ret = Parent::spawnPlayer(%client);
		%player = %client.player;
		%player.gotLoc = false;
		%player.elap = 0;
		%client.schedule(100,BoundaryCheck);
		return %ret;
	}
};
activatePackage(Boundary);

function GameConnection::BoundaryCheck(%client)
{
	if(!$Pref::Boundary::Enabled)
		return;

	%player = %client.player;
	if(!isObject(%player) || %player.getState() $= "Dead")
		return;

	%client.schedule(100,BoundaryCheck);

	%posX = mFloor(getWord(%player.getTransform(),0));
	%posY = mFloor(getWord(%player.getTransform(),1));
	%posZ = mFloor(getWord(%player.getTransform(),2));

	if(!%player.gotLoc)
	{

		%player.startPos = %posX SPC %posY SPC %posZ;
		%player.gotLoc = true;
	}

	if(getSimTime()-%player.spawnTime > 5000)
	{
		%startPos = %player.startPos;
		%currPos = %posX SPC %posY SPC %posZ;
		%center = $Pref::Boundary::Center;
		%limit = $Pref::Boundary::WarnRadius;
		%finalLimit = $Pref::Boundary::KillRadius;
		%distA = vectorDist(%center, %currPos);
		%distB = vectorDist(%startPos, %currPos); //This is to prevent death on spawning for the idiots that try
		%distX = mAbs(getWord(%center,0) - %posX);
		%distY = mAbs(getWord(%center,1) - %posY);
		%distZ = mAbs(getWord(%center,2) - %posZ);

		if(%limit > %finalLimit)
			%finalLimit = %limit;

		if(%distB < $Pref::Boundary::SafeZone)
			return;

		if($Pref::Boundary::Type)
		{
			if(%distA > %limit & %distA < %finalLimit)
				%client.schedule(50,Warn);
			else
			{
				%player.elap = 0;
				%player.flash = 0;
			}

			if(%distA > %finalLimit)
			{
				
				%client.centerPrint(%msg @ "<br>Kill Zone!",1,0);
				%client.schedule(500,KillMe);
			}
		}
		else
		{
			if(%distX > %finalLimit || %distY > %finalLimit || %distZ > %finalLimit)
			{
				
				%client.centerPrint(%msg @ "<br>Kill Zone!",1,0);
				%client.schedule(500,KillMe);
				%kill = true;
			}

			if(!%kill && ((%distX > %limit && %distX < %finalLimit) || (%distY > %limit && %distY < %finalLimit) || (%distZ> %limit && %distZ < %finalLimit)))
				%client.schedule(50,Warn);
			else
			{
				%player.elap = 0;
				%player.flash = 0;
			}


		}

	}
}

function GameConnection::KillMe(%client)
{
	if(%client.player)
		%client.player.kill();
}

function GameConnection::ClearScr(%client)
{
	%client.centerPrint("",1,0);
}

function GameConnection::Warn(%client)
{
	%player = %client.player;
	%warnTime = $Pref::Boundary::WarnTime;
	%msg = $Pref::Boundary::Message;
	%player.elap += 0.1;
	%player.flash += 1;

	if(%player.flash >= 10) %player.flash = 0;

	if(%player.elap == mFloor(%player.elap) || %player.elap == 0.1) serverplay3d(errorSound,%player.getHackPosition());

	if(%player.elap < %warnTime)
	{
		%elap2 = %warnTime - mFloor(%player.elap);
		if(%player.flash < 5)
			%client.centerPrint(%msg @ "<br>" @ %elap2,1,0);
		else
			%client.schedule(50,ClearScr);
	}
	else
	{
		%client.centerPrint(%msg @ "<br>0",1,0);
		%client.schedule(500,KillMe);
	}
}

function serverCmdSetBoundaryCenter(%client)
{
	if(!%client.isAdmin) return;
	%player = %client.player;

	if(isObject(%player) && %player.getState() !$= "Dead")
	{
		%pos = mFloor(getWord(%player.getTransform(),0)) SPC mFloor(getWord(%player.getTransform(),1)) SPC mFloor(getWord(%player.getTransform(),2));
		serverplay3d(errorSound,%player.getHackPosition());
		messageClient(%client,'',"\c0The Boundary Center has been moved from\c5 " @ $Pref::Boundary::Center @ "\c0 to \c5" @ %pos @ "\c0.");
		$Pref::Boundary::Center = %pos;
	}
}

function serverCmdSetBoundaryAfghan(%client)
{
	if(!%client.isAdmin) return;
	%player = %client.player;

	serverplay3d(errorSound,%player.getHackPosition());
	messageClient(%client,'',"\c0The Server Boundary is now setup for the Afghanistan DM");
	$Pref::Boundary::Center = "-3 13 0";
	$Pref::Boundary::WarnRadius = 89;

	if($Pref::Boundary::KillRadius > 89)
		$Pref::Boundary::KillRadius = 89;
}