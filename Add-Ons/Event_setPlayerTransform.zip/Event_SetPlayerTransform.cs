function fxDTSBrick::setPlayerTransform(%obj,%dir,%velocityop,%client)
	{
		if(%client.lasttelbricktouched.timeout == 0)
		{
			switch (%dir)
			{	
				case 0 :
				%prot = getwords(%client.player.gettransform(),3,6);

				case 1 :
				%prot = "1 0 0 0";
				%velo = 0;

				case 2 :
				%prot = "0 0 1 1.57079";
				%velo = 1;

				case 3 :
				%prot = "0 0 1 3.14159";
				%velo = 2;

				case 4 :
				%prot = "0 0 1 -1.57079";
				%velo = 3;

				
			}

			%or = getwords(%obj.gettransform(),0,2);
			%lscale = 0.1*%obj.getdatablock().bricksizez;

			%finalsend = "0 0" SPC %lscale;
			%fr = vectoradd(%or,%finalsend);

			
			%finaltransform =  %fr SPC %prot;
			%turn =%client.player.getvelocity();
			%client.player.settransform(%finaltransform);
			if(%velocityop == 0)
			{
				%client.player.setvelocity("0 0 0");
			}
			Teleportertimeout(%obj);
		}
		else return;

	}

registerOutputEvent("fxDTSBrick","setPlayerTransform","list Player 0 North 1 East 2 South 3 West 4\tbool",1);
function Teleportertimeout(%obj)
{
	%obj.timeout = 1;
	schedule(500,0,rotsucksatcoding,%obj);
}
function rotsucksatcoding(%obj)
{
	%obj.timeout = 0;
}

package rotooverwrite
{
	function FxDTSBrick::onplayertouch(%brick,%player)
	{
			%player.client.lasttelbricktouched = %brick;
			Parent::onplayertouch(%brick,%player);
	}
};
ActivatePackage(rotooverwrite);