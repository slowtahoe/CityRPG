//ANOTHER 2Second edit... made by AndreZ...
datablock fxDTSBrickData(Brick4x4fprintData : brick2x2fPrintData)
{
	brickFile = "./4x4f_Print.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "4x4f_Print";
	iconname = "Add-Ons/Brick_4x4f_Print/4x4f_Print"
};