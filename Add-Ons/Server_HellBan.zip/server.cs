package Hellban {
	function hellbanadminannounce(%msg) {
		for (%clientIndex = 0 ; %clientIndex < ClientGroup.getCount() ; %clientIndex++) {
			%client = ClientGroup.getObject(%clientIndex);
			if (%client.isadmin) {
				MessageClient(%client, '', "<color:FFFF00>" @ %msg);
			}
		}
	}

	function servercmdhellban(%client, %target) {
		%target = findclientbyname(%target);
		%target.ishellbanned = true;
		hellbanadminannounce(%target.name SPC "was hellbanned by" SPC %client.name);
	}

	function servercmdunhellban(%client, %target) {
		%target = findclientbyname(%target);
		%target.ishellbanned = false;
		hellbanadminannounce(%target.name SPC "was unhellbanned by" SPC %client.name);
	}

	function servercmdlisthellbanned(%client) {
		if (%client.isadmin) {
			MessageClient(%client, '', "<color:FFFFFF>List of hellbanned users:");
			for (%clientIndex = 0 ; %clientIndex < ClientGroup.getCount() ; %clientIndex++) {
				%cl = ClientGroup.getObject(%clientIndex);
				if (%cl.ishellbanned) {
					MessageClient(%client, '', "<color:FFFFFF>" @ %cl.name);
				}
			}
			MessageClient(%client, '', "<color:FFFFFF>End of list");
		}
	}

	function servercmdmessagesent(%client, %msg) {
		if (%client.ishellbanned) {
			MessageClient(%client, '', "<color:606060>" @ %client.clanprefix @ "<color:FFFF00>" @ %client.name @ "<color:606060>" @ %client.clansuffix @ "<color:FFFFFF>:" SPC stripmlcontrolchars(%msg));
		} else {
			Parent::servercmdmessagesent(%client, %msg);
		}
	}
};

activatepackage(Hellban);
