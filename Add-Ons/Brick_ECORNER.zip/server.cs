//Inverted Corner Ramp Bricks - by Space Guy

datablock fxDTSBrickData (brickRAMPINVdata)
{
	brickFile = "./2x2x3rampinvCorner.blb";
	category = "Ramps";
	subCategory = "72 Degree";
	uiName = "72� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x3";
	collisionshapename = "./2x2x3rampinvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV2data)
{
	brickFile = "./2x2x5rampinvCorner.blb";
	category = "Ramps";
	subCategory = "80 Degree";
	uiName = "80� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x5";
	collisionshapename = "./2x2x5rampinvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV3data)
{
	brickFile = "./2x2x2rampinvCorner.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65 INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x2";
	collisionshapename = "./2x2x2rampInvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV4data)
{
	brickFile = "./2x2x3UPrampinvCorner.blb";
	category = "Ramps";
	subCategory = "72 Degree";
	uiName = "72 UP INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x3UP";
	collisionshapename = "./2x2x3rampUpInvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV5data)
{
	brickFile = "./2x2x5UPrampinvCorner.blb";
	category = "Ramps";
	subCategory = "80 Degree";
	uiName = "80 UP INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x5UP";
	collisionshapename = "./2x2x5rampUpInvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV6data)
{
	brickFile = "./2x2x2UPrampinvCorner.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65 UP INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/2x2x2UP";
	collisionshapename = "./2x2x2rampUpInvCorner.dts";
};

datablock fxDTSBrickData (brickRAMPINV7data)
{
	brickFile = "./4x4x1rampinvCorner.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18 INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/4x4x1";
};

datablock fxDTSBrickData (brickRAMPINV8data)
{
	brickFile = "./4x4x1UPrampinvCorner.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18 UP INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/4x4x1UP";
};

datablock fxDTSBrickData (brickRAMPINV9data)
{
	brickFile = "./3x3x1UPrampinvCorner.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25 UP INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/3x3x1UPrampinvCorner";
};

datablock fxDTSBrickData (brickRAMPINV10data)
{
	brickFile = "./3x3x1rampinvCorner.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25 INV Ramp corner";
	iconName = "Add-Ons/Brick_ECORNER/3x3x1rampinvCorner";
};

datablock fxDTSBrickData (brickRAMPINV11data)
{
	brickFile = "./2x2InvCorner.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_InvertedCorners/45 Inv Ramp";
	
	brickSizeX = 2;
	brickSizeY = 2;
	brickSizeZ = 3;
	canCoverTop = 1;
	canCoverBottom = 1;
	canCoverNorth = 1;
	canCoverSouth = 0;
	canCoverEast = 0;
	canCoverWest = 1;
	
	eastArea = 3;
	southArea = 3;
	
	orientationFix = 1;
};

datablock fxDTSBrickData (brickRAMPINV12data)
{
	brickFile = "./2x2InvUpCorner.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_InvertedCorners/-45 Inv Ramp";
	
	brickSizeX = 2;
	brickSizeY = 2;
	brickSizeZ = 3;
	canCoverTop = 1;
	canCoverBottom = 1;
	canCoverNorth = 1;
	canCoverSouth = 0;
	canCoverEast = 0;
	canCoverWest = 1;
	
	eastArea = 3;
	southArea = 3;
	
	orientationFix = 1;
};