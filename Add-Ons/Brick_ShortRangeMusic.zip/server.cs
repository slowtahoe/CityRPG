datablock AudioDescription(AudioHalfMusicLooping3d : AudioMusicLooping3d)
{
	maxDistance = 15;
	referenceDistance = 5;
};

datablock fxDtsBrickData(brickHalfMusicData : brickMusicData)
{
	uiName = "Music (Half Range)";
	musicRange = 15;
	musicDescription = AudioHalfMusicLooping3d;
};

datablock AudioDescription(AudioQuarterMusicLooping3d : AudioMusicLooping3d)
{
	maxDistance = 7.5;
	referenceDistance = 3;
};

datablock fxDtsBrickData(brickQuarterMusicData : brickMusicData)
{
	uiName = "Music (Quarter Range)";
	musicRange = 7.5;
	musicDescription = AudioQuarterMusicLooping3d;
};

exec("./Support_CustomRangeMusic.cs");