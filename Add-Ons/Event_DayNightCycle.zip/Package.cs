package Package_EventDNC
{
	function onServerDestroyed()
	{
		cancel($EventDNC_todSched);
		
		deleteVariables("$EventDNC_todSched");
		deleteVariables("$EventDNC_todSchedRun");
		deleteVariables("$EventDNC_todUpdate*");
		
		if(isObject(EventDNC_BrSimSet)) EventDNC_BrSimSet.delete();
		
		return Parent::onServerDestroyed();
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	function SERVERCMDClearEvents(%cl)
	{
		%parent = parent::serverCmdClearEvents(%cl);
		
		if(isObject(%br = %cl.wrenchBrick) && EventDNC_BrSimSet.isMember(%br))
			EventDNC_BrSimSet.remove(%br);
		
		return %parent;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//addScheduledEvent?
	
	function SERVERCMDAddEvent(%cl,%enabled,%inputID,%delay,%targetID,%targetNameID,%outputID,%param1,%param2,%param3,%param4)
	{
		%parent = parent::SERVERCMDAddEvent(%cl,%enabled,%inputID,%delay,%targetID,%targetNameID,%outputID,%param1,%param2,%param3,%param4);
		
		if(isObject(%br = %cl.wrenchBrick) && !EventDNC_BrSimSet.isMember(%br))
		{
			%EIDdawn = inputEvent_GetInputEventIdx("onDNC_Dawn");
			%EIDmidd = inputEvent_GetInputEventIdx("onDNC_MidDay");
			%EIDdusk = inputEvent_GetInputEventIdx("onDNC_Dusk");
			%EIDmidn = inputEvent_GetInputEventIdx("onDNC_MidNight");
			
			if(%inputID == %EIDdawn || %inputID == %EIDmidd || %inputID == %EIDdusk || %inputID == %EIDmidn)
				EventDNC_BrSimSet.add(%br);
		}
		
		return %parent;
	}
};
activatePackage(Package_EventDNC);