registerInputEvent("fxDTSBrick","onDNC_Dawn","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick","onDNC_MidDay","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick","onDNC_Dusk","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick","onDNC_MidNight","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");

registerInputEvent("fxDTSBrick","onDNC_CondTrue","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");
registerInputEvent("fxDTSBrick","onDNC_CondFalse","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame");

registerOutputEvent("fxDTSBrick","DNC_CondCheck","list if_Dawn 0 if_MidDay 1 if_Dusk 2 if_MidNight 3",1);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fxDTSBrick::EventDNC_EventInput(%br,%cond,%cl)
{
	$InputTarget_["Self"]   = %br;
	$InputTarget_["Player"] = %cl.player;
	$InputTarget_["Client"] = %cl;

	if($Server::LAN)
		$InputTarget_["MiniGame"] = getMiniGameFromObject(%cl);
	else
	{
		if(getMiniGameFromObject(%br) == getMiniGameFromObject(%cl))
			$InputTarget_["MiniGame"] = getMiniGameFromObject(%br);
		else
			$InputTarget_["MiniGame"] = 0;
	}

	switch$(%cond)
	{
		case "CondTrue":
			%br.processInputEvent("onDNC_CondTrue",%cl);
		case "CondFalse":
			%br.processInputEvent("onDNC_CondFalse",%cl);
		case "Dawn":
			%br.processInputEvent("onDNC_Dawn",%cl);
		case "Mid-Day":
			%br.processInputEvent("onDNC_MidDay",%cl);
		case "Dusk":
			%br.processInputEvent("onDNC_Dusk",%cl);
		case "Mid-Night":
			%br.processInputEvent("onDNC_MidNight",%cl);
	}								
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fxDTSBrick::DNC_CondCheck(%br,%condFunc,%cl)
{
	switch(%condFunc)
	{
		case 0:
		
			if($EventDNC_todUpdate["Dawn"])
				%br.EventDNC_EventInput("CondTrue",%cl);
			else
				%br.EventDNC_EventInput("CondFalse",%cl);
			
		case 1:
		
			if($EventDNC_todUpdate["Mid-Day"])
				%br.EventDNC_EventInput("CondTrue",%cl);
			else
				%br.EventDNC_EventInput("CondFalse",%cl);
		
		case 2:
		
			if($EventDNC_todUpdate["Dusk"])
				%br.EventDNC_EventInput("CondTrue",%cl);
			else
				%br.EventDNC_EventInput("CondFalse",%cl);
		
		case 3:
		
			if($EventDNC_todUpdate["Mid-Night"])
				%br.EventDNC_EventInput("CondTrue",%cl);
			else
				%br.EventDNC_EventInput("CondFalse",%cl);
	}
}