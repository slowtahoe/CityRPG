exec("Add-Ons/Event_DayNightCycle/Callbacks.cs");
exec("Add-Ons/Event_DayNightCycle/Commands.cs");
exec("Add-Ons/Event_DayNightCycle/CycleCheck.cs");
exec("Add-Ons/Event_DayNightCycle/Events.cs");
exec("Add-Ons/Event_DayNightCycle/Package.cs");

if($Pref::Server::EventDNC::SchedTick $= "") $Pref::Server::EventDNC::SchedTick = 1000; //How often to check the current time of day (33ms to 3000ms)
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if(!isObject(EventDNC_BrSimSet))
	new SimSet("EventDNC_BrSimSet"); //MissionCleanup doesn't exist yet
if(!$EventDNC_todSchedRun)
{
	$EventDNC_todSchedRun = true;
	EventDNC_RoutineCheck(); //Begin routine check automatically
}
