function EventDNC_RoutineCheck()
{
	if(isObject(DayCycle) && $EnvGuiServer::DayCycleEnabled)
	{
		%t = $Sim::Time;
		%l = Daycycle.dayLength;
		%o = Daycycle.dayOffset;
		%r = (%t + (%l * %o)) % %l;

		%tDawn = 0; //don't use %l
		%tMidD = %l * 0.25;
		%tDusk = %l * 0.5;
		%tMidN = %l * 0.75;
		
		if(%r > %tDawn) %tod = "Dawn";
		if(%r > %tMidD) %tod = "Mid-Day";
		if(%r > %tDusk) %tod = "Dusk";
		if(%r > %tMidN) %tod = "Mid-Night";
		
		//////////////////////////////////////////////////
		
		switch$(%tod)
		{
			case "Dawn":
			
				if(!$EventDNC_todUpdate["Dawn"])
				{
					$EventDNC_todUpdate["Dawn"] = true;
					$EventDNC_todUpdate["Mid-Day"] = false;
					$EventDNC_todUpdate["Dusk"] = false;
					$EventDNC_todUpdate["Mid-Night"] = false;

					%timeUpdate = true;
					EventDNC_onDawn();
				}
			
			case "Mid-Day":
			
				if(!$EventDNC_todUpdate["Mid-Day"])
				{
					$EventDNC_todUpdate["Dawn"] = false;
					$EventDNC_todUpdate["Mid-Day"] = true;
					$EventDNC_todUpdate["Dusk"] = false;
					$EventDNC_todUpdate["Mid-Night"] = false;

					%timeUpdate = true;
					EventDNC_onMidDay();
				}
				
			case "Dusk":
			
				if(!$EventDNC_todUpdate["Dusk"])
				{
					$EventDNC_todUpdate["Dawn"] = false;
					$EventDNC_todUpdate["Mid-Day"] = false;
					$EventDNC_todUpdate["Dusk"] = true;
					$EventDNC_todUpdate["Mid-Night"] = false;

					%timeUpdate = true;
					EventDNC_onDusk();
				}
			
			case "Mid-Night":
			
				if(!$EventDNC_todUpdate["Mid-Night"])
				{
					$EventDNC_todUpdate["Dawn"] = false;
					$EventDNC_todUpdate["Mid-Day"] = false;
					$EventDNC_todUpdate["Dusk"] = false;
					$EventDNC_todUpdate["Mid-Night"] = true;

					%timeUpdate = true;
					EventDNC_onMidNight();
				}
		}
		
		//////////////////////////////////////////////////
		
		if(%timeUpdate)
		{
			//Call Brick Input Events
			%ss = EventDNC_BrSimSet; //sim set should always exist for events
			%brCount = %ss.getCount();
			%refEventInp = "onDNC_" @ stripChars(%tod,"-");
			
			for(%c = 0; %c < %brCount; %c++)
			{
				%tmpBr = %ss.getObject(%c);
				%numEvents = %tmpBr.numEvents;
				
				for(%d = 0; %d < %numEvents; %d++)
				{
					%tmpEventInp = %tmpBr.eventInput[%d];
					
					if(%tmpEventInp $= %refEventInp)
					{
						//Use ".EventDNC_EventInput" rather than ".processInputevent", otherwise input event won't work (due to $InputTarget vars not being set up for event?)
						%tmpBr.EventDNC_EventInput(%tod,%tmpBr.client); //calls all relative, enabled events for brick (client defaults to brick client)
						break;
					}
				}
			}
		}
	}
		
	//////////////////////////////////////////////////
	
	if($EventDNC_todSchedRun)
	{
		%schedTick = mClamp($Pref::Server::EventDNC::SchedTick,33,3000);
		$EventDNC_todSched = schedule(%schedTick,0,EventDNC_RoutineCheck);
	}
	else
		echo("\c5> Day / Night Cycle routine check halted.");
}