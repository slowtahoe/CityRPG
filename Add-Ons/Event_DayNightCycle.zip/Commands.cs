function SERVERCMDToggleEDNC(%cl)
{
	//The day / night cycle routine check runs automatically, but this command gives you the option to toggle it
	
	if(!%cl.isSuperAdmin)
		return;

	if(!$EventDNC_todSchedRun)
	{
		$EventDNC_todSchedRun = true;
		EventDNC_RoutineCheck();
		
		echo("\c4> Day / Night Cycle event routine check RE-ENABLED.");
		messageAll(0,"\c6> Day / Night Cycle event routine check \c2RE-ENABLED.");
	}
	else
	{
		$EventDNC_todSchedRun = false;
		cancel($EventDNC_todSched);
		
		echo("\c2> Day / Night Cycle event routine check DISABLED.");
		messageAll(0,"\c6> Day / Night Cycle event routine check \c0DISABLED.");
	}
}