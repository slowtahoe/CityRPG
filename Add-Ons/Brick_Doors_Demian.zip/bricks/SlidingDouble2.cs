datablock fxDTSBrickData ( brickDoor_SlidingDouble2_OpenCWData )
{
	brickFile = "./SlidingDouble2_openCW.blb";
	uiName = "Sliding Double Door 2";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_SlidingDouble2_ClosedCWData";
	openCW = "brickDoor_SlidingDouble2_OpenCWData";
	
	closedCCW = "brickDoor_SlidingDouble2_ClosedCWData";
	openCCW = "brickDoor_SlidingDouble2_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_SlidingDouble2_OpenCCWData : brickDoor_SlidingDouble2_OpenCWData )
{
	brickFile = "./SlidingDouble2_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_SlidingDouble2_ClosedCWData : brickDoor_SlidingDouble2_OpenCWData )
{
	brickFile = "./SlidingDouble2_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/SlidingDouble2";

	isOpen = 0;
};