datablock fxDTSBrickData ( brickDoor_GlassPane_OpenCWData )
{
	brickFile = "./GlassPane_openCW.blb";
	uiName = "Glass Pane Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_GlassPane_ClosedCWData";
	openCW = "brickDoor_GlassPane_OpenCWData";
	
	closedCCW = "brickDoor_GlassPane_ClosedCWData";
	openCCW = "brickDoor_GlassPane_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_GlassPane_OpenCCWData : brickDoor_GlassPane_OpenCWData )
{
	brickFile = "./GlassPane_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_GlassPane_ClosedCWData : brickDoor_GlassPane_OpenCWData )
{
	brickFile = "./GlassPane_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/GlassPane";

	isOpen = 0;
};