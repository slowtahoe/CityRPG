datablock fxDTSBrickData ( brickDoor_SlidingDouble_OpenCWData )
{
	brickFile = "./SlidingDouble_openCW.blb";
	uiName = "Sliding Double Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_SlidingDouble_ClosedCWData";
	openCW = "brickDoor_SlidingDouble_OpenCWData";
	
	closedCCW = "brickDoor_SlidingDouble_ClosedCWData";
	openCCW = "brickDoor_SlidingDouble_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_SlidingDouble_OpenCCWData : brickDoor_SlidingDouble_OpenCWData )
{
	brickFile = "./SlidingDouble_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_SlidingDouble_ClosedCWData : brickDoor_SlidingDouble_OpenCWData )
{
	brickFile = "./SlidingDouble_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/SlidingDouble";

	isOpen = 0;
};