datablock fxDTSBrickData ( brickDoor_FrenchScreen_OpenCWData )
{
	brickFile = "./FrenchScreen_openCW.blb";
	uiName = "French Screen Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_FrenchScreen_ClosedCWData";
	openCW = "brickDoor_FrenchScreen_OpenCWData";
	
	closedCCW = "brickDoor_FrenchScreen_ClosedCWData";
	openCCW = "brickDoor_FrenchScreen_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_FrenchScreen_OpenCCWData : brickDoor_FrenchScreen_OpenCWData )
{
	brickFile = "./FrenchScreen_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_FrenchScreen_ClosedCWData : brickDoor_FrenchScreen_OpenCWData )
{
	brickFile = "./FrenchScreen_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/FrenchScreen";

	isOpen = 0;
};