datablock fxDTSBrickData ( brickDoor_LargeWindow_OpenCWData )
{
	brickFile = "./LargeWindow_openCW.blb";
	uiName = "Large Window Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_LargeWindow_ClosedCWData";
	openCW = "brickDoor_LargeWindow_OpenCWData";
	
	closedCCW = "brickDoor_LargeWindow_ClosedCWData";
	openCCW = "brickDoor_LargeWindow_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_LargeWindow_OpenCCWData : brickDoor_LargeWindow_OpenCWData )
{
	brickFile = "./LargeWindow_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_LargeWindow_ClosedCWData : brickDoor_LargeWindow_OpenCWData )
{
	brickFile = "./LargeWindow_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/LargeWindow";

	isOpen = 0;
};