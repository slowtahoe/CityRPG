datablock fxDTSBrickData ( brickDoor_3PaneGlass_OpenCWData )
{
	brickFile = "./3PaneGlass_openCW.blb";
	uiName = "3 Pane Glass Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_3PaneGlass_ClosedCWData";
	openCW = "brickDoor_3PaneGlass_OpenCWData";
	
	closedCCW = "brickDoor_3PaneGlass_ClosedCWData";
	openCCW = "brickDoor_3PaneGlass_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_3PaneGlass_OpenCCWData : brickDoor_3PaneGlass_OpenCWData )
{
	brickFile = "./3PaneGlass_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_3PaneGlass_ClosedCWData : brickDoor_3PaneGlass_OpenCWData )
{
	brickFile = "./3PaneGlass_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/3PaneGlass";

	isOpen = 0;
};