datablock fxDTSBrickData ( brickDoor_Wood_OpenCWData )
{
	brickFile = "./Wood_openCW.blb";
	uiName = "Wood Plank Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Wood_ClosedCWData";
	openCW = "brickDoor_Wood_OpenCWData";
	
	closedCCW = "brickDoor_Wood_ClosedCWData";
	openCCW = "brickDoor_Wood_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Wood_OpenCCWData : brickDoor_Wood_OpenCWData )
{
	brickFile = "./Wood_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Wood_ClosedCWData : brickDoor_Wood_OpenCWData )
{
	brickFile = "./Wood_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/Wood";

	isOpen = 0;
};