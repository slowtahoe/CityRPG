datablock fxDTSBrickData ( brickDoor_StripeWindow_OpenCWData )
{
	brickFile = "./StripeWindow_openCW.blb";
	uiName = "Stripe Window Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_StripeWindow_ClosedCWData";
	openCW = "brickDoor_StripeWindow_OpenCWData";
	
	closedCCW = "brickDoor_StripeWindow_ClosedCWData";
	openCCW = "brickDoor_StripeWindow_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_StripeWindow_OpenCCWData : brickDoor_StripeWindow_OpenCWData )
{
	brickFile = "./StripeWindow_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_StripeWindow_ClosedCWData : brickDoor_StripeWindow_OpenCWData )
{
	brickFile = "./StripeWindow_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/StripeWindow";

	isOpen = 0;
};