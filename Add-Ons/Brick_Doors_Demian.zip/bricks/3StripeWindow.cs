datablock fxDTSBrickData ( brickDoor_3StripeWindow_OpenCWData )
{
	brickFile = "./3StripeWindow_openCW.blb";
	uiName = "3 Stripe Window Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_3StripeWindow_ClosedCWData";
	openCW = "brickDoor_3StripeWindow_OpenCWData";
	
	closedCCW = "brickDoor_3StripeWindow_ClosedCWData";
	openCCW = "brickDoor_3StripeWindow_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_3StripeWindow_OpenCCWData : brickDoor_3StripeWindow_OpenCWData )
{
	brickFile = "./3StripeWindow_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_3StripeWindow_ClosedCWData : brickDoor_3StripeWindow_OpenCWData )
{
	brickFile = "./3StripeWindow_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian/bricks/3StripeWindow";

	isOpen = 0;
};