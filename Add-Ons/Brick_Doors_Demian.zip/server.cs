%error = ForceRequiredAddOn("Support_Doors");

if( %error == $Error::AddOn_NotFound )
{
	error("ERROR: Brick_Doors_Demian - required add-on Support_Doors not found");
}
else
{
	exec("./bricks/3PaneGlass.cs");
	exec("./bricks/3StripeWindow.cs");
	exec("./bricks/FrenchScreen.cs");
	exec("./bricks/GlassPane.cs");
	exec("./bricks/LargeWindow.cs");
	exec("./bricks/SlidingDouble.cs");
	exec("./bricks/SlidingDouble2.cs");
	exec("./bricks/StripeWindow.cs");
	exec("./bricks/Wood.cs");
}