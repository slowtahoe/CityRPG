datablock fxDTSBrickData(brick1x4rampData)
{
	brickFile = "./1x4ramp.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18� Ramp 1x";
	iconName = "Add-Ons/Brick_18Degree/1x4ramp";
	collisionShapeName = "./1x4ramp.dts";
};

datablock fxDTSBrickData(brick2x4rampData)
{
	brickFile = "./2x4ramp.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18� Ramp 2x";
	iconName = "Add-Ons/Brick_18Degree/2x4ramp";
	collisionShapeName = "./2x4ramp.dts";
};

datablock fxDTSBrickData(brick4x4rampData)
{
	brickFile = "./4x4ramp.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18� Ramp 4x";
	iconName = "Add-Ons/Brick_18Degree/4x4ramp";
	collisionShapeName = "./4x4ramp.dts";
};

datablock fxDTSBrickData(brick1x4rampUpData)
{
	brickFile = "./1x4rampUp.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "-18� Ramp 1x";
	iconName = "Add-Ons/Brick_18Degree/1x4rampUp";
	collisionShapeName = "./1x4rampUp.dts";
};

datablock fxDTSBrickData(brick2x4rampUpData)
{
	brickFile = "./2x4rampUp.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "-18� Ramp 2x";
	iconName = "Add-Ons/Brick_18Degree/2x4rampUp";
	collisionShapeName = "./2x4rampUp.dts";
};

datablock fxDTSBrickData(brick4x4rampCornerData)
{
	brickFile = "./4x4rampCorner.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "18� Ramp Corner";
	iconName = "Add-Ons/Brick_18Degree/4x4rampCorner";
	collisionShapeName = "./4x4rampCorner.dts";
};

datablock fxDTSBrickData(brick4x4rampUpCornerData)
{
	brickFile = "./4x4rampUpCorner.blb";
	category = "Ramps";
	subCategory = "18 Degree";
	uiName = "-18� Ramp Corner";
	iconName = "Add-Ons/Brick_18Degree/4x4rampUpCorner";
	collisionShapeName = "./4x4rampUpCorner.dts";
};