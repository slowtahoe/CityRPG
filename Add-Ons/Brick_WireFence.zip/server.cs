datablock fxDTSBrickData(Wirefence3Data)
{
	brickFile = "./Wirefence.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "Wire Fence";
	iconName = "Add-Ons/Brick_Wirefence/1x6WireFence";
};

datablock fxDTSBrickData(Wirefence2Data)
{
	brickFile = "./Wirefence2.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "Wire Fence Footless";
	iconName = "Add-Ons/Brick_Wirefence/1x6WireFence2";
};

datablock fxDTSBrickData(WirefenceSign2Data)
{
	brickFile = "./WirefenceSign2.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "Wire Fence Sign Small";
	iconName = "Add-Ons/Brick_Wirefence/1x6WireFencesignsmall";
	        hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(WirefenceSign1Data)
{
	brickFile = "./WirefenceSign1.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "Wire Fence Sign Large";
	iconName = "Add-Ons/Brick_Wirefence/1x6WireFencesignlarge";
	        hasPrint = 1;
	printAspectRatio = "1x1";
};