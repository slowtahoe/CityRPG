datablock fxDTSBrickData(brick4x4roundCornerFullData)
{
	brickFile = "./4x4roundCornerFull.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "4x4 Corner Full";
	iconName = "Add-Ons/Brick_Round_Corners/4x4roundCornerFull";
	collisionShapeName = "./4x4roundCornerFull.dts";
};

datablock fxDTSBrickData(brick4x4FroundCornerFullData)
{
	brickFile = "./4x4FroundCornerFull.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "4x4F Corner Full";
	iconName = "Add-Ons/Brick_Round_Corners/4x4FroundCornerFull";
	collisionShapeName = "./4x4FroundCornerFull.dts";
};

datablock fxDTSBrickData(brick4x4roundCornerMacaroniData)
{
	brickFile = "./4x4roundCornerMacaroni.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "4x4 Corner Macaroni";
	iconName = "Add-Ons/Brick_Round_Corners/4x4roundCornerMacaroni";
	collisionShapeName = "./4x4roundCornerMacaroni.dts";
};

datablock fxDTSBrickData(brick4x4FroundCornerMacaroniData)
{
	brickFile = "./4x4FroundCornerMacaroni.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "4x4F Corner Macaroni";
	iconName = "Add-Ons/Brick_Round_Corners/4x4FroundCornerMacaroni";
	collisionShapeName = "./4x4FroundCornerMacaroni.dts";
};

datablock fxDTSBrickData(brick2x2roundCornerMacaroniData)
{
	brickFile = "./2x2roundCornerMacaroni.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "2x2 Corner Macaroni";
	iconName = "Add-Ons/Brick_Round_Corners/2x2roundCornerMacaroni";
	collisionShapeName = "./2x2roundCornerMacaroni.dts";
};

datablock fxDTSBrickData(brick2x2FroundCornerMacaroniData)
{
	brickFile = "./2x2FroundCornerMacaroni.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "2x2F Corner Macaroni";
	iconName = "Add-Ons/Brick_Round_Corners/2x2FroundCornerMacaroni";
	collisionShapeName = "./2x2FroundCornerMacaroni.dts";
};

datablock fxDTSBrickData(brick2x2roundCornerFullData)
{
	brickFile = "./2x2roundCornerFull.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "2x2 Corner Full";
	iconName = "Add-Ons/Brick_Round_Corners/2x2roundCornerFull";
	collisionShapeName = "./2x2roundCornerFull.dts";
};


datablock fxDTSBrickData(brick2x2FroundCornerFullData)
{
	brickFile = "./2x2FroundCornerFull.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "2x2F Corner Full";
	iconName = "Add-Ons/Brick_Round_Corners/2x2FroundCornerFull";
	collisionShapeName = "./2x2FroundCornerFull.dts";
};

datablock fxDTSBrickData(brick4x4x6roundCornerWallData)
{
	brickFile = "./4x4x6roundCornerWall.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "4x4x6 Corner Wall";
	iconName = "Add-Ons/Brick_Round_Corners/4x4roundCornerWall";
	collisionShapeName = "./4x4roundCornerWall.dts";
};

datablock fxDTSBrickData(brick2x2x6roundCornerWallData)
{
	brickFile = "./2x2x6roundCornerWall.blb";
	category = "Rounds";
	subCategory = "Corners";
	uiName = "2x2x6 Corner Wall";
	iconName = "Add-Ons/Brick_Round_Corners/2x2roundCornerWall";
	collisionShapeName = "./2x2roundCornerWall.dts";
};