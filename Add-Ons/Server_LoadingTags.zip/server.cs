package Tags
{
	function ServerCmdMessageSent(%client, %message)
	{
		%oldPrefix = %client.clanPrefix;
		if(!%Client.hasSpawnedOnce)
		{
			%client.ClanPrefix = "\c7[\c1Loading\c7] " @%OldPrefix;
		}
		else
		{
			%client.ClanPrefix = "" @%oldPrefix;
		}
		parent::ServerCmdMessageSent(%client, %message);
		%client.clanPrefix = %oldPrefix;
	}
};
activatePackage(Tags);