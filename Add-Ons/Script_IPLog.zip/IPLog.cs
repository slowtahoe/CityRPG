//Constants
$logFile = "config/server/ServerLogs/IPAddresses.cs";

//Checks if log already exists, if so, load log.
if(isFile($logFile))
{
    exec($logFile);
}

//Package for automatically logging and saving IP addresses.
package IPLog
{
    function GameConnection::AutoAdminCheck(%client)
    {
       $LoggedIP[%client.BL_ID] = %client.getRawIP();
       export("$LoggedIP*", $logFile, false); 
       
       return Parent::AutoAdminCheck(%client);
    }
};
activatepackage(IPLog);