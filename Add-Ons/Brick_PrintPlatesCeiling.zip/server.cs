datablock fxDTSBrickData (brick1x1FPrintPlateCData)
{
	brickFile = "./1x1FPrintPlateC.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x1F Ceiling Print Plate";
	iconName = "Add-Ons/Brick_PrintPlatesCeiling/1x1FPrintPlateC";

	hasPrint = 1;
	printAspectRatio = "1x1f";
};

datablock fxDTSBrickData (brick1x2FPrintPlateCData)
{
	brickFile = "./1x2FPrintPlateC.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x2F Ceiling Print Plate";
	iconName = "Add-Ons/Brick_PrintPlatesCeiling/1x2FPrintPlateC";

	hasPrint = 1;
	printAspectRatio = "1x2f";
};

datablock fxDTSBrickData (brick2x2FPrintPlateCData)
{
	brickFile = "./2x2FPrintPlateC.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F Ceiling Print Plate";
	iconName = "Add-Ons/Brick_PrintPlatesCeiling/2x2FPrintPlateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};