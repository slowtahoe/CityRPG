if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
        if(!$RTB::RTBR_ServerControl_Hook)
         exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
      RTB_registerPref("Can Change Environment","Environment Control","ECP","list Host 3 SuperAdmin 2 Admin 1","Script_EnvironmentControl",1,0,1);
}
else
{
   $ECP = 1;
}

package EnvironmentControl
{
   function serverCmdEnvGui_SetVar(%client,%var,%value)
   {
      switch($ECP)
      {
         case 1:
            if(!%client.isAdmin)
            {
               return;
            }
         case 2:
            if(!%client.isSuperAdmin)
            {
               commandtoclient(%client,'MessageBoxOK',"Environment","You do not have permission to change the environment.");
               return;
            }
         case 3:
            if(%client.bl_id !$= getnumkeyid())
            {
               commandtoclient(%client,'MessageBoxOK',"Environment","You do not have permission to change the environment.");
               return;
            }
      }
      Parent::ServerCmdEnvGui_SetVar(%client,%var,%value);
   }

   function serverCmdEnvGui_RequestCurrentVars(%client)
   {
      switch($ECP)
      {
         case 1:
            if(!%client.isAdmin)
            {
               return;
            }
         case 2:
            if(!%client.isSuperAdmin)
            {
               commandtoclient(%client,'MessageBoxOK',"Environment","You do not have permission to change the environment.");
               return;
            }
         case 3:
            if(%client.bl_id !$= getnumkeyid())
            {
               commandtoclient(%client,'MessageBoxOK',"Environment","You do not have permission to change the environment.");
               return;
            }
      }
      Parent::serverCmdEnvGui_RequestCurrentVars(%client);
   }

  function serverCmdenvPer(%client,%mode,%mode2)
  {
    serverCmdEnvironmentpermission(%client,%mode,%mode2);
  }

   //Server command if you prefer them over RTB prefs
   function serverCmdEnvironmentpermission(%client, %mode, %mode2)
   {
      if(%client.bl_id == getnumkeyid())
      {
         if(%mode $= "admin")
         {
            if($ECP == 1)
               MessageClient(%client,'',"\c6Environment permission is already set to Admin");
            else
            {
               $ECP = 1;
               MessageAll('',"\c6Environment permission has been set to \c3Admin");
            }
         }
         else if(%mode $= "super" && %mode2 $= "admin")
         {
            if($ECP == 2)
               MessageClient(%client,'',"\c6Environment permission is already set to Super Admin");
            else
            {
               $ECP = 2;
               MessageAll('',"\c6Environment permission has been set to \c3Super Admin");
            }
         }
         else if(%mode $= "host")
         {
            if($ECP == 3)
               MessageClient(%client,'',"\c6Environment permission is already set to Host");
            else
            {
               $ECP = 3;
               MessageAll('',"\c6Environment permission has been set to \c3Host");
            }
         }
      }
   }
};
activatepackage(EnvironmentControl);
