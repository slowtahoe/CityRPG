datablock fxDTSBrickData(brick2x2FBookHorizData)
{
	brickFile = "./2x2FBookHoriz.blb";
	category = "Special";
	subCategory = "Education";
	uiName = "2x2f Book Horiz";
	iconName = "Add-Ons/Brick_Books/2x2FBookHoriz";
	hasPrint=1;
	printAspectRatio="2x2f";
	OrientationFix=5;
};
datablock fxDTSBrickData(brick1x2BookVertData)
{
	brickFile = "./1x2BookVert.blb";
	category = "Special";
	subCategory = "Education";
	uiName = "1x2 Book Vert";
	iconName = "Add-Ons/Brick_Books/1x2BookVert";
	hasPrint=1;
	printAspectRatio="2x2f";
	OrientationFix=2;
};
datablock fxDTSBrickData(brick2x2BookDiagData)
{
	brickFile = "./2x2BookDiag.blb";
	category = "Special";
	subCategory = "Education";
	uiName = "2x2 Book Diag R";
	iconName = "Add-Ons/Brick_Books/2x2BookDiag";
	hasPrint=1;
	printAspectRatio="2x2f";
	OrientationFix=2;
};
datablock fxDTSBrickData(brick2x2BookDiagLData)
{
	brickFile = "./2x2BookDiagL.blb";
	category = "Special";
	subCategory = "Education";
	uiName = "2x2 Book Diag L";
	iconName = "Add-Ons/Brick_Books/2x2BookDiagL";
	hasPrint=1;
	printAspectRatio="2x2f";
	OrientationFix=2;
};