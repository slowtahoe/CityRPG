//6 slot player.
datablock PlayerData(Player6SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "6 Slot Player";
	showEnergyBar = false;
	maxTools = 6;
	maxWeapons = 6;
};