//2 slot player.
datablock PlayerData(Player2SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "2 Slot Player";
	showEnergyBar = false;
	maxTools = 2;
	maxWeapons = 2;
};