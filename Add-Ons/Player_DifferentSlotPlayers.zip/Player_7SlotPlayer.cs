//7 slot player.
datablock PlayerData(Player7SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "7 Slot Player";
	showEnergyBar = false;
	maxTools = 7;
	maxWeapons = 7;
};