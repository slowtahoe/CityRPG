//4 slot player.
datablock PlayerData(Player4SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "4 Slot Player";
	showEnergyBar = false;
	maxTools = 4;
	maxWeapons = 4;
};