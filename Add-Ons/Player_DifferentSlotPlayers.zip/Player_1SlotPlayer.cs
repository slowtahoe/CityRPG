//1 slot player.
datablock PlayerData(Player1SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "1 Slot Player";
	showEnergyBar = false;
	maxTools = 1;
	maxWeapons = 1;
};