//8 slot player.
datablock PlayerData(Player8SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "8 Slot Player";
	showEnergyBar = false;
	maxTools = 8;
	maxWeapons = 8;
};