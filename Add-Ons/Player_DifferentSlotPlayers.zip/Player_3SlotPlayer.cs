//3 slot player.
datablock PlayerData(Player3SlotPlayer : PlayerStandardArmor)
{
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "3 Slot Player";
	showEnergyBar = false;
	maxTools = 3;
	maxWeapons = 3;
};