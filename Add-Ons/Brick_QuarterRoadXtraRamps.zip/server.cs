datablock fxDTSBrickData (brickQRStraightRampALongData)
{
	brickFile = "./StraightRampLong.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad Xtra Ramps";
	uiName = "Straight Ramp A Long";
	iconName = "Add-Ons/Brick_QuarterRoadXtraRamps/Straight Ramp A Long";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoadXtraRamps/StraightRampLongCol.dts";
};

datablock fxDTSBrickData (brickQRCenterRampLongData)
{
	brickFile = "./CenterRampLong.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad Xtra Ramps";
	uiName = "Middle Ramp Long";
	iconName = "Add-Ons/Brick_QuarterRoadXtraRamps/Middle Ramp Long";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoadXtraRamps/CenterRampLongCol.dts";
};

datablock fxDTSBrickData (brickQRStraightRampBLongData)
{
	brickFile = "./StraightRamp2Long.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad Xtra Ramps";
	uiName = "Straight Ramp B Long";
	iconName = "Add-Ons/Brick_QuarterRoadXtraRamps/Straight Ramp B Long";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoadXtraRamps/StraightRamp2LongCol.dts";
};

datablock fxDTSBrickData (brickQRSideWalkRampLongData)
{
	brickFile = "./SideWalkRampLong.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad Xtra Ramps";
	uiName = "Sidewalk Ramp Long";
	iconName = "Add-Ons/Brick_QuarterRoadXtraRamps/Sidewalk Ramp Long";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoadXtraRamps/SideWalkRampLongCol.dts";
};