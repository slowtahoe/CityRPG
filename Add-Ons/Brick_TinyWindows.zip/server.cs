//Colored Windows

datablock fxDTSBrickData (brick1x1x1WindowGreendata)
{
	brickFile = "./1x1x1WindowGreen.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Green Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowReddata)
{
	brickFile = "./1x1x1WindowRed.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Red Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowBluedata)
{
	brickFile = "./1x1x1WindowBlue.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Blue Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowPurpledata)
{
	brickFile = "./1x1x1WindowPurple.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Purple Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowOrangedata)
{
	brickFile = "./1x1x1WindowOrange.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Orange Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowSpecialdata)
{
	brickFile = "./1x1x1WindowSpecial.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Special Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowPinkdata)
{
	brickFile = "./1x1x1WindowPink.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Pink Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData (brick1x1x1WindowYellowdata)
{
	brickFile = "./1x1x1WindowYellow.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Yellow Window";
	iconName = "Add-Ons/Brick_TinyWindows/1x1x1window";
	orientationFix = 1;
};