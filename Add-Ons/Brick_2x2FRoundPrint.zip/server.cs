datablock fxDTSBrickData (brick2x2fRoundPrintData : brick2x2fRoundData)
{
	brickFile = "./2x2fRoundPrint.blb";
	category = "Rounds";
	subCategory = "Print";
	uiName = "2x2F Round Print";
	iconName = "Add-Ons/Brick_2x2FRoundPrint/Icon_2x2fRoundPrint";
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
	orientationFix = 3;
};