datablock fxDTSBrickData ( brickDoor_HalfPaneled_OpenCWData )
{
	brickFile = "./HalfPaneled_openCW.blb";
	uiName = "Half Paneled Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_HalfPaneled_ClosedCWData";
	openCW = "brickDoor_HalfPaneled_OpenCWData";
	
	closedCCW = "brickDoor_HalfPaneled_ClosedCWData";
	openCCW = "brickDoor_HalfPaneled_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_HalfPaneled_OpenCCWData : brickDoor_HalfPaneled_OpenCWData )
{
	brickFile = "./HalfPaneled_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_HalfPaneled_ClosedCWData : brickDoor_HalfPaneled_OpenCWData )
{
	brickFile = "./HalfPaneled_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Half/bricks/HalfPaneled";

	isOpen = 0;
};