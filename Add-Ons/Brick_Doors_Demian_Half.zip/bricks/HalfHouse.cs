datablock fxDTSBrickData ( brickDoor_HalfHouse_OpenCWData )
{
	brickFile = "./HalfHouse_openCW.blb";
	uiName = "Half House Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_HalfHouse_ClosedCWData";
	openCW = "brickDoor_HalfHouse_OpenCWData";
	
	closedCCW = "brickDoor_HalfHouse_ClosedCWData";
	openCCW = "brickDoor_HalfHouse_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_HalfHouse_OpenCCWData : brickDoor_HalfHouse_OpenCWData )
{
	brickFile = "./HalfHouse_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_HalfHouse_ClosedCWData : brickDoor_HalfHouse_OpenCWData )
{
	brickFile = "./HalfHouse_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Half/bricks/HalfHouse";

	isOpen = 0;
};