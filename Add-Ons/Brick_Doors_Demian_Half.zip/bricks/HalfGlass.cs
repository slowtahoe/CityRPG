datablock fxDTSBrickData ( brickDoor_HalfGlass_OpenCWData )
{
	brickFile = "./HalfGlass_openCW.blb";
	uiName = "Half Glass Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_HalfGlass_ClosedCWData";
	openCW = "brickDoor_HalfGlass_OpenCWData";
	
	closedCCW = "brickDoor_HalfGlass_ClosedCWData";
	openCCW = "brickDoor_HalfGlass_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_HalfGlass_OpenCCWData : brickDoor_HalfGlass_OpenCWData )
{
	brickFile = "./HalfGlass_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_HalfGlass_ClosedCWData : brickDoor_HalfGlass_OpenCWData )
{
	brickFile = "./HalfGlass_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Half/bricks/HalfGlass";

	isOpen = 0;
};