datablock fxDTSBrickData ( brickDoor_HalfPlain_OpenCWData )
{
	brickFile = "./HalfPlain_openCW.blb";
	uiName = "Half Plain Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_HalfPlain_ClosedCWData";
	openCW = "brickDoor_HalfPlain_OpenCWData";
	
	closedCCW = "brickDoor_HalfPlain_ClosedCWData";
	openCCW = "brickDoor_HalfPlain_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_HalfPlain_OpenCCWData : brickDoor_HalfPlain_OpenCWData )
{
	brickFile = "./HalfPlain_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_HalfPlain_ClosedCWData : brickDoor_HalfPlain_OpenCWData )
{
	brickFile = "./HalfPlain_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Half/bricks/HalfPlain";

	isOpen = 0;
};