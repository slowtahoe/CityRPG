%error = ForceRequiredAddOn("Support_Doors");

if( %error == $Error::AddOn_NotFound )
{
	error("ERROR: Brick_Doors_Demian_Half - required add-on Support_Doors not found");
}
else
{
	exec("./bricks/HalfGlass.cs");
	exec("./bricks/HalfHouse.cs");
	exec("./bricks/HalfPaneled.cs");
	exec("./bricks/HalfPlain.cs");
}