datablock fxDTSBrickData ( brickDoorJailOpenCW_NoFrame )
{
	brickFile = "./door_jail_openCW.blb";
	uiName = "Jail Door Frameless";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickDoorJailCW_NoFrame";
	openCW = "brickDoorJailOpenCW_NoFrame";
	
	closedCCW = "brickDoorJailCW_NoFrame";
	openCCW = "brickDoorJailOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorJailOpenCCW_NoFrame : brickDoorJailOpenCW_NoFrame )
{
	brickFile = "./door_jail_openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorJailCW_NoFrame : brickDoorJailOpenCW_NoFrame )
{
	brickFile = "./door_jail_closed.blb";
	category = "Special";
	subCategory = "Doors";

	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/Jail Door";
	
	isOpen = 0;
};