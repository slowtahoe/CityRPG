datablock fxDTSBrickData ( brickDoorGlassOpenCW_NoFrame )
{
	brickFile = "./door_glass_openCW.blb";
	uiName = "Glassiest Door Frameless";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickDoorGlassCW_NoFrame";
	openCW = "brickDoorGlassOpenCW_NoFrame";
	
	closedCCW = "brickDoorGlassCCW_NoFrame";
	openCCW = "brickDoorGlassOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorGlassCCW_NoFrame : brickDoorGlassOpenCW_NoFrame )
{
	brickFile = "./door_glass_closedCCW.blb";
	
	isOpen = 0;
};

datablock fxDTSBrickData ( brickDoorGlassOpenCCW_NoFrame : brickDoorGlassOpenCW_NoFrame )
{
	brickFile = "./door_glass_openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorGlassCW_NoFrame : brickDoorGlassOpenCW_NoFrame )
{
	brickFile = "./door_glass_closedCW.blb";
	category = "Special";
	subCategory = "Doors";

	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/Glass Door";
	
	isOpen = 0;
};