datablock fxDTSBrickData ( brickDoorJailPoleOpenCW_NoFrame )
{
	brickFile = "./door_jailPole_openCW.blb";
	uiName = "Jail Pole Door Frameless";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickDoorJailPoleCW_NoFrame";
	openCW = "brickDoorJailPoleOpenCW_NoFrame";
	
	closedCCW = "brickDoorJailPoleCW_NoFrame";
	openCCW = "brickDoorJailPoleOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorJailPoleOpenCCW_NoFrame : brickDoorJailPoleOpenCW_NoFrame )
{
	brickFile = "./door_jailPole_openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorJailPoleCW_NoFrame : brickDoorJailPoleOpenCW_NoFrame )
{
	brickFile = "./door_jailPole_closed.blb";
	category = "Special";
	subCategory = "Doors";

	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/Jail Door";
	
	isOpen = 0;
};