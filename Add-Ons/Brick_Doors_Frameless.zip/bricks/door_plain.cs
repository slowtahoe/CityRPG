datablock fxDTSBrickData ( brickDoorPlainOpenCW_NoFrame )
{
	brickFile = "./door_plain_openCW.blb";
	uiName = "Plain Door Frameless";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickDoorPlainCW_NoFrame";
	openCW = "brickDoorPlainOpenCW_NoFrame";
	
	closedCCW = "brickDoorPlainCW_NoFrame";
	openCCW = "brickDoorPlainOpenCCW_NoFrame";
};

datablock fxDTSBrickData ( brickDoorPlainOpenCCW_NoFrame : brickDoorPlainOpenCW_NoFrame )
{
	brickFile = "./door_plain_openCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoorPlainCW_NoFrame : brickDoorPlainOpenCW_NoFrame )
{
	brickFile = "./door_plain_closed.blb";
	category = "Special";
	subCategory = "Doors";

	iconName = "Add-Ons/Brick_Doors_Frameless/bricks/Plain Door";
	
	isOpen = 0;
};