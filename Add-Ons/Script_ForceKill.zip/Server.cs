//////////////////
//Force Kill//////
//////////////////
//Author: Tezuni//
//////////////////

$CanForceKill = 3;

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
    if(!$RTB::RTBR_ServerControl_Hook)
	exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");

    RTB_registerPref("Force Kill", "Admin Controls", "$CanForceKill","list Admin 1 SuperAdmin 2 Host 3","Script_ForceKill", 0, 0, 1);
}

function servercmdKill(%client,%Player)
{
	%Status = %client.isSuperAdmin + %client.isAdmin;
	%player = findClientByName(%player);

	if(findLocalClient() == %client || %client.bl_id == getNumKeyID() || !%client)
	{
		%Status = 3;
	}

	if(%Status >= $CanForceKill)
	{
        	if(!isObject(%player))
        		return messageClient(%client, '', "\c6Player not found.");

		if(!isObject(%player.player))
			return messageClient(%client,"","\c3"@ %player.name @" \c6is already dead.");
    
        	%player.player.kill("suicide");
        	return messageClient(%client, '', '\c2%1\c6 is now dead.', %player.name);	
	}
	
	else
	{
	    commandToClient(%client, 'centerPrint', "\c0/Kill \c6is not available to you at this time.", 4);
	}
}