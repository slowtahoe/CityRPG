%error = ForceRequiredAddOn("Support_Doors");

if( %error == $Error::AddOn_NotFound )
{
	error("ERROR: Brick_Doors_Demian_Arched - required add-on Support_Doors not found");
}
else
{
	exec("./bricks/ArchFrenchScreen.cs");
	exec("./bricks/ArchFrenchScreenCCW.cs");
}