datablock fxDTSBrickData ( brickDoor_ArchFrenchScreen_OpenCCWData )
{
	brickFile = "./ArchFrenchScreen_openCCW.blb";
	uiName = "Arched French Screen CCW";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_ArchFrenchScreen_ClosedCCWData";
	openCW = "brickDoor_ArchFrenchScreen_OpenCCWData";
	
	closedCCW = "brickDoor_ArchFrenchScreen_ClosedCCWData";
	openCCW = "brickDoor_ArchFrenchScreen_OpenCCWData";
};

//Default state
//Without a second brick CCW toggled doors would load in CW closed position which looks awful, though the orientation is fixed on first door toggle.
datablock fxDTSBrickData ( brickDoor_ArchFrenchScreen_ClosedCCWData : brickDoor_ArchFrenchScreen_OpenCCWData )
{
	brickFile = "./ArchFrenchScreen_closedCCW.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Arched/bricks/ArchFrenchScreen";

	isOpen = 0;
};