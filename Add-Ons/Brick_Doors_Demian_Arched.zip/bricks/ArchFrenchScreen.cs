datablock fxDTSBrickData ( brickDoor_ArchFrenchScreen_OpenCWData )
{
	brickFile = "./ArchFrenchScreen_openCW.blb";
	uiName = "Arched French Screen";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_ArchFrenchScreen_ClosedCWData";
	openCW = "brickDoor_ArchFrenchScreen_OpenCWData";
	
	closedCCW = "brickDoor_ArchFrenchScreen_ClosedCWData";
	openCCW = "brickDoor_ArchFrenchScreen_OpenCWData";
};

//Default state
datablock fxDTSBrickData ( brickDoor_ArchFrenchScreen_ClosedCWData : brickDoor_ArchFrenchScreen_OpenCWData )
{
	brickFile = "./ArchFrenchScreen_closedCW.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Arched/bricks/ArchFrenchScreen";

	isOpen = 0;
};