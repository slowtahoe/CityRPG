datablock ItemData(yellowKeyItem : redKeyItem)
{
   shapeFile = "Add-Ons/Item_Key/keyB.dts";
   uiName = "Key Yellow";
   colorShiftColor = "1.0 1.0 0.0 1.0";
   iconName = "Add-Ons/Item_Key/Icon_KeyB";
   image = yellowKeyImage;
};

datablock ShapeBaseImageData(yellowKeyImage : redKeyImage)
{
   shapeFile = "Add-Ons/Item_Key/keyB.dts";
   colorShiftColor = yellowKeyItem.colorShiftColor;
};

function yellowKeyImage::onPreFire(%this, %obj, %slot)
{
	redKeyImage::onPreFire(%this, %obj, %slot);
}

function yellowKeyImage::onStopFire(%this, %obj, %slot)
{	
	redKeyImage::onStopFire(%this, %obj, %slot);
}

function yellowKeyImage::onFire(%this, %player, %slot)
{
   redKeyImage::onFire(%this, %player, %slot);
}

function yellowKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal)
{
   redKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal);
}