datablock fxDTSBrickData(brick2xCubePrintData)
{
	brickFile = "./2xCubePrint.blb";
	category = "Bricks";
	subCategory = "Cube Prints";
	uiName = "2x Cube Print";
	iconName = "Add-Ons/Brick_PrintCubes/2xCubePrint";
	
        hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick4xCubePrintData)
{
	brickFile = "./4xCubePrint.blb";
	category = "Bricks";
	subCategory = "Cube Prints";
	uiName = "4x Cube Print";
	iconName = "Add-Ons/Brick_PrintCubes/4xCubePrint";
	
        hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick6xCubePrintData)
{
	brickFile = "./6xCubePrint.blb";
	category = "Bricks";
	subCategory = "Cube Prints";
	uiName = "6x Cube Print";
	iconName = "Add-Ons/Brick_PrintCubes/6xCubePrint";
	
        hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick8xCubePrintData)
{
	brickFile = "./8xCubePrint.blb";
	category = "Bricks";
	subCategory = "Cube Prints";
	uiName = "8x Cube Print";
	iconName = "Add-Ons/Brick_PrintCubes/8xCubePrint";
	
        hasPrint = 1;
	printAspectRatio = "2x2f";
};
