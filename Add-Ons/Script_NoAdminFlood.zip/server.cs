package no_admin_flood
{
	function serverCmdMessageSent( %cl, %msg )
	{
		prevent_admin_flood( %cl );
		parent::serverCmdMessageSent( %cl, %msg );
	}

	function serverCmdTeamMessageSent( %cl, %msg )
	{
		prevent_admin_flood( %cl );
		parent::serverCmdTeamMessageSent( %cl, %msg );
	}

	function spamAlert( %cl )
	{
		if ( %cl.isAdmin || %cl.isSuperAdmin )
		{
			return false;
		}

		return parent::spamAlert( %cl );
	}
};

function prevent_admin_flood( %cl )
{
	if ( %cl.isAdmin || %cl.isSuperAdmin )
	{
		%cl.lastChatText = "";
		%cl.lastChatTime = "";

		%cl.spamMessageCount = "";
		%cl.spamProtectStart = "";

		%cl.isSpamming = false;
	}
}