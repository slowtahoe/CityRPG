function buildIconJSON() {
  %allowed = JettisonArray();
  %restricted = JettisonArray();
  %file = findFirstFile("Add-Ons/System_BlocklandGlass/image/icon/*");
  while(%file !$= "") {
    %fn = getSubStr(%file, 41, strlen(%file)-45);
    if(strpos(%fn, "user_") == 0) {
      %allowed.push("string", %fn);
    } else {
      %restricted.push("string", %fn);
    }
    %file = findNextFile("Add-Ons/System_BlocklandGlass/image/icon/*");
  }
  JettisonWriteFile("Add-Ons/System_BlocklandGlass/dev/allow.json", "object", %allowed);
  JettisonWriteFile("Add-Ons/System_BlocklandGlass/dev/restrict.json", "object", %restricted);
}
