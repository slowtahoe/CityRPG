function Glass::loadDevMode() {
  Glass.debug = true;
  Glass.version = "3.2.0-indev";
  Glass.netAddress = "test.blocklandglass.com";
}
