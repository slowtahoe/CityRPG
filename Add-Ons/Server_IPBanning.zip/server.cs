// Pecon7
// 12/30/12
// IP ban script. Ban players by their IP so they cannot rejoin from a different ID.

if(!isfile("config/server/IPBanList.txt"))
{
	%file = new fileobject();
	%file.openforwrite("config/server/IPBanList.txt");
	%file.close();
	%file.delete();
}

package IPBanning
{
	function GameConnection::AutoAdminCheck(%this)
	{
		if(checkIfIPIsBanned(%this.getRawIP()))
			BanBLID(%this.BL_ID, -1, "Your IP address" SPC %this.getRawIP() SPC "is banned from this server.");
		else
			parent::AutoAdminCheck(%this);
	}
};
activatePackage(IPBanning);

function checkIfIPIsBanned(%IP)
{
	%file = new fileobject();
	%file.openforread("config/server/IPBanList.txt");
	
	while(!%file.isEOF())
	{
		%line = %file.readLine();
		
		if(%line $= %IP)
		{
			%file.close();
			%file.delete();
			return true;
		}
	}
	
	%file.close();
	%file.delete();
	
	return false;
}

// function serverCMDUnBanIP(%client, %IP)
// {
	// if(!%client.issuperadmin)
	// {
		// %client.chatmessage("Only super admins can do this.");
		// return;
	// }
	
	// %ip = trim(%ip);
	
	// %loop = 1;
	// while(!$BannedIP[%loop] $= "")
	// {
		// if(%IP $= $BannedIP[%loop])
		// {
			// $BannedIP[%loop] = 1;
			// %client.chatmessage("Removed" SPC %IP);
			// if(isobject(RTB_Hosting))
				// RTB_Hosting.addCustomStreamEvent(%client.name SPC "(BL_ID:" @ %client.BL_ID @ ") removed IP:" SPC %IP SPC "from the banned IP list.", "admin", "info", "");
			// return;
		// }
		// else
			// %loop++;
	// }
	
	
	
	// %client.chatmessage("That IP is not banned!");
// }

// Just delete them manually...

function serverCMDBanIP(%client, %IP)
{
	if(!%client.issuperadmin)
	{
		%client.chatmessage("Only super admins can do this.");
		return;
	}
	
	%ip = stripChars(%ip, "*;!@#$%^&*()-_+='/?><,`~\|");
	%ip = trim(%ip);
	
	if(!strlen(%ip) > 6)
	{
		%client.chatmessage("Invalid IP address.");
		return;
	}
	
	if(isobject(RTB_Hosting))
		RTB_Hosting.addCustomStreamEvent(%client.name SPC "(BL_ID:" @ %client.BL_ID @ ") banned IP:" SPC %IP, "admin", "info", "");
	
	
	
	%client.chatmessage("Banned IP" SPC %IP);
	
	%file = new fileobject();
	%file.openforappend("config/server/IPBanList.txt");
	%file.writeline(%IP);
	%file.close();
	%file.delete();
	
	
}

function serverCmdIPBan(%client, %name)
{
	if(!%client.issuperadmin)
	{
		%client.chatmessage("Only super admins can do this.");
		return;
	}

	if(!isobject(%target = findclientbyname(%name)) || %name $= "")
	{
		if(!isobject(%target = findclientbyBL_ID(%name)) || %name $= "")
		{
			%client.chatmessage("Invalid name or BL_ID.");
			return;
		}
	}
	
	%ip = %target.getRawIP();
	
	if(isobject(RTB_Hosting))
		RTB_Hosting.addCustomStreamEvent(%client.name SPC "(BL_ID:" @ %client.BL_ID @ ") banned IP:" SPC %ip SPC "Who was known as" SPC %target.name SPC "(BL_ID:" @ %target.BL_ID @ ")", "admin", "info", "");
	
	%client.chatmessage("IP banned" SPC %target.name SPC "(" @ %ip @ ")");
	
	
	%file = new fileobject();
	%file.openforappend("config/server/IPBanList.txt");
	%file.writeline(%IP);
	%file.close();
	%file.delete();
	
	
	BanBLID(%target.BL_ID, -1, "Your IP address" SPC %ip SPC "is banned from this server.");
}

function servercmdCheckIP(%client, %name)
{
	if(!%client.issuperadmin)
		return;
		
	if(!isobject(%target = findclientbyname(%name)))
		if(!isobject(%target = findclientbyBL_ID(%name)))
			return;
		
	messageClient(%client, '', %target.name @ "'s IP is" SPC %target.getrawIP());
}