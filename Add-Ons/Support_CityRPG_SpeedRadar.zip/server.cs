%error = ForceRequiredAddOn("GameMode_CityRPG4");
if(%error == $Error::AddOn_NotFound)
{
  error("ERROR: Support_CityRPG_SpeedRadar - required add-on GameMode_CityRPG4 not found");
  return;
}

%error = ForceRequiredAddOn("Item_SpeedRadar");
if(%error == $Error::AddOn_NotFound)
{
  error("ERROR: Support_CityRPG_SpeedRadar - required add-on Item_SpeedRadar not found");
  return;
}

exec("./Support_CityRPG_SpeedRadar.cs");
