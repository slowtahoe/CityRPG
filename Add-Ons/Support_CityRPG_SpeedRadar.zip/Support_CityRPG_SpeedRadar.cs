// Prefs
RTB_registerPref("Speed Limit", "CityRPG Speeding|Speeding", "$Pref::Server::City::SpeedLimit", "int 0 10000", "Support_CityRPG_SpeedRadar", 50, 0, 0);

registerPreferenceAddon("Support_CityRPG_SpeedRadar", "CityRPG Speeding", "small_car");

if($Pref::Server::City::SpeedLimit $= "")
{
  $Pref::Server::City::SpeedLimit = 50;
}

// Config changes
$CityRPG::prices::weapon::name[$CityRPG::guns] = "SpeedRadarItem";
$CityRPG::prices::weapon::price[$CityRPG::guns] = 25;
$CityRPG::prices::weapon::mineral[$CityRPG::guns++] = 1;

package CityRPG_SpeedRadar
{
  function SpeedRadarProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
  {
  	if(%col.getClassName() $= "WheeledVehicle" || %col.getClassName() $= "FlyingVehicle" || %col.getClassName() $= "AiPlayer")
  	{
  		%speed = vectorLen(%col.getvelocity());
      %owner = %col.getControllingClient();

  		if(isObject(%owner) && cityrpgdata.getdata(%owner.bl_id).valuedemerits < 200 && mFloatLength(%speed * 2,0) > $Pref::Server::City::SpeedLimit)
      {
        commandToClient(%owner, 'centerPrint', "\c6You have committed a crime. [\c3Speeding\c6]", 5);
        City_AddDemerits(%owner.bl_id, 200);
      }
  	}

    Parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
  }
};

deactivatePackage("CityRPG_SpeedRadar");
activatePackage("CityRPG_SpeedRadar");
