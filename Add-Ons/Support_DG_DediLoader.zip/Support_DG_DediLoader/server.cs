// Name	::	Instant Dedicated Loader
// ================
// Made by	::	Dglider
// Date	::	02/15/14
// Info	::	Runs kaphost autosaver and loads the first time a client joins the game.
// ================
package DG_Dediload
{
function gameConnection::startLoad(%client)
	{
		Parent::startLoad(%client);
		//loadfile
		if(!$DG_DSLLOADED)
		{
			DG_Dediload();
			exec("Add-Ons/Support_DG_Dediloader/kaphost_autosave.cs");
			$DG_DSLLOADED=1;
		}
	}
};
activatepackage(DG_Dediload);

// Command to quick load the file
function ServerCmdDG_DediLoad(%client, %name0, %name1, %name2, %name3, %name4)
{
	// Protect!
	if (%client.bl_id !$= getNumKeyId())
		return;
	DG_dediLoad();
}

// Loads a file from the server
function DG_dediLoad()
{
	// Load
	serverDirectSaveFileLoad("saves/autosave/auto0.bls",3,"",1);
}