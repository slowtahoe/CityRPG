$kaphost::AS::dir = "saves/autosave";

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
    if(!$RTB::RTBR_ServerControl_Hook)
	exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");

    RTB_registerPref("Interval", "Autosaver", "$kaphost::AS::interval", "int 0 180", "Server_AutoSaver", 5, 0, 0);
    RTB_registerPref("Announce", "Autosaver", "$kaphost::AS::announce", "bool", "Server_AutoSaver", 1, 0, 0);
}
else
{
    $kaphost::AS::announce = false;
    $kaphost::AS::interval = 5;
}

function kaphost_AS1_begin()
{
    deleteVariables("$kaphost::AS_groups::group*");

    cancel($kaphost_AS_schedule);

    if($kaphost::AS::announce)
	messageAll('', "\c5Autosaving...");

    $time_beg = getSimTime();

    %dir = $kaphost::AS::dir;
    $kaphost::AS_groups::group_count = 0;
    $kaphost::AS_groups::cur_group = 0;
    $kaphost::AS_groups::brick_count = 0;

    for(%i = 0; %i < mainBrickGroup.getCount(); %i++)
    {
	%g = mainBrickGroup.getObject(%i);
	%b = %g.getCount();
	if(%b > 0)
	{
	    %g.kaphost_AS_stop = %b;
	    $kaphost::AS_groups::group[$kaphost::AS_groups::group_count] = %g;
	    $kaphost::AS_groups::group_count++;
	}
    }

    $kaphost::AS::FO = %f = new FileObject();
    %f.openForWrite(%dir @"/TEMP1.bls");

    if(isObject($kaphost::AS_groups::group[0]))
	kaphost_AS1_nextGroup(%f);
}

function kaphost_AS1_nextGroup(%f)
{
    if($kaphost::AS_groups::cur_group == $kaphost::AS_groups::group_count)
	return kaphost_AS1_end(%f);

    %g = $kaphost::AS_groups::group[$kaphost::AS_groups::cur_group];
    $kaphost::AS_groups::cur_group++;
    kaphost_AS1_nextBrick(%f, %g, 0);
}

function kaphost_AS1_nextBrick(%f, %g, %c)
{
    if(%c >= %g.getCount())
	return kaphost_AS1_nextGroup(%f);

    %f.writeLine(%g.getObject(%c).getID());

    $kaphost::AS_groups::brick_count += 1;

    schedule(0, 0, kaphost_AS1_nextBrick, %f, %g, %c+1);
}

function kaphost_AS1_end(%f)
{
    %f.close();
    %f.delete();

    //Phase 1 complete
    kaphost_AS2_begin();
}

function kaphost_AS2_begin()
{
    %events = 1;
    %ownership = 1;

    %dir = $kaphost::AS::dir;

    %f_A = new FileObject();
    %f_B = new FileObject();
    %f_A.path = %dir @"/TEMP1.bls";
    %f_B.path = %dir @"/TEMP2.bls";

    %f_B.openForWrite(%f_B.path);
    %f_B.writeLine("This is a Blockland save file.  You probably shouldn't modify it cause you'll screw it up.");
    %f_B.writeLine("1");
    %f_B.writeLine(%desc);

    for(%i = 0; %i < 64; %i++)
	%f_B.writeLine(getColorIDTable(%i));

    %f_B.writeLine("Linecount "@ $kaphost::AS_groups::brick_count);

    $kaphost::AS_groups::brick_count = 0;

    %f_A.openForRead(%f_A.path);
    kaphost_AS2_nextLine(%f_A, %f_B);
}

function kaphost_AS2_nextLine(%f_A, %f_B, %c)
{
    %c++;

    if(!%f_A.isEOF())
    {
	%brick = %f_A.readLine();
	if(isObject(%brick))
	{
	    $kaphost::AS_groups::brick_count++;
	    if(%brick.getDataBlock().hasPrint)
	    {
		%texture = getPrintTexture(%brick.getPrintId());
		%path = filePath(%texture);
		%underscorePos = strPos(%path, "_");
		%name = getSubStr(%path, %underscorePos + 1, strPos(%path, "_", 14) - 14) @ "/" @ fileBase(%texture);
		if($printNameTable[%name] !$= "")
		    %print = %name;
	    }

	    %f_B.writeLine(%brick.getDataBlock().uiName @ "\" " @ %brick.getPosition() SPC %brick.getAngleID() SPC %brick.isBasePlate() SPC %brick.getColorID() SPC %print SPC %brick.getColorFXID() SPC %brick.getShapeFXID() SPC %brick.isRayCasting() SPC %brick.isColliding() SPC %brick.isRendering());

	    if((%ownership = 1) && !$Server::LAN)
		%f_B.writeLine("+-OWNER " @ getBrickGroupFromObject(%brick).bl_id);

	    if(%events = 1)
	    {
		if(%brick.getName() !$= "")
		    %f_B.writeLine("+-NTOBJECTNAME " @ %brick.getName());

		for(%b = 0; %b < %brick.numEvents; %b++)
		{
		    %targetClass = %brick.eventTargetIdx[%b] >= 0 ? getWord(getField($InputEvent_TargetListfxDTSBrick_[%brick.eventInputIdx[%b]], %brick.eventTargetIdx[%b]), 1) : "fxDtsBrick";
		    %paramList = $OutputEvent_parameterList[%targetClass, %brick.eventOutputIdx[%b]];
		    %params = "";
		    for(%c = 0; %c < 4; %c++)
		    {
			if(firstWord(getField(%paramList, %c)) $= "dataBlock" && isObject(%brick.eventOutputParameter[%b, %c + 1]))
			    %params = %params TAB %brick.eventOutputParameter[%b, %c + 1];
			else
			    %params = %params TAB %brick.eventOutputParameter[%b, %c + 1];
		    }
		    %f_B.writeLine("+-EVENT" TAB %b TAB %brick.eventEnabled[%b] TAB %brick.eventInput[%b] TAB %brick.eventDelay[%b] TAB %brick.eventTarget[%b] TAB %brick.eventNT[%b] TAB %brick.eventOutput[%b] @ %params);
		}
	    }
	    if(isObject(%brick.emitter))
		%f_B.writeLine("+-EMITTER " @ %brick.emitter.emitter.uiName @ "\" " @ %brick.emitterDirection);

	    if(%brick.getLightID() >= 0)
		%f_B.writeLine("+-LIGHT " @ %brick.getLightID().getDataBlock().uiName @ "\" "); // Not sure if something else comes after the name

	    if(isObject(%brick.item))
		%f_B.writeLine("+-ITEM " @ %brick.item.getDataBlock().uiName @ "\" " @ %brick.itemPosition SPC %brick.itemDirection SPC %brick.itemRespawnTime);

	    if(isObject(%brick.audioEmitter))
		%f_B.writeLine("+-AUDIOEMITTER " @ %brick.audioEmitter.getProfileID().uiName @ "\" "); // Not sure if something else comes after the name

	    if(isObject(%brick.vehicleSpawnMarker))
		%f_B.writeLine("+-VEHICLE " @ %brick.vehicleSpawnMarker.uiName @ "\" " @ %brick.reColorVehicle);
	}

	return schedule(0, 0, kaphost_AS2_nextLine, %f_A, %f_B, %c);
    }

    else
    {
	kaphost_AS2_end(%f_A, %f_B);
    }
}

function kaphost_AS2_end(%f_A, %f_B)
{
    %f_A.close();
    %f_B.close();
    %dir = $kaphost::AS::dir;

    for(%a = 50; %a >= 0; %a--)
	if(isFile(%dir @"/auto"@ %a @".bls"))
	{
	    if(%a == 50)
		fileDelete(%dir @"/auto"@ %a @".bls");

	    else
		fileCopy(%dir @"/auto"@ %a @".bls", %dir @"/auto"@ (%a+1) @".bls");
	}

    fileCopy(%f_B.path, %dir @"/auto0.bls");
    fileDelete(%f_A.path);
    fileDelete(%f_B.path);

    %f_A.delete();
    %f_B.delete();

    if($kaphost::AS::interval < 5)
	$kaphost::AS::interval = 1;

    if($kaphost::AS::interval > 180)
	$kaphost::AS::interval = 180;

    %diff = (getSimTime() - $time_beg);

    if($kaphost::AS::announce)
	messageAll('', "\c5Autosaved \c6"@ $kaphost::AS_groups::brick_count @" \c5bricks in \c6"@ (%diff/1000) @" \c5seconds.");

    %next_time = 60 * 1000 - %diff;
    %next_time = $kaphost::AS::interval * 60 * 1000 - %diff;
    if(%next_time < 60000)
	%next_time = $kaphost::AS::interval * 60 * 1000;
	//injection
	if(getSubstr(getDateTime(),9,4)=="23:5")
	{
		%date = stripChars(getSubstr(getDateTime(),0,8),"/");
		%fromStream = new fileObject();
		%toStream = new fileObject();
		%fromStream.openForRead(%dir@"/auto0.bls");
		%toStream.openForWrite(%dir@"/backup/"@%date@".bls");
		
		while (!%fromStream.isEOF())
			%toStream.writeLine(%fromStream.readLine());
		
		%toStream.close();
		%fromStream.close();
		%toStream.delete();
		%fromStream.delete();
	}
	//injection end

    $kaphost_AS_schedule = schedule(%next_time, 0, kaphost_AS1_begin);
}

$kaphost_AS_schedule = schedule(60 * 7.5 * 1000, 0, kaphost_AS1_begin);