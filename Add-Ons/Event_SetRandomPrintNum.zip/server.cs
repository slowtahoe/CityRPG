function fxDTSbrick::setRandomPrintNum(%brick, %min, %max, %client)
{
	%min = mClampF(%min, 0, 9);
	%max = mClampF(%max, 0, 9);
	%random = getRandom(%min, %max);

	%brick.setPrintCount(%random, %client);
}

registerOutputEvent("fxDTSbrick", "setRandomPrintNum", "int 0 9 0" TAB "int 0 9 9", 1);