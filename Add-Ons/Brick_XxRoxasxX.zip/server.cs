datablock fxDTSBrickData (brick1x1x9BrickData)
{
	brickFile = "./1x1x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x1x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x1x3";
};

datablock fxDTSBrickData (brick1x2x9BrickData)
{
	brickFile = "./1x2x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x2x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x2x3";
};

datablock fxDTSBrickData (brick1x3x9BrickData)
{
	brickFile = "./1x3x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x3x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x3x3";
};

datablock fxDTSBrickData (brick1x4x9BrickData)
{
	brickFile = "./1x4x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x4x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x4x3";
};

datablock fxDTSBrickData (brick1x6x9BrickData)
{
	brickFile = "./1x6x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x6x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x6x3";
};

datablock fxDTSBrickData (brick1x8x9BrickData)
{
	brickFile = "./1x8x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x8x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x8x3";
};

datablock fxDTSBrickData (brick1x10x9BrickData)
{
	brickFile = "./1x10x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x10x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x10x3";
};

datablock fxDTSBrickData (brick1x12x9BrickData)
{
	brickFile = "./1x12x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x12x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x12x3";
};

datablock fxDTSBrickData (brick1x16x9BrickData)
{
	brickFile = "./1x16x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x16x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x16x3";
};


datablock fxDTSBrickData (brick2x3x9BrickData)
{
	brickFile = "./2x3x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x3x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x3x3";
};


datablock fxDTSBrickData (brick2x8x9BrickData)
{
	brickFile = "./2x8x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x8x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x8x3";
};

datablock fxDTSBrickData (brick2x10x9BrickData)
{
	brickFile = "./2x10x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x10x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x10x3";
};

datablock fxDTSBrickData (brick2x12x9BrickData)
{
	brickFile = "./2x12x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x12x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x12x3";
};

datablock fxDTSBrickData (brick2x16x9BrickData)
{
	brickFile = "./2x16x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x16x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x16x3";
};

datablock fxDTSBrickData (brick1x8x15BrickData)
{
	brickFile = "./1x8x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x8x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x8x5";
};

datablock fxDTSBrickData (brick1x10x15BrickData)
{
	brickFile = "./1x10x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x10x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x10x5";
};

datablock fxDTSBrickData (brick1x16x15BrickData)
{
	brickFile = "./1x16x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x16x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 1x16x5";
};

datablock fxDTSBrickData (brick2x8x15BrickData)
{
	brickFile = "./2x8x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x8x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x8x5";
};

datablock fxDTSBrickData (brick2x10x15BrickData)
{
	brickFile = "./2x10x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x10x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x10x5";
};

datablock fxDTSBrickData (brick2x16x15BrickData)
{
	brickFile = "./2x16x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x16x5";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x16x5";
};

datablock fxDTSBrickData (brick3x3x1BrickData)
{
	brickFile = "./3x3F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x3F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x3F";
};

datablock fxDTSBrickData (brick3x4x1BrickData)
{
	brickFile = "./3x4F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x4F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x4F";
};

datablock fxDTSBrickData (brick3x6x1BrickData)
{
	brickFile = "./3x6F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x6F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x6F";
};

datablock fxDTSBrickData (brick3x8x1BrickData)
{
	brickFile = "./3x8F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x8F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x8F";
};

datablock fxDTSBrickData (brick3x10x1BrickData)
{
	brickFile = "./3x10F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x10F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x10F";
};

datablock fxDTSBrickData (brick3x12x1BrickData)
{
	brickFile = "./3x12F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x12F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x12F";
};

datablock fxDTSBrickData (brick3x16x1BrickData)
{
	brickFile = "./3x16F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x16F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x16F";
};

datablock fxDTSBrickData (brick3x3x3BrickData)
{
	brickFile = "./3x3.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x3";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x3";
};

datablock fxDTSBrickData (brick3x4x3BrickData)
{
	brickFile = "./3x4.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x4";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x4";
};

datablock fxDTSBrickData (brick3x6x3BrickData)
{
	brickFile = "./3x6.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x6";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x6";
};

datablock fxDTSBrickData (brick3x8x3BrickData)
{
	brickFile = "./3x8.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x8";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x8";
};

datablock fxDTSBrickData (brick3x10x3BrickData)
{
	brickFile = "./3x10.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x10";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x10";
};

datablock fxDTSBrickData (brick3x12x3BrickData)
{
	brickFile = "./3x12.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x12";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x12";
};

datablock fxDTSBrickData (brick3x16x3BrickData)
{
	brickFile = "./3x16.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x16";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 3x16";
};

datablock fxDTSBrickData (brick2x12x1BrickData)
{
	brickFile = "./2x12F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x12F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x12F";
};

datablock fxDTSBrickData (brick2x16x1BrickData)
{
	brickFile = "./2x16F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x16F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x16F";
};

datablock fxDTSBrickData (brick2x12x3BrickData)
{
	brickFile = "./2x12.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x12";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x12";
};

datablock fxDTSBrickData (brick2x16x3BrickData)
{
	brickFile = "./2x16.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x16";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 2x16";
};

datablock fxDTSBrickData (brick6x6x3BrickData)
{
	brickFile = "./6x6.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x6";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 6x6";
};

datablock fxDTSBrickData (brick6x8x3BrickData)
{
	brickFile = "./6x8.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x8";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 6x8";
};

datablock fxDTSBrickData (brick6x10x3BrickData)
{
	brickFile = "./6x10.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x10";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 6x10";
};

datablock fxDTSBrickData (brick6x12x3BrickData)
{
	brickFile = "./6x12.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x12";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 6x12";
};

datablock fxDTSBrickData (brick6x16x3BrickData)
{
	brickFile = "./6x16.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x16";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 6x16";
};

datablock fxDTSBrickData (brick8x10x3BrickData)
{
	brickFile = "./8x10.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x10";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 8x10";
};

datablock fxDTSBrickData (brick8x10x1BrickData)
{
	brickFile = "./8x10F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x10F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 8x10F";
};

datablock fxDTSBrickData (brick8x12x3BrickData)
{
	brickFile = "./8x12.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x12";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 8x12";
};

datablock fxDTSBrickData (brick8x12x1BrickData)
{
	brickFile = "./8x12F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x12F";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 8x12F";
};

datablock fxDTSBrickData (brick16x64x1BrickData)
{
	brickFile = "./16x64Base.blb";
	category = "Baseplates";
	subCategory = "Plain";
	uiName = "16x64 Base";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 16x64Base";
};

datablock fxDTSBrickData (brick32x48x1BrickData)
{
	brickFile = "./32x48Base.blb";
	category = "Baseplates";
	subCategory = "Plain";
	uiName = "32x48 Base";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 32x48Base";
};

datablock fxDTSBrickData (brick16x48x1BrickData)
{
	brickFile = "./16x48Base.blb";
	category = "Baseplates";
	subCategory = "Plain";
	uiName = "16x48 Base";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 16x48Base";
};

datablock fxDTSBrickData (brick48x64x1BrickData)
{
	brickFile = "./48x64Base.blb";
	category = "Baseplates";
	subCategory = "Plain";
	uiName = "48x64 Base";
	iconName = "Add-Ons/Brick_XxRoxasxX/Pic 48x64Base";
};