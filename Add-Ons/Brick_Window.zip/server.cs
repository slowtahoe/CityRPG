datablock fxDTSBrickData(brick1x1x3WindowData)
{
	brickFile = "./1x1x3window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x3 Window";
	iconName = "Add-Ons/Brick_Window/1x1x3window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x2x3WindowData)
{
	brickFile = "./1x2x3window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x2x3 Window";
	iconName = "Add-Ons/Brick_Window/1x2x3window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x4x3WindowData)
{
	brickFile = "./1x4x3window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x4x3 Window";
	iconName = "Add-Ons/Brick_Window/1x4x3window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x4x2WindowData)
{
	brickFile = "./1x4x2window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x4x2 Window";
	iconName = "Add-Ons/Brick_Window/1x4x2window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x3x2WindowData)
{
	brickFile = "./1x3x2window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x3x2 Window";
	iconName = "Add-Ons/Brick_Window/1x3x2window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x2x2WindowData)
{
	brickFile = "./1x2x2window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x2x2 Window";
	iconName = "Add-Ons/Brick_Window/1x2x2window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x1x2WindowData)
{
	brickFile = "./1x1x2window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x2 Window";
	iconName = "Add-Ons/Brick_Window/1x1x2window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick1x2x1WindowData)
{
	brickFile = "./1x2x1window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x2x1 Window";
	iconName = "Add-Ons/Brick_Window/1x2x1window";
	orientationFix = 1;
};


datablock fxDTSBrickData(brick1x1x1WindowData)
{
	brickFile = "./1x1x1window.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "1x1x1 Window";
	iconName = "Add-Ons/Brick_Window/1x1x1window";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x4x5WindowData)
{
	brickFile = "./2x4x5window.blb";
	category = "Special";
	subCategory = "Special Windows";
	uiName = "2x4x5 Window Slanted";
	iconName = "Add-Ons/Brick_Window/2x4x5window";
	orientationFix = 3;
	collisionShapeName = "./2x4x5window.dts";
};

datablock fxDTSBrickData(brick3x4x6WindowData)
{
	brickFile = "./3x4x6window.blb";
	category = "Special";
	subCategory = "Special Windows";
	uiName = "3x4x6 Window Slanted";
	iconName = "Add-Ons/Brick_Window/3x4x6window";
	orientationFix = 3;
	collisionShapeName = "./3x4x6window.dts";
};


datablock fxDTSBrickData(brick4x4x3WindowData)
{
	brickFile = "./4x4x3window.blb";
	category = "Special";
	subCategory = "Special Windows";
	uiName = "4x4x3 Window Slanted";
	iconName = "Add-Ons/Brick_Window/4x4x3window";
	orientationFix = 3;
	collisionShapeName = "./4x4x3window.dts";
};

datablock fxDTSBrickData(brick4x5x2WindowData)
{
	brickFile = "./4x5x2window.blb";
	category = "Special";
	subCategory = "Special Windows";
	uiName = "4x5x2 Window Slanted";
	iconName = "Add-Ons/Brick_Window/4x5x2window";
	orientationFix = 3;
	collisionShapeName = "./4x5x2window.dts";
};

datablock fxDTSBrickData(brick3x8x6BayWindowData)
{
	brickFile = "./3x8x6baywindow.blb";
	category = "Special";
	subCategory = "Special Windows";
	uiName = "Bay Window";
	iconName = "Add-Ons/Brick_Window/3x8x6baywindow";
	orientationFix = 1;
	collisionShapeName = "./3x8x6baywindow.dts";
};