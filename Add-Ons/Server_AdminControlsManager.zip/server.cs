//> ===>
//> Title: Admin Controls Manager
//> Author: Truce
//> ===>

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs")) {
	if(!$RTB::RTBR_ServerControl_Hook)
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	%file=new FileObject();
	%path="config/server/AdminControls/cmdList.txt";
	if(!isFile(%path)) {
		%file.openForWrite(%path);
		%file.writeLine("Kick");
		%file.writeLine("Ban");
		%file.writeLine("UnBan");
		%file.close();
	}
	%file2=new FileObject();
	%path2="config/server/AdminControls/cmdParent.cs";
	%file2.openForWrite(%path2);
	%file2.writeLine("package ACM2 {");
	%file.openForRead(%path);
	while(!%file.isEOF()) {
		%line=%file.readLine();
		RTB_registerPref(%line,"Admin Controls","AdminControls["@%line@"]","list Admin 0 SuperAdmin 1 Host 2","Server_AdminControls",0,0,1);
		%file2.writeLine("	function serverCmd"@%line@"(%cl,%a1,%a2,%a3,%a5,%a6,%a7,%a8,%a9,%a10,%a11,%a12,%a13,%a14,%a15,%a16,%a17,%a18,%a19,%a20) {");
		%file2.writeLine("		if(CheckACM(%cl,\""@%line@"\")) {");
		%file2.writeLine("			%a=%cl.isSuperAdmin;");
		%file2.writeLine("			%b=%cl.isHost;");
		%file2.writeLine("			%cl.isSuperAdmin=1;");
		%file2.writeLine("			%cl.isHost=1;");
		%file2.writeLine("			Parent::serverCmd"@%line@"(%cl,%a1,%a2,%a3,%a5,%a6,%a7,%a8,%a9,%a10,%a11,%a12,%a13,%a14,%a15,%a16,%a17,%a18,%a19,%a20);");
		%file2.writeLine("			%cl.isSuperAdmin=%a;");
		%file2.writeLine("			%cl.isHost=%b;");
		%file2.writeLine("		}");
		%file2.writeLine("	}");
	}
	%file2.writeLine("};");
	%file2.writeLine("activatePackage(ACM2);");
	%file.close();
	%file2.close();
	%file.delete();
	%file2.delete();
	exec(%path2);
}
else {
	error("Server_AdminControls: Required mod System_ReturnToBlockland not found!");
	return;
}
package ACM {
	function GameConnection::autoAdminCheck(%cl) {
		%cl.isHost=0;
		if(%cl.isLocalConnection()||%cl.bl_id==getNumKeyID())
			%cl.isHost=1;
		return Parent::autoAdminCheck(%cl);
	}
	function CheckACM(%cl,%cmd) {
		switch($AdminControls[%cmd]) {
			case 0:
				if(%cl.isAdmin||%cl.isSuperAdmin||%cl.isHost)
					return 1;
				%type="\c3Admins\c0, \c3Super Admins\c0, and the \c3Host";
			case 1:
				if(%cl.isSuperAdmin||%cl.isHost)
					return 1;
				%type="\c3Super Admins\c0 and the \c3Host";
			case 2:
				if(%cl.isHost)
					return 1;
				%type="the \c3Host";
		}
		messageClient(%cl,'',"\c0Sorry, only "@%type@" \c0can use the \c3"@%cmd@" \c0command.");
		return 0;
	}
};
activatePackage(ACM);