datablock fxDTSBrickData (brickATMData)
{
	brickFile = "Add-Ons/Brick_ATM/ATM.blb";
	category = "Special"; 
	subCategory = "Misc";
	uiName = "ATM";                  
	iconName = "Add-Ons/Brick_ATM/imgATM";
};