// - Zack0Wack0 <http://zack0wack0.com>

%error = ForceRequiredAddOn("Brick_Large_Cubes");

if(%error == $Error::AddOn_NotFound)
{
	error("ERROR: Brick_Deletion - required add-on Brick_Large_Cubes not found");
	return;
}

datablock fxDTSBrickData (brick64xDeleteData : brick64xCubeData)
{
	category = "Baseplates";
	subCategory = "Deletion";
	uiName = "64x Deletion Cube";
	deletion = true;
	deletionSize = "31.5 31.5 32";
};

datablock fxDTSBrickData (brick32xDeleteData : brick32xCubeData)
{
	category = "Baseplates";
	subCategory = "Deletion";
	uiName = "32x Deletion Cube";
	deletion = true;
	deletionSize = "15.5 15.5 16";
};

datablock fxDTSBrickData (brick16xDeleteData : brick16xCubeData)
{
	category = "Baseplates";
	subCategory = "Deletion";
	uiName = "16x Deletion Cube";
	deletion = true;
	deletionSize = "7.5 7.5 8";
};

datablock fxDTSBrickData (brick8xDeleteData : brick8xCubeData)
{
	category = "Baseplates";
	subCategory = "Deletion";
	uiName = "8x Deletion Cube";
	deletion = true;
	deletionSize = "3.5 3.5 4";
};

datablock fxDTSBrickData(brick4xDeleteData : brick4xCubeData)
{
	category = "Baseplates";
	subCategory = "Deletion";
	uiName = "4x Deletion Cube";
	deletion = true;
	deletionSize = "1.5 1.5 2";
};

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		if(isFile("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs"))
			exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
		else
			exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}
	
	RTB_registerPref("Admin only","Deletion Bricks","$Deletion::Admin","bool","Brick_Deletion",0,0,0);
}
else
	$Deletion::Admin = 0;

package Brick_Deletion
{
	function serverCmdPlantBrick(%client)
	{
		%player = %client.player;
		%tempBrick = %player.tempBrick;
		
		if(!isObject(%tempBrick))
			return Parent::serverCmdPlantBrick(%client);
		
		%db = %tempBrick.getDatablock();
		
		if(!%db.deletion)
			return Parent::serverCmdPlantBrick(%client);

		if(!%client.isAdmin && !$Deletion::Admin)
		{
			%oldBrickCount = $Server::BrickCount;
			
			initContainerBoxSearch(%tempBrick.getPosition(),%db.deletionSize,$TypeMasks::FxBrickAlwaysObjectType);
			
			while(%brick = containerSearchNext())
			{
				if(%brick == %tempBrick)
					continue;
				
				if(%brick.willCauseChainKill())
				{
					if(getTrustLevel(%client,%brick) >= $TrustLevel::Wand)
						%brick.killbrick();
					else
					{
						%name = %brick.getGroup().name;
						
						centerPrint(%client,%name @ " does not trust you enough to do that.",3,3);
					}
	 			}
				else
				{
					if(getTrustLevel(%client,%brick) >= 2)
						%brick.killbrick();
					else
					{
						%name = %brick.getGroup().name;
						
						centerPrint(%client,%name @ " does not trust you enough to do that.",3,3);
					}
	 			}
		
			}
			
			bottomPrint(%client,%oldBrickCount - $Server::BrickCount @ "\c6 bricks were deleted.",3,3);
		}
		else if(%client.isAdmin)
		{
			%oldBrickCount = $Server::BrickCount;
			
			initContainerBoxSearch(%tempBrick.getPosition(),%db.deletionSize,$TypeMasks::FxBrickAlwaysObjectType);
			
			while(%brick = containerSearchNext())
			{
				if(%brick != %tempBrick)
					%brick.killbrick();
			}
			
			bottomPrint(%client,%oldBrickCount - $Server::BrickCount @ "\c6 bricks were deleted.",3,3);
		}
	}
};

activatePackage(Brick_Deletion);
