if($BSD_TabShifting != 1)
{
	exec("./ui/BrickSelectorDlg.gui");
	$BSD_SelectedTab = 0;
	$BSD_TabShifting = 1;
}

//Package

package GUI_tabShiftingBrickSelectorClient
{
	//Functions

	function BSD_ShowTab(%number)
	{
		Parent::BSD_ShowTab(%number);

		if(%number < BSD_TabBox.getCount())
		{
			$BSD_SelectedTab = %number;
		}
		else
		{
			$BSD_SelectedTab = 1;
		}

		BSD_TabBoxShifter.checkTabVisibility();
	}

	//BrickSelectorDlg Methods

	function BrickSelectorDlg::onWake(%this)
	{
		Parent::onWake(%this);
		BSD_TabBoxShifter.add(BSD_TabBox);

		if(getWord(BSD_TabBox.position,0) > 0)
		{
			BSD_TabBox.position = 0 SPC 0;
		}
		else
		{
			BSD_TabBox.position = getWord(BSD_TabBox.position,0) SPC 0;
		}

		%width = 0;

		for(%i = 0;%i < BSD_TabBox.getCount();%i++)
		{
			%width += 80;
		}

		BSD_TabBox.extent = %width SPC 25;
		BSD_TabBoxShifter.checkButtonVisibility();
		BSD_TabBoxShifter.checkTabVisibility();
	}

	//BSD_TabBoxShifter Methods

	function BSD_TabBoxShifter::checkButtonVisibility()
	{
		if(getWord(BSD_TabBox.extent,0) > 584)
		{
			if(getWord(BSD_TabBox.position,0) == 0)
			{
				BSD_TabBoxShifter_BtnLeft.visible = 0;
				BSD_TabBoxShifter_BtnRight.visible = 1;
			}
			else if(getWord(BSD_TabBox.position,0) == 584 - getWord(BSD_TabBox.extent,0))
			{
				BSD_TabBoxShifter_BtnLeft.visible = 1;
				BSD_TabBoxShifter_BtnRight.visible = 0;
			}
			else
			{
				BSD_TabBoxShifter_BtnLeft.visible = 1;
				BSD_TabBoxShifter_BtnRight.visible = 1;
			}
		}
		else
		{
			BSD_TabBoxShifter_BtnLeft.visible = 0;
			BSD_TabBoxShifter_BtnRight.visible = 0;
		}
	}

	function BSD_TabBoxShifter::checkTabVisibility()
	{
		%selectedTab = BSD_TabBox.getObject($BSD_SelectedTab);

		if(isObject(%selectedTab))
		{
			if(getWord(%selectedTab.position,0) + getWord(BSD_TabBox.position,0) > 504)
			{
				%number = mCeil((getWord(%selectedTab.position,0) + getWord(BSD_TabBox.position,0) - 504) / 80);

				for(%i = 0;%i < %number;%i++)
				{
					BSD_TabBoxShifter.shiftTabsLeft();
				}
			}
			else if(getWord(BSD_TabBox.position,0) + getWord(%selectedTab.position,0) < 0)
			{
				%number = mCeil(-1 * (getWord(BSD_TabBox.position,0) + getWord(%selectedTab.position,0)) / 80);

				for(%i = 0;%i < %number;%i++)
				{
					BSD_TabBoxShifter.shiftTabsRight();
				}
			}
		}
	}

	function BSD_TabBoxShifter::shiftTabsLeft()
	{
		if(getWord(BSD_TabBox.extent,0) > 584 && getWord(BSD_TabBox.position,0) > 584 - getWord(BSD_TabBox.extent,0))
		{
			if(getWord(BSD_TabBox.position,0) - 80 >= 584 - getWord(BSD_TabBox.extent,0))
			{
				BSD_TabBox.position = getWord(BSD_TabBox.position,0) - 80 SPC getWord(BSD_TabBox.position,1);
			}
			else
			{
				BSD_TabBox.position = 584 - getWord(BSD_TabBox.extent,0) SPC getWord(BSD_TabBox.position,1);
			}
		}

		BSD_TabBoxShifter.checkButtonVisibility();
	}

	function BSD_TabBoxShifter::shiftTabsRight()
	{
		if(getWord(BSD_TabBox.extent,0) > 584 && getWord(BSD_TabBox.position,0) < 0)
		{
			if(getWord(BSD_TabBox.position,0) + 80 <= 0)
			{
				BSD_TabBox.position = getWord(BSD_TabBox.position,0) + 80 SPC getWord(BSD_TabBox.position,1);
			}
			else
			{
				BSD_TabBox.position = 0 SPC getWord(BSD_TabBox.position,1);
			}
		}

		BSD_TabBoxShifter.checkButtonVisibility();
	}
};

activatePackage(GUI_tabShiftingBrickSelectorClient);