datablock fxDTSBrickData(brick1x1SlantedData)
{
	brickFile = "./1x1Slanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x1 Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x1Slanted";
};
datablock fxDTSBrickData(brick1x1CSlantedData)
{
	brickFile = "./1x1CSlanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x1 C Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x1CSlanted";
};
datablock fxDTSBrickData(brick1x2SlantedData)
{
	brickFile = "./1x2Slanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x2 Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x2Slanted";
};
datablock fxDTSBrickData(brick1x4SlantedData)
{
	brickFile = "./1x4Slanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x4 Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x4Slanted";
};
datablock fxDTSBrickData(brick1x6SlantedData)
{
	brickFile = "./1x6Slanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x6 Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x6Slanted";
};
datablock fxDTSBrickData(brick1x8SlantedData)
{
	brickFile = "./1x8Slanted.blb";
	category = "Ramps";
	subCategory = "Slanted";
	uiName = "1x8 Slanted";
	iconName = "Add-Ons/Brick_Slanted/1x8Slanted";
};