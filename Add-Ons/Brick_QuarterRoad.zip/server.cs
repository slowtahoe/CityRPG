datablock fxDTSBrickData (brickQRStraightData)
{
	brickFile = "./Straight.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Straight";
	iconName = "Add-Ons/Brick_QuarterRoad/Straight";
};

datablock fxDTSBrickData (brickQROutsideCornerData)
{
	brickFile = "./OutsideCorner.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Outside Corner";
	iconName = "Add-Ons/Brick_QuarterRoad/Outside Corner";
};

datablock fxDTSBrickData (brickQRInsideCornerData)
{
	brickFile = "./InsideCorner.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Inside Corner";
	iconName = "Add-Ons/Brick_QuarterRoad/Inside Corner";
};

datablock fxDTSBrickData (brickQRCenterData)
{
	brickFile = "./Center.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Middle";
	iconName = "Add-Ons/Brick_QuarterRoad/Middle";
};

datablock fxDTSBrickData (brickQRSideWalkData)
{
	brickFile = "./SideWalk.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Sidewalk";
	iconName = "Add-Ons/Brick_QuarterRoad/Sidewalk";
};

datablock fxDTSBrickData (brickQRStraightRampAData)
{
	brickFile = "./StraightRamp.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Straight Ramp A";
	iconName = "Add-Ons/Brick_QuarterRoad/Straight Ramp A";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoad/StraightRamp.dts";
};

datablock fxDTSBrickData (brickQRCenterRampData)
{
	brickFile = "./CenterRamp.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Middle Ramp";
	iconName = "Add-Ons/Brick_QuarterRoad/Middle Ramp";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoad/CenterRamp.dts";
};

datablock fxDTSBrickData (brickQRStraightRampBData)
{
	brickFile = "./StraightRamp2.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Straight Ramp B";
	iconName = "Add-Ons/Brick_QuarterRoad/Straight Ramp B";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoad/StraightRamp2.dts";
};

datablock fxDTSBrickData (brickQRSideWalkRampData)
{
	brickFile = "./SideWalkRamp.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Sidewalk Ramp";
	iconName = "Add-Ons/Brick_QuarterRoad/Sidewalk Ramp";
	CollisionShapeName = "Add-Ons/Brick_QuarterRoad/SideWalkRampCol.dts";
};

datablock fxDTSBrickData (brickQRRampSupportData)
{
	brickFile = "./RampSupport.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Ramp Support";
	iconName = "Add-Ons/Brick_QuarterRoad/Ramp Support";
};

datablock fxDTSBrickData (brickQRStraightFData)
{
	brickFile = "./StraightF.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "StraightF";
	iconName = "Add-Ons/Brick_QuarterRoad/StraightF";
};

datablock fxDTSBrickData (brickQROutsideCornerFData)
{
	brickFile = "./OutsideCornerF.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Outside CornerF";
	iconName = "Add-Ons/Brick_QuarterRoad/Outside CornerF";
};

datablock fxDTSBrickData (brickQRInsideCornerFData)
{
	brickFile = "./InsideCornerF.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "Inside CornerF";
	iconName = "Add-Ons/Brick_QuarterRoad/Inside CornerF";
};

datablock fxDTSBrickData (brickQRCenterFData)
{
	brickFile = "./CenterF.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "MiddleF";
	iconName = "Add-Ons/Brick_QuarterRoad/MiddleF";
};

datablock fxDTSBrickData (brickQRSideWalkFData)
{
	brickFile = "./SideWalkF.blb";
	category = "Baseplates";
	subCategory = "QuarterRoad";
	uiName = "SidewalkF";
	iconName = "Add-Ons/Brick_QuarterRoad/SidewalkF";
};