//Misc
datablock fxDTSBrickData(brick1x1x5AntennaData)
{
	brickFile = "./1x1x5Antenna.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Antenna";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x5Antenna";
};

datablock fxDTSBrickData(brick1x2RidgedData)
{
	brickFile = "./1x2Ridged.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2 Ridged";
	iconName = "Add-Ons/Brick_1RandomPack/1x2Ridged";
};

datablock fxDTSBrickData(brick1x2LogData)
{
	brickFile = "./1x2Log.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "1x2Log";
	iconName = "Add-Ons/Brick_1RandomPack/1x2Log";
};

datablock fxDTSBrickData(brick2x2x2coneInvData)
{
	brickFile = "./2x2x2coneInv.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x2x2 cone Inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2coneInv";
};

datablock fxDTSBrickData(brick2x4x3WindscreenData)
{
	brickFile = "./2x4x3Windscreen.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "2x4x3 Windscreen";
	iconName = "Add-Ons/Brick_1RandomPack/2x4x3Windscreen";
};

datablock fxDTSBrickData(brick2x4x3TubeData)
{
	brickFile = "./2x4x3Tube.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "2x4x3 Tube";
	iconName = "Add-Ons/Brick_1RandomPack/2x4x3Tube";
};

datablock fxDTSBrickData(brick2x4x3WindscreenUpData)
{
	brickFile = "./2x4x3WindscreenUp.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "2x4x3 Windscreen Inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x4x3WindscreenUp";
};


datablock fxDTSBrickData(brick2x2discInvData : brick2x2discData)
{
	brickFile = "./2x2discInv.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x2 disc Inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x2discInv";
};

datablock fxDTSBrickData(brick1x1coneInvData)
{
	brickFile = "./1x1coneInv.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x1 cone Inv";
	iconName = "Add-Ons/Brick_1RandomPack/1x1coneInv";
};

//Vertical Wings
datablock fxDTSBrickData(brick1x4x2vertwingData)
{
	brickFile = "./1x4x2vertwing.blb";
	category = "Special";
	subCategory = "Vertical Wings";
	uiName = "1x4x2vertwing";
	iconName = "Add-Ons/Brick_1RandomPack/1x4x2vertwing";
};

datablock fxDTSBrickData(brick1x5x3vertwingData)
{
	brickFile = "./1x5x3vertwing.blb";
	category = "Special";
	subCategory = "Vertical Wings";
	uiName = "1x5x3vertwing";
	iconName = "Add-Ons/Brick_1RandomPack/1x5x3vertwing";
};

//Octagonal
datablock fxDTSBrickData(brick1x1OctoPlateData)
{
	brickFile = "./1x1OctoPlate.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "1x1 Octo Plate";
	iconName = "Add-Ons/Brick_1RandomPack/1x1OctoPlate";
};

datablock fxDTSBrickData(brick1x1x1OctoBrickData)
{
	brickFile = "./1x1x1OctoBrick.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "1x1 Octo";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x1OctoBrick";
};

datablock fxDTSBrickData(brick1x1x2OctoBrickData)
{
	brickFile = "./1x1x2OctoBrick.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "1x1x2 Octo";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x2OctoBrick";
};

datablock fxDTSBrickData(brick2x2OctoPlateData)
{
	brickFile = "./2x2OctoPlate.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2 Octo Plate";
	iconName = "Add-Ons/Brick_1RandomPack/2x2OctoPlate";
};

datablock fxDTSBrickData(brick2x2x1OctoBrickData)
{
	brickFile = "./2x2x1OctoBrick.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2 Octo";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x1OctoBrick";
};

datablock fxDTSBrickData(brick2x2x2OctoBrickData)
{
	brickFile = "./2x2x2OctoBrick.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoBrick";
};

datablock fxDTSBrickData(brick1x2OctoPlate90Data)
{
	brickFile = "./1x2OctoPlate90.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "1x2 Octo Plate90";
	iconName = "Add-Ons/Brick_1RandomPack/1x2OctoPlate90";
};

datablock fxDTSBrickData(brick1x2OctoBrick90Data)
{
	brickFile = "./1x2OctoBrick90.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "1x2 Octo Brick90";
	iconName = "Add-Ons/Brick_1RandomPack/1x2OctoBrick90";
};

datablock fxDTSBrickData(brick2x2OctoBrick90Data)
{
	brickFile = "./2x2OctoBrick90.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2 Octo Brick90";
	iconName = "Add-Ons/Brick_1RandomPack/2x2OctoBrick90";
};

datablock fxDTSBrickData(brick2x2x1OctoConeData)
{
	brickFile = "./2x2x1OctoCone.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x1 Octo Cone";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x1OctoCone";
};

datablock fxDTSBrickData(brick2x2x1OctoConeInvData)
{
	brickFile = "./2x2x1OctoConeInv.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x1 Octo Cone Inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x1OctoConeInv";
};

datablock fxDTSBrickData(brick2x2x2OctoConeData)
{
	brickFile = "./2x2x2OctoCone.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Cone";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoCone";
};

datablock fxDTSBrickData(brick2x2x2OctoConeInvData)
{
	brickFile = "./2x2x2OctoConeInv.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Cone Inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoConeInv";
};

datablock fxDTSBrickData(brick2x3x2OctoBendData)
{
	brickFile = "./2x3x2OctoBend.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x3x2 Octo Offset";
	iconName = "Add-Ons/Brick_1RandomPack/2x3x2OctoBend";
};

datablock fxDTSBrickData(brick2x2x2OctoElbowData)
{
	brickFile = "./2x2x2OctoElbow.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Elbow";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoElbow";
};

datablock fxDTSBrickData(brick2x2x2OctoElbowUpData)
{
	brickFile = "./2x2x2OctoElbowUp.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo - Elbow";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoElbowUp";
};

datablock fxDTSBrickData(brick2x2x2OctoTVertData)
{
	brickFile = "./2x2x2OctoTVert.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo T Vert";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoTVert";
};

datablock fxDTSBrickData(brick2x2x2OctoPlusVertData)
{
	brickFile = "./2x2x2OctoPlusVert.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Plus Vert";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoPlusVert";
};

datablock fxDTSBrickData(brick2x2x2OctoTHorzData)
{
	brickFile = "./2x2x2OctoTHorz.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo T Horz";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoTHorz";
};

datablock fxDTSBrickData(brick2x2x2OctoElbowHorzData)
{
	brickFile = "./2x2x2OctoElbowHorz.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Elbow Horz";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoElbowHorz";
};

datablock fxDTSBrickData(brick2x2x2OctoPlusHorzData)
{
	brickFile = "./2x2x2OctoPlusHorz.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Plus Horz";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoPlusHorz";
};

datablock fxDTSBrickData(brick2x2x2OctoPlusPlusData)
{
	brickFile = "./2x2x2OctoPlusPlus.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo Plus Plus";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoPlusPlus";
};

datablock fxDTSBrickData(brick2x2x2OctoTData)
{
	brickFile = "./2x2x2OctoT.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo T";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoT";
};

datablock fxDTSBrickData(brick2x2x2OctoTupData)
{
	brickFile = "./2x2x2OctoTup.blb";
	category = "Rounds";
	subCategory = "Octagonal";
	uiName = "2x2x2 Octo T inv";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2OctoTup";
};


//Panels
datablock fxDTSBrickData(brick1x1x1PanelCornerData)
{
	brickFile = "./1x1x1PanelCorner.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "1h Panel Corner 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x1PanelCorner";
};

datablock fxDTSBrickData(brick1x1x1PanelData)
{
	brickFile = "./1x1x1Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "1h Panel 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x1Panel";
};

datablock fxDTSBrickData(brick1x2x1PanelData)
{
	brickFile = "./1x2x1Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "1h Panel 2x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x1Panel";
};

datablock fxDTSBrickData(brick1x4x1PanelData)
{
	brickFile = "./1x4x1Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "1h Panel 4x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4x1Panel";
};

datablock fxDTSBrickData(brick1x1x2PanelData)
{
	brickFile = "./1x1x2Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "2h Panel 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x2Panel";
};

datablock fxDTSBrickData(brick1x2x2PanelData)
{
	brickFile = "./1x2x2Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "2h Panel 2x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x2Panel";
};

datablock fxDTSBrickData(brick1x4x2PanelData)
{
	brickFile = "./1x4x2Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "2h Panel 4x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4x2Panel";
};

datablock fxDTSBrickData(brick1x1x4PanelData)
{
	brickFile = "./1x1x4Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "4h Panel 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x1x4Panel";
};

datablock fxDTSBrickData(brick1x2x4PanelData)
{
	brickFile = "./1x2x4Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "4h Panel 2x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x4Panel";
};

datablock fxDTSBrickData(brick1x4x4PanelData)
{
	brickFile = "./1x4x4Panel.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "4h Panel 4x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4x4Panel";
};

datablock fxDTSBrickData(brick1x4x4PanelPrintInsideData)
{
	brickFile = "./1x4x4PanelPrintInside.blb";
	category = "Special";
	subCategory = "Panel";
	uiName = "4h Panel 4x Print Inside";
	iconName = "Add-Ons/Brick_1RandomPack/1x4x4PanelPrintInside";

	hasPrint = 1;
	printAspectRatio = "1x1";
};


//Centered Ramps

datablock fxDTSBrickData(brick1x3rampCenterData)
{
	brickFile = "./1x3rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "45� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3rampCenter";
};

datablock fxDTSBrickData(brick1x3rampCenterUpData)
{
	brickFile = "./1x3rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-45� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3rampCenterUp";
};

datablock fxDTSBrickData(brick1x5rampCenterData)
{
	brickFile = "./1x5rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "25� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x5rampCenter";
};

datablock fxDTSBrickData(brick1x5rampCenterUpData)
{
	brickFile = "./1x5rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-25� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x5rampCenterUp";
};

datablock fxDTSBrickData(brick1x3x3rampCenterData)
{
	brickFile = "./1x3x3rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "72� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x3rampCenter";
};

datablock fxDTSBrickData(brick1x3x3rampCenterUpData)
{
	brickFile = "./1x3x3rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-72� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x3rampCenterUp";
};

datablock fxDTSBrickData(brick1x3x5rampCenterData)
{
	brickFile = "./1x3x5rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "80� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x5rampCenter";
};

datablock fxDTSBrickData(brick1x3x5rampCenterUpData)
{
	brickFile = "./1x3x5rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-80� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x5rampCenterUp";
};

datablock fxDTSBrickData(brick1x4rampCenterData)
{
	brickFile = "./1x4rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "18� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4rampCenter";
};

datablock fxDTSBrickData(brick1x4rampCenterUpData)
{
	brickFile = "./1x4rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-18� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4rampCenterUp";
};

datablock fxDTSBrickData(brick1x2x2rampCenterData)
{
	brickFile = "./1x2x2rampCenter.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "65� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x2rampCenter";
};

datablock fxDTSBrickData(brick1x2x2rampCenterUpData)
{
	brickFile = "./1x2x2rampCenterUp.blb";
	category = "Ramps";
	subCategory = "Centered";
	uiName = "-65� Center Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x2rampCenterUp";
};



//Centered Diagonal Ramps

datablock fxDTSBrickData(brick1x3rampCenterDiagData)
{
	brickFile = "./1x3rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "45� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3rampCenterDiag";
};

datablock fxDTSBrickData(brick1x5rampCenterDiagData)
{
	brickFile = "./1x5rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "25� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x5rampCenterDiag";
};

datablock fxDTSBrickData(brick1x3x3rampCenterDiagData)
{
	brickFile = "./1x3x3rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "72� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x3rampCenterDiag";
};

datablock fxDTSBrickData(brick1x3x5rampCenterDiagData)
{
	brickFile = "./1x3x5rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "80� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x3x5rampCenterDiag";
};

datablock fxDTSBrickData(brick1x4rampCenterDiagData)
{
	brickFile = "./1x4rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "18� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x4rampCenterDiag";
};

datablock fxDTSBrickData(brick1x2x2rampCenterDiagData)
{
	brickFile = "./1x2x2rampCenterDiag.blb";
	category = "Ramps";
	subCategory = "Centered Diagonal";
	uiName = "65� Center Diag Ramp 1x";
	iconName = "Add-Ons/Brick_1RandomPack/1x2x2rampCenterDiag";
};



//Ramp Adapters

datablock fxDTSBrickData(brick2545RampAdapterAData)
{
	brickFile = "./2545RampAdapterA.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "45� 25� Adapter A";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterA";
};

datablock fxDTSBrickData(brick2545RampAdapterBData)
{
	brickFile = "./2545RampAdapterB.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "45� 25� Adapter B";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterB";
};

datablock fxDTSBrickData(brick2545RampAdapterAupData)
{
	brickFile = "./2545RampAdapterAup.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "-45�-25� Inv Adapter A";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterAup";
};

datablock fxDTSBrickData(brick2545RampAdapterBupData)
{
	brickFile = "./2545RampAdapterBup.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "-45�-25� Inv Adapter B";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterBup";
};

datablock fxDTSBrickData(brick2545RampAdapterCData)
{
	brickFile = "./2545RampAdapterC.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "45� 25� Adapter C";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterC";
};

datablock fxDTSBrickData(brick2545RampAdapterCupData)
{
	brickFile = "./2545RampAdapterCup.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "-45� -25� Inv Adapter C";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterCup";
};

datablock fxDTSBrickData(brick2545RampAdapterDData)
{
	brickFile = "./2545RampAdapterD.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "45� 25� Adapter D";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterD";
};

datablock fxDTSBrickData(brick2545RampAdapterDupData)
{
	brickFile = "./2545RampAdapterDup.blb";
	category = "Ramps";
	subCategory = "Adapter";
	uiName = "-45� -25� Inv Adapter D";
	iconName = "Add-Ons/Brick_1RandomPack/2545RampAdapterDup";
};


//Print Plates

datablock fxDTSBrickData(brick3x3FPrintPlateData)
{
	brickFile = "./3x3FPrintPlate.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "3x3f Print";
	iconName = "Add-Ons/Brick_1RandomPack/3x3FPrintPlate";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick3x3FPrintPlateCData)
{
	brickFile = "./3x3FPrintPlateC.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "3x3f Print Ceiling";
	iconName = "Add-Ons/Brick_1RandomPack/3x3FPrintPlateC";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fPlatePrint90Data)
{
	brickFile = "./2x2fPlatePrint90.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2f Print 90";
	iconName = "Add-Ons/Brick_1RandomPack/2x2fPlatePrint90";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};



//Rounds
datablock fxDTSBrickData(brick4x4froundData)
{
	brickFile = "./4x4fround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "4x4f Round";
	iconName = "Add-Ons/Brick_1RandomPack/4x4fround";
	collisionShapeName = "./4x4fround.dts";
};

datablock fxDTSBrickData(brick6x6froundData)
{
	brickFile = "./6x6fround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "6x6f Round";
	iconName = "Add-Ons/Brick_1RandomPack/6x6fround";
	collisionShapeName = "./6x6fround.dts";
};

datablock fxDTSBrickData(brick2x2fRoundPrintCData : brick2x2fRoundData)
{
	brickFile = "./2x2fRoundPrintC.blb";
	category = "Rounds";
	subCategory = "Print";
	uiName = "2x2f Round Ceiling";
	iconName = "Add-Ons/Brick_1RandomPack/2x2fRoundPrintC";
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x4froundprintData)
{
	brickFile = "./4x4froundprint.blb";
	category = "Rounds";
	subCategory = "Print";
	uiName = "4x4f Round Print";
	iconName = "Add-Ons/Brick_1RandomPack/4x4froundprint";
	collisionShapeName = "./4x4fround.dts";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick4x4froundprintCData)
{
	brickFile = "./4x4froundprintC.blb";
	category = "Rounds";
	subCategory = "Print";
	uiName = "4x4f Round Print Ceiling";
	iconName = "Add-Ons/Brick_1RandomPack/4x4froundprintC";
	collisionShapeName = "./4x4fround.dts";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fRoundPrint90Data)
{
	brickFile = "./2x2fRoundPrint90.blb";
	category = "Rounds";
	subCategory = "Print";
	uiName = "2x2f Round Print 90";
	iconName = "Add-Ons/Brick_1RandomPack/2x2fRoundPrint90";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2x2UndercarriageData)
{
	brickFile = "./2x2x2Undercarriage.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x2x2Undercarriage";
	iconName = "Add-Ons/Brick_1RandomPack/2x2x2Undercarriage";
};

datablock fxDTSBrickData(brick1x2halfroundData)
{
	brickFile = "./1x2halfround.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x2 Half-round";
	iconName = "Add-Ons/Brick_1RandomPack/1x2halfround";
};

datablock fxDTSBrickData(brick1x2FhalfroundData)
{
	brickFile = "./1x2Fhalfround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "1x2F Half-round";
	iconName = "Add-Ons/Brick_1RandomPack/1x2Fhalfround";
};

datablock fxDTSBrickData(brick4x2FhalfroundData)
{
	brickFile = "./4x2Fhalfround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "4x2F Half-round";
	iconName = "Add-Ons/Brick_1RandomPack/4x2Fhalfround";
};

datablock fxDTSBrickData(brick6x3FhalfroundData)
{
	brickFile = "./6x3Fhalfround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "6x3F Half-round";
	iconName = "Add-Ons/Brick_1RandomPack/6x3Fhalfround";
};

datablock fxDTSBrickData(brick1x1fhalfroundData)
{
	brickFile = "./1x1fhalfround.blb";
	category = "Rounds";
	subCategory = "Plates";
	uiName = "1x1f half-round";
	iconName = "Add-Ons/Brick_1RandomPack/1x1fhalfround";
};

datablock fxDTSBrickData(brick1x1halfroundData)
{
	brickFile = "./1x1halfround.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x1 half-round";
	iconName = "Add-Ons/Brick_1RandomPack/1x1halfround";
};

datablock fxDTSBrickData(brick1x1halfround90Data)
{
	brickFile = "./1x1halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x1 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/1x1halfround90";
};

datablock fxDTSBrickData(brick2x1halfround90Data)
{
	brickFile = "./2x1halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x1 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/2x1halfround90";
};

datablock fxDTSBrickData(brick4x1halfround90Data)
{
	brickFile = "./4x1halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "4x1 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/4x1halfround90";
};

datablock fxDTSBrickData(brick1x2halfround90Data)
{
	brickFile = "./1x2halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "1x2 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/1x2halfround90";
};

datablock fxDTSBrickData(brick2x2halfround90Data)
{
	brickFile = "./2x2halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "2x2 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/2x2halfround90";
};

datablock fxDTSBrickData(brick4x2halfround90Data)
{
	brickFile = "./4x2halfround90.blb";
	category = "Rounds";
	subCategory = "Bricks";
	uiName = "4x2 half-round 90";
	iconName = "Add-Ons/Brick_1RandomPack/4x2halfround90";
};




// RAMPS
datablock fxDTSBrickData(brick25InvRampCornerData)
{
	brickFile = "./25InvRampCorner.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25�Inv Ramp Corner";
	iconName = "Add-Ons/Brick_1RandomPack/25InvRampCorner";
};

datablock fxDTSBrickData(brick25InvRampCornerUpData)
{
	brickFile = "./25InvRampCornerUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Inv Ramp Corner";
	iconName = "Add-Ons/Brick_1RandomPack/25InvRampCornerUp";
};

datablock fxDTSBrickData(brick2x2crestLowTData)
{
	brickFile = "./2x2crestLowT.blb";
	category = "Ramps";
	subCategory = "25 Degree Crest";
	uiName = "25� Crest T";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestLowT";
};

datablock fxDTSBrickData(brick2x2crestHighTData)
{
	brickFile = "./2x2crestHighT.blb";
	category = "Ramps";
	subCategory = "45 Degree Crest";
	uiName = "45� Crest T";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestHighT";
};

datablock fxDTSBrickData(brick2x2crestLowplusData)
{
	brickFile = "./2x2crestLowplus.blb";
	category = "Ramps";
	subCategory = "25 Degree Crest";
	uiName = "25� Crest Plus";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestLowplus";
};

datablock fxDTSBrickData(brick2x2crestHighplusData)
{
	brickFile = "./2x2crestHighplus.blb";
	category = "Ramps";
	subCategory = "45 Degree Crest";
	uiName = "45� Crest Plus";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestHighplus";
};

datablock fxDTSBrickData(brick1x2xdot666rampData)
{
	brickFile = "./1x2xdot666ramp.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "16.7� 1x2 Ramp";
	iconName = "Add-Ons/Brick_1RandomPack/1x2xdot666ramp";
};

datablock fxDTSBrickData(brick1x3xdot666rampData)
{
	brickFile = "./1x3xdot666ramp.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "11.31� 1x3 Ramp";
	iconName = "Add-Ons/Brick_1RandomPack/1x3xdot666ramp";
};

datablock fxDTSBrickData(brick1x4xdot666rampData)
{
	brickFile = "./1x4xdot666ramp.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "8.53� 1x4 Ramp";
	iconName = "Add-Ons/Brick_1RandomPack/1x4xdot666ramp";
};

datablock fxDTSBrickData(brick2x2crestLowEndData : brick2x2crestLowData)
{
	brickFile = "./2x2crestLowEnd.blb";
	category = "Ramps";
	subCategory = "25 Degree Crest";
	uiName = "25� Crest 2x End";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestLowEnd";
};

datablock fxDTSBrickData(brick2x2crestHighEndData : brick2x2crestHighData)
{
	brickFile = "./2x2crestHighEnd.blb";
	category = "Ramps";
	subCategory = "45 Degree Crest";
	uiName = "45� Crest 2x End";
	iconName = "Add-Ons/Brick_1RandomPack/2x2crestHighEnd";
};




//Extended Ramps

datablock fxDTSBrickData(brick3x2rampData)
{
	brickFile = "./3x2ramp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Ramp 3x";
	iconName = "Add-Ons/Brick_1RandomPack/3x2ramp";
};

datablock fxDTSBrickData(brick8x2rampData)
{
	brickFile = "./8x2ramp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Ramp 8x";
	iconName = "Add-Ons/Brick_1RandomPack/8x2ramp";
};

datablock fxDTSBrickData(brick12x2rampData)
{
	brickFile = "./12x2ramp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Ramp 12x";
	iconName = "Add-Ons/Brick_1RandomPack/12x2ramp";
};

datablock fxDTSBrickData(brick16x2rampData)
{
	brickFile = "./16x2ramp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "45� Ramp 16x";
	iconName = "Add-Ons/Brick_1RandomPack/16x2ramp";
};

datablock fxDTSBrickData(brick3x3rampData)
{
	brickFile = "./3x3ramp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25� Ramp 3x";
	iconName = "Add-Ons/Brick_1RandomPack/3x3ramp";
};

datablock fxDTSBrickData(brick8x3rampData)
{
	brickFile = "./8x3ramp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25� Ramp 8x";
	iconName = "Add-Ons/Brick_1RandomPack/8x3ramp";
};

datablock fxDTSBrickData(brick12x3rampData)
{
	brickFile = "./12x3ramp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25� Ramp 12x";
	iconName = "Add-Ons/Brick_1RandomPack/12x3ramp";
};

datablock fxDTSBrickData(brick16x3rampData)
{
	brickFile = "./16x3ramp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "25� Ramp 16x";
	iconName = "Add-Ons/Brick_1RandomPack/16x3ramp";
};

datablock fxDTSBrickData(brick3x2rampUpData)
{
	brickFile = "./3x2rampUp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Ramp 3x";
	iconName = "Add-Ons/Brick_1RandomPack/3x2rampUp";
};

datablock fxDTSBrickData(brick4x2rampUpData)
{
	brickFile = "./4x2rampUp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Ramp 4x";
	iconName = "Add-Ons/Brick_1RandomPack/4x2rampUp";
};

datablock fxDTSBrickData(brick8x2rampUpData)
{
	brickFile = "./8x2rampUp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Ramp 8x";
	iconName = "Add-Ons/Brick_1RandomPack/8x2rampUp";
};

datablock fxDTSBrickData(brick12x2rampUpData)
{
	brickFile = "./12x2rampUp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Ramp 12x";
	iconName = "Add-Ons/Brick_1RandomPack/12x2rampUp";
};

datablock fxDTSBrickData(brick16x2rampUpData)
{
	brickFile = "./16x2rampUp.blb";
	category = "Ramps";
	subCategory = "45 Degree";
	uiName = "-45� Ramp 16x";
	iconName = "Add-Ons/Brick_1RandomPack/16x2rampUp";
};

datablock fxDTSBrickData(brick3x3rampUpData)
{
	brickFile = "./3x3rampUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Ramp 3x";
	iconName = "Add-Ons/Brick_1RandomPack/3x3rampUp";
};

datablock fxDTSBrickData(brick4x3rampUpData)
{
	brickFile = "./4x3rampUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Ramp 4x";
	iconName = "Add-Ons/Brick_1RandomPack/4x3rampUp";
};

datablock fxDTSBrickData(brick8x3rampUpData)
{
	brickFile = "./8x3rampUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Ramp 8x";
	iconName = "Add-Ons/Brick_1RandomPack/8x3rampUp";
};

datablock fxDTSBrickData(brick12x3rampUpData)
{
	brickFile = "./12x3rampUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Ramp 12x";
	iconName = "Add-Ons/Brick_1RandomPack/12x3rampUp";
};

datablock fxDTSBrickData(brick16x3rampUpData)
{
	brickFile = "./16x3rampUp.blb";
	category = "Ramps";
	subCategory = "25 Degree";
	uiName = "-25� Ramp 16x";
	iconName = "Add-Ons/Brick_1RandomPack/16x3rampUp";
};