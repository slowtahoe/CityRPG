datablock fxDTSBrickData ( brickDoor_VentFrameless_OpenCWData )
{
	brickFile = "./VentFrameless_openCW.blb";
	uiName = "Vent Door Frameless";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_VentFrameless_ClosedCWData";
	openCW = "brickDoor_VentFrameless_OpenCWData";
	
	closedCCW = "brickDoor_VentFrameless_ClosedCWData";
	openCCW = "brickDoor_VentFrameless_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_VentFrameless_OpenCCWData : brickDoor_VentFrameless_OpenCWData )
{
	brickFile = "./VentFrameless_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_VentFrameless_ClosedCWData : brickDoor_VentFrameless_OpenCWData )
{
	brickFile = "./VentFrameless_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Other/bricks/VentFrameless";

	isOpen = 0;
};