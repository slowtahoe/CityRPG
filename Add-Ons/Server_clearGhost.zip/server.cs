//ClearGhostBricks

package GhostBrickClear
{
	function servercmdClearGhostBricks(%client)
	{
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			for (%c = 0; %c < ClientGroup.getCount(); %c++)
			{
				%target = ClientGroup.getObject(%c);
				if(%target.player.tempbrick)
				{
					%target.player.tempbrick.delete();
				}
				else
				{
					messageClient(%client,'',"\c6Player \c3" @ %input @ "\c6 doesn't have a Ghost Brick");
				}
			}
		}
	}
	
	function serverCmdClearGhostBrick(%client, %input)
	{
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			%target = findclientbyname(%input);
			if(isObject(%target))
			{
				if(%target.player.tempbrick)
				{
					%target.player.tempbrick.delete();
				}
			}
			else
			{
				messageClient(%client,'',"\c6Player \c3" @ %input @ "\c6 doesn't exist");
			}
		}
	}
};
ActivatePackage(GhostBrickClear);
	