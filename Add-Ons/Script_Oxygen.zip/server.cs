//-------------------------------------------------------------
// Script_Oxygen
// Copyright (c) SolarFlare Productions, Inc.
//-------------------------------------------------------------

//-----------------------------------------------------------------------------
// Change this value to change the maximum oxygen for the server.
$maxOxygen = 100;
$oxygenState = 1; // 1=On,0=Off
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
    if(!$RTB::RTBR_ServerControl_Hook)
    {
        exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
    }
    RTB_registerPref("Toggle Oxygen","Oxygen","$oxygenState","list Off 0 On 1","Script_Oxygen",0,0,1);
    RTB_registerPref("Max Oxygen","Oxygen","$maxOxygen","int 1 500","Script_Oxygen",25,0,0);
}
package oxygen
{
    function Armor::onEnterLiquid(%this, %obj, %coverage, %type)
    {
        if($oxygenState == 1)
        {
            %obj.oxygen = $maxOxygen;
            %obj.oxygenTick = schedule(100, 0, oxygenTick, %obj);
        }
        else
        {
            %obj.oxygen = $maxOxygen;
        }
    }
    function oxygenTick(%obj)
    {
        if($oxygenState == 1)
        {
            if(!isObject(%obj))
                return;
            centerPrint(%obj.client, "<just:right>\c3Oxygen (\c6" @ %obj.oxygen--@ "\c3/\c6" @ $maxOxygen @ "\c3)", 1, 2);
            if(%obj.getWaterCoverage() $= 1)
                %obj.oxygen = %obj.oxygen;
            else
                %obj.oxygen = $maxOxygen;
                centerPrint(%obj.client, "<just:right>\c3Oxygen (\c6" @ %obj.oxygen @ "\c3/\c6" @ $maxOxygen @ "\c3)", 1, 2);
            if(%obj.oxygen <= 0)
            {
                %obj.kill();
                centerPrint(%obj.client, "<just:right>\c3Oxygen (\c0" @ %obj.oxygen @ "\c3/\c6" @ $maxOxygen @ "\c3)", 1, 2);
                return;
            }
            if(%obj.oxygen > $maxOxygen)
            {
                %obj.setOxygenLevel($maxOxygen);
            }
            %obj.oxygenTick = schedule(100, 0, oxygenTick, %obj);
        }
    }
    function Armor::onLeaveLiquid(%this, %obj, %type)
    {
        if($oxygenState == 1)
        {
            cancel(%obj.oxygenTick);
            %obj.oxygen = $maxOxygen;
            centerPrint(%obj.client, "<just:right>\c3Oxygen (\c6" @ %obj.oxygen @ "\c3/\c6" @ $maxOxygen @ "\c3)", 1, 2);
        }
    }
};
activatePackage(oxygen);

//The Slash Command to toggle, unneeded if you have RTB.
function serverCmdToggleOxygen(%client)
{
    if(%client.isSuperAdmin)
    {
        if($oxygenState == 0)
        {
            $oxygenState = 1;
            messageAll('', "\c0Oxygen has been \c3enabled\c0.");
        }
        else
        {
            $oxygenState = 0;
            messageAll('', "\c0Oxygen has been \c3disabled\c0.");	
        }
    }
}
//EVENT
function Player::setOxygenLevel(%this, %level){
%this.oxygen = %level;
}
function Player::getOxygenLevel(%this){
return %this.oxygen;
}


registerOutputEvent("Player", "SetOxygen", "int 1 500 100", 0);

function Player::setOxygen(%p,%id2){
    %p.setOxygenLevel(%id2);
}

registerOutputEvent("Player", "AddOxygen", "int -500 500 100", 0);

function Player::addOxygen(%p,%id2){
    %p.setOxygenLevel(%p.getOxygenLevel() + %id2);
}