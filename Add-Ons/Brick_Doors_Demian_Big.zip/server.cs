%error = ForceRequiredAddOn("Support_Doors");

if( %error == $Error::AddOn_NotFound )
{
	error("ERROR: Brick_Doors_Demian - required add-on Support_Doors not found");
}
else
{
	exec("./bricks/Castle.cs");
	exec("./bricks/Castle2.cs");
	exec("./bricks/Castle3.cs");
}