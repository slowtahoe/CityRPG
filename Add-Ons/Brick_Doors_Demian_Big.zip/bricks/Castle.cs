datablock fxDTSBrickData ( brickDoor_Castle_OpenCWData )
{
	brickFile = "./Castle_openCW.blb";
	uiName = "Castle Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Castle_ClosedCWData";
	openCW = "brickDoor_Castle_OpenCWData";
	
	closedCCW = "brickDoor_Castle_ClosedCWData";
	openCCW = "brickDoor_Castle_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Castle_OpenCCWData : brickDoor_Castle_OpenCWData )
{
	brickFile = "./Castle_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Castle_ClosedCWData : brickDoor_Castle_OpenCWData )
{
	brickFile = "./Castle_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Big/bricks/Castle";

	isOpen = 0;
};