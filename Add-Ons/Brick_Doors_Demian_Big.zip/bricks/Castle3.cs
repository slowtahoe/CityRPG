datablock fxDTSBrickData ( brickDoor_Castle3_OpenCWData )
{
	brickFile = "./Castle3_open.blb";
	uiName = "Castle Door 3";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Castle3_ClosedCWData";
	openCW = "brickDoor_Castle3_OpenCWData";
	
	closedCCW = "brickDoor_Castle3_ClosedCWData";
	openCCW = "brickDoor_Castle3_OpenCWData";
};

//Default state
datablock fxDTSBrickData ( brickDoor_Castle3_ClosedCWData : brickDoor_Castle3_OpenCWData )
{
	brickFile = "./Castle3_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Big/bricks/Castle3";

	isOpen = 0;
};