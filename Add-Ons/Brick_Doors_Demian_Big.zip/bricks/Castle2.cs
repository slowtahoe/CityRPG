datablock fxDTSBrickData ( brickDoor_Castle2_OpenCWData )
{
	brickFile = "./Castle2_openCW.blb";
	uiName = "Castle Door 2";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Castle2_ClosedCWData";
	openCW = "brickDoor_Castle2_OpenCWData";
	
	closedCCW = "brickDoor_Castle2_ClosedCWData";
	openCCW = "brickDoor_Castle2_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Castle2_OpenCCWData : brickDoor_Castle2_OpenCWData )
{
	brickFile = "./Castle2_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Castle2_ClosedCWData : brickDoor_Castle2_OpenCWData )
{
	brickFile = "./Castle2_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Big/bricks/Castle2";

	isOpen = 0;
};