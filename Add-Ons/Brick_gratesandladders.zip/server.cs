datablock fxDTSBrickData (brickLadderData) {
	brickfile = "./Ladder.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Ladder";
	iconName = "base/Unknown.png";
};


datablock fxDTSBrickData (brickGrate4xData) {
	brickfile = "./Grate4x.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Grate4x";
	iconName = "base/Unknown.png";
};


datablock fxDTSBrickData (brickLaddertopData) {
	brickfile = "./Laddertop.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Laddertop";
	iconName = "base/Unknown.png";
};


datablock fxDTSBrickData (brickGrillver4x3Data) {
	brickfile = "./Grillver4x3.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Grillver4x3";
	iconName = "base/Unknown.png";
};



datablock fxDTSBrickData (brickGrill2x2Data) {
	brickfile = "./Grill2x2.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Grill2x2";
	iconName = "base/Unknown.png";
};


datablock fxDTSBrickData (brickGrill1x2Data) {
	brickfile = "./Grill1x2.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Grill1x2";
	iconName = "base/Unknown.png";
};



datablock fxDTSBrickData (brickFittedvergrill4x3Data) {
	brickfile = "./Fittedvergrill4x3.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "Fittedvergrill4x3";
	iconName = "base/Unknown.png";
};



datablock fxDTSBrickData (brickPlateLadderData) {
	brickfile = "./PlateLadder.blb";
	category = "Special";
	subcategory = "GratesAndLadders";
	uiname = "PlateLadder";
	iconName = "base/Unknown.png";
};