datablock fxDTSBrickData (BrickSignStopData)
{
	brickFile = "./stopsign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Stop Sign";
	collisionShapeName = "./squarecol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/stopsign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignRoundData)
{
	brickFile = "./roundsign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Round Sign";
	collisionShapeName = "./squarecol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/roundsign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignTriangleData)
{
	brickFile = "./trianglesign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Triangle Sign";
	collisionShapeName = "./tcol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/trianglesign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignSquareData)
{
	brickFile = "./squaresign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Square Sign";
	collisionShapeName = "./squarecol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/squaresign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignRectangleData)
{
	brickFile = "./rectanglesign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Rectangle Sign";
	collisionShapeName = "./rectanglecol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/rectanglesign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignYieldData)
{
	brickFile = "./yieldsign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Yield Sign";
	collisionShapeName = "./yieldcol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/yieldsign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData (BrickSignDiamondData)
{
	brickFile = "./diamondsign.blb";
	category = "Special";
	subCategory = "Signs";
	uiName = "Diamond Sign";
	collisionShapeName = "./squarecol.dts";
	iconName = "Add-Ons/Brick_Road_Sign/diamondsign";
	orientationFix = 1;
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};