%error = ForceRequiredAddOn("Support_Doors");

if( %error == $Error::AddOn_NotFound )
{
	error("ERROR: Brick_Doors_Demian_Thematic - required add-on Support_Doors not found");
}
else
{
	exec("./bricks/CleanRoom.cs");
	exec("./bricks/Curtain.cs");
	exec("./bricks/DoubleCurtains.cs");
	exec("./bricks/Lab.cs");
	exec("./bricks/Lab2.cs");
	exec("./bricks/Locker.cs");
}