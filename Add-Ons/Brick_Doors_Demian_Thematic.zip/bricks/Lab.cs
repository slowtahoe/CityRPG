datablock fxDTSBrickData ( brickDoor_Lab_OpenCWData )
{
	brickFile = "./Lab_openCW.blb";
	uiName = "Lab Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Lab_ClosedCWData";
	openCW = "brickDoor_Lab_OpenCWData";
	
	closedCCW = "brickDoor_Lab_ClosedCWData";
	openCCW = "brickDoor_Lab_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Lab_OpenCCWData : brickDoor_Lab_OpenCWData )
{
	brickFile = "./Lab_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Lab_ClosedCWData : brickDoor_Lab_OpenCWData )
{
	brickFile = "./Lab_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/Lab";

	isOpen = 0;
};