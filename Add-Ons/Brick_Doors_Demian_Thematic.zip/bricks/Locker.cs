datablock fxDTSBrickData ( brickDoor_Locker_OpenCWData )
{
	brickFile = "./Locker_openCW.blb";
	uiName = "Locker Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Locker_ClosedCWData";
	openCW = "brickDoor_Locker_OpenCWData";
	
	closedCCW = "brickDoor_Locker_ClosedCCWData";
	openCCW = "brickDoor_Locker_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Locker_OpenCCWData : brickDoor_Locker_OpenCWData )
{
	brickFile = "./Locker_openCCW.blb";
	isOpen = 1;
};

datablock fxDTSBrickData ( brickDoor_Locker_ClosedCCWData : brickDoor_Locker_OpenCWData )
{
	brickFile = "./Locker_closedCCW.blb";
	isOpen = 0;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Locker_ClosedCWData : brickDoor_Locker_OpenCWData )
{
	brickFile = "./Locker_closedCW.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/Locker";

	isOpen = 0;
};