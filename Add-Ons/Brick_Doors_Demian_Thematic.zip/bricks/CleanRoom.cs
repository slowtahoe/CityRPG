datablock fxDTSBrickData ( brickDoor_CleanRoom_OpenCWData )
{
	brickFile = "./CleanRoom_openCW.blb";
	uiName = "Clean Room Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_CleanRoom_ClosedCWData";
	openCW = "brickDoor_CleanRoom_OpenCWData";
	
	closedCCW = "brickDoor_CleanRoom_ClosedCWData";
	openCCW = "brickDoor_CleanRoom_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_CleanRoom_OpenCCWData : brickDoor_CleanRoom_OpenCWData )
{
	brickFile = "./CleanRoom_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_CleanRoom_ClosedCWData : brickDoor_CleanRoom_OpenCWData )
{
	brickFile = "./CleanRoom_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/CleanRoom";

	isOpen = 0;
};