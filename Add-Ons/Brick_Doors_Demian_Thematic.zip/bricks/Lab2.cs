datablock fxDTSBrickData ( brickDoor_Lab2_OpenCWData )
{
	brickFile = "./Lab2_openCW.blb";
	uiName = "Lab Door 2";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Lab2_ClosedCWData";
	openCW = "brickDoor_Lab2_OpenCWData";
	
	closedCCW = "brickDoor_Lab2_ClosedCWData";
	openCCW = "brickDoor_Lab2_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Lab2_OpenCCWData : brickDoor_Lab2_OpenCWData )
{
	brickFile = "./Lab2_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Lab2_ClosedCWData : brickDoor_Lab2_OpenCWData )
{
	brickFile = "./Lab2_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/Lab2";

	isOpen = 0;
};