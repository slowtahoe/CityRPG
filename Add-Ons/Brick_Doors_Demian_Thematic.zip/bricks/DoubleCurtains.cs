datablock fxDTSBrickData ( brickDoor_DoubleCurtains_OpenCWData )
{
	brickFile = "./DoubleCurtains_open.blb";
	uiName = "Double Curtains Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_DoubleCurtains_ClosedCWData";
	openCW = "brickDoor_DoubleCurtains_OpenCWData";
	
	closedCCW = "brickDoor_DoubleCurtains_ClosedCWData";
	openCCW = "brickDoor_DoubleCurtains_OpenCWData";
};

//Default state
datablock fxDTSBrickData ( brickDoor_DoubleCurtains_ClosedCWData : brickDoor_DoubleCurtains_OpenCWData )
{
	brickFile = "./Curtain_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/DoubleCurtains";

	isOpen = 0;
};