datablock fxDTSBrickData ( brickDoor_Curtain_OpenCWData )
{
	brickFile = "./Curtain_openCW.blb";
	uiName = "Curtain Door";

	isDoor = 1;
	isOpen = 1;

	closedCW = "brickDoor_Curtain_ClosedCWData";
	openCW = "brickDoor_Curtain_OpenCWData";
	
	closedCCW = "brickDoor_Curtain_ClosedCWData";
	openCCW = "brickDoor_Curtain_OpenCCWData";
};

datablock fxDTSBrickData ( brickDoor_Curtain_OpenCCWData : brickDoor_Curtain_OpenCWData )
{
	brickFile = "./Curtain_openCCW.blb";
	isOpen = 1;
};

//Default state
datablock fxDTSBrickData ( brickDoor_Curtain_ClosedCWData : brickDoor_Curtain_OpenCWData )
{
	brickFile = "./Curtain_closed.blb";

	category = "Special";
	subCategory = "Doors";
	
	iconName = "Add-Ons/Brick_Doors_Demian_Thematic/bricks/Curtain";

	isOpen = 0;
};