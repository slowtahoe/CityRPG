datablock fxDTSBrickData (brickGuardrail8xData)
{
	brickFile = "Add-Ons/Brick_Guardrail/Bricks/Guardrail8x.blb";
	category = "Special";
	subcategory = "Highway";
	uiName = "Guardrail 8x";                  
	iconName = "Add-Ons/Brick_Guardrail/Icons/Guardrail";
};

datablock fxDTSBrickData (brickGuardrail16xData)
{
	brickFile = "Add-Ons/Brick_Guardrail/Bricks/Guardrail16x.blb";
	category = "Special";
	subcategory = "Highway";
	uiName = "Guardrail 16x";                  
	iconName = "Add-Ons/Brick_Guardrail/Icons/Guardrail";
};

datablock fxDTSBrickData (brickGuardrail64xData)
{
	brickFile = "Add-Ons/Brick_Guardrail/Bricks/Guardrail64x.blb";
	category = "Special";
	subcategory = "Highway";
	uiName = "Guardrail 64x";                  
	iconName = "Add-Ons/Brick_Guardrail/Icons/Guardrail";
};

datablock fxDTSBrickData (brickGuardrailEndLData)
{
	brickFile = "Add-Ons/Brick_Guardrail/Bricks/GuardrailEndL.blb";
	category = "Special";
	subcategory = "Highway";
	uiName = "Guardrail End L";                  
	iconName = "Add-Ons/Brick_Guardrail/Icons/GuardrailEndL";
};

datablock fxDTSBrickData (brickGuardrailEndRData)
{
	brickFile = "Add-Ons/Brick_Guardrail/Bricks/GuardrailEndR.blb";
	category = "Special";
	subcategory = "Highway";
	uiName = "Guardrail End R";                  
	iconName = "Add-Ons/Brick_Guardrail/Icons/GuardrailEndR";
};