//JVS Door Fix
//Author: Gothboy77 BLID 14329
//Fixes JVS doors not properly loading with raycasting and collision
//------------------------------------------------------------------
package JVS_DoorFix
{			
	function serverLoadSaveFile_End()
	{
		%parent = parent::serverLoadSaveFile_End();

	    %count = $LoadingBricks_BrickGroup.getCount();
        if(%count < 1) 
			return;
        
		for(%i=0;%i<%count;%i++)
        {
			%brick = $LoadingBricks_BrickGroup.getObject(%i);
		
			if(%brick.getDatablock().isJVS)
			{
				%brick.setRaycasting(1);
				%brick.setColliding(1);
			}
        }
		return %parent;
	}
};
activatePackage(JVS_DoorFix);
