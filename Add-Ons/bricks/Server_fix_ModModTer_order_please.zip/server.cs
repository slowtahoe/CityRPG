//function made by eagle517, thanks eagle517
function isAddOnEnabled(%addOnName)
{
	if ($GameModeArg $= "")
		return $AddOn__[getSafeVariableName(%addOnName)] == 1;
	else {
		%count = $GameMode::AddOnCount;
		for (%i = 0; %i < %count; %i++) {
			if ($GameMode::AddOn[%i] $= %addOnName)
				return true;
		}
	}

	return false;
}

if(isObject(brick32WedgeLongL5Data) || isObject(brick64Cube1Data) || isObject(brick64Ramp1InvData) || isObject(brick4Cube1Data) || isObject(brick16ChiselL1Data) || isObject(brick16CornerC90L1Data) || isObject(brickModter2x4x10CubeData) || isObject(brick8cWatertestData))
{
	schedule(1000, 0, messageAll, '', "ERROR: Place \"fix ModModTer order please\" before all ModTer packs in the gamemode.txt file!");
	return;
}

if(!isAddOnEnabled("Brick_ModModTer"))
{
	schedule(1000, 0, messageAll, '', "ERROR: why are you running \"fix ModModTer order please\" without ModModTer, you buffoon");
	return;
}

//fix the order
exec("./64x.cs");
exec("./32x.cs");
exec("./16x.cs");
exec("./8x.cs");
exec("./4x.cs");
exec("./4xfix.cs");
exec("./2x.cs");
exec("./2xfix.cs");
exec("./64xinv.cs");
exec("./32xinv.cs");
exec("./16xinv.cs");
exec("./8xinv.cs");
exec("./4xinv.cs");
exec("./4xinvfix.cs");
exec("./2xinv.cs");
exec("./2xinvfix.cs");
exec("./32xlong.cs");
exec("./16xlong.cs");
exec("./8xlong.cs");
exec("./4xlong.cs");
exec("./4xlongfix.cs");
exec("./2xlong.cs");
exec("./2xlongfix.cs");
exec("./32xlonginv.cs");
exec("./16xlonginv.cs");
exec("./8xlonginv.cs");
exec("./4xlonginv.cs");
exec("./4xlonginvfix.cs");
exec("./2xlonginv.cs");
exec("./2xlonginvfix.cs");
exec("./ramps.cs");

//and then some
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brickModter2x4x10CubeData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Filler";
		uiName = "Filler Category Dummy";
	};
	datablock fxDTSBrickData(brickModter2xto4xAdapterLData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Adapter";
		uiName = "Adapter Category Dummy";
	};
	datablock fxDTSBrickData(brickModter2x2FenceEnddata)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Fence";
		uiName = "Fence Category Dummy";
	};
	datablock fxDTSBrickData(brickModter4x12x10BenchData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Street Props";
		uiName = "Street Props Category Dummy";
	};
	datablock fxDTSBrickData(brickModter8x8x5RailroadData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Railroad";
		uiName = "Railroad Category Dummy";
	};
	datablock fxDTSBrickData(brickModter2x4x10CubeData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Misc";
		uiName = "Misc. Category Dummy";
	};
}
if(isAddOnEnabled("Brick_ModTer_DecorPack") && isFile("Add-Ons/Brick_ModTer_DecorPack/server.cs"))
{
	datablock fxDTSBrickData(brick8cWatertestData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "Decor";
		uiName = "Decor Category Dummy";
	};
}
