datablock fxDTSBrickData(brick16Cube5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Category Dummy";
};
datablock fxDTSBrickData(brick16Wedge5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cWSteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Wedge Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cWSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cWSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cRSteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Ramp Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cRSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cCASteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerA Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cCASteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cCASteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cCBSteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerB Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cCBSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cCBSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cCCSteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerC Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cCCSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cCCSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/16cCDSteep.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerD Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/16cCDSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/16cCDSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Cube1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16c.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Cube ";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Wedge1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cW.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Wedge";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cW";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cWCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cR.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Ramp";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cR";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cCA.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerA";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cCA";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cCACol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cCB.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerB";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cCB";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cCBCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cCC.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerC";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cCC";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cCCCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/16cCD.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerD";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/16cCD";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/16cCDCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Cube2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16c3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Cube 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16c3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16c3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Wedge2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cW3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Wedge 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cW3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cW3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cR3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cR3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cCA3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerA 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cCA3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cCA3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cCB3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerB 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cCB3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cCB3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cCC3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerC 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cCC3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cCC3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/16cCD3-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerD 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/16cCD3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/16cCD3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Cube3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16c1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Cube 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16c1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16c1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Wedge3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cW1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Wedge 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cW1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cW1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cR1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cR1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cCA1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerA 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cCA1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cCA1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cCB1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerB 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cCB1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cCB1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cCC1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerC 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cCC1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cCC1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/16cCD1-2.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerD 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/16cCD1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/16cCD1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Cube4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16c1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Cube 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16c1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16c1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Wedge4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cW1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Wedge 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cW1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cW1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cR1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cR1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cCA1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerA 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cCA1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cCA1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cCB1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerB 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cCB1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cCB1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cCC1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerC 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cCC1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cCC1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/16cCD1-4.blb";
	category = "ModTer";
	subCategory = "16x";
	uiName = "16x CornerD 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/16cCD1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/16cCD1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brickModter16x16x5CubeData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCD1-4.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x CornerD 1/4h";
	        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCD1-4";
	        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCD1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16cW1-8.blb";
		category = "ModTer";
		subCategory = "16x";
		uiName = "16x Wedge 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
