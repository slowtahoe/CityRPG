datablock fxDTSBrickData(brick32WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongWedge L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongWedge R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongCornerA L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongCornerA R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongCornerB L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "741x LongCornerB R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "741x LongCornerC L Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "741x LongCornerC R Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "741x LongCornerD L Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "741x LongCornerD R Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick32WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "154x LongCornerC L";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "154x LongCornerC R";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "154x LongCornerD L";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "154x LongCornerD R";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick32WedgeLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongWedge R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerA R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "154x LongCornerB R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};

if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick32WedgeLongL6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-8.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "645x LongWedge L 1/8h";
	        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-8";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongR6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-8.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "645x LongWedge R 1/8h";
	        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-8";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongL7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-16.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "645x LongWedge L 1/16h";
	        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-16";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-16Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongR7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-16.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "645x LongWedge R 1/16h";
	        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-16";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-16Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
