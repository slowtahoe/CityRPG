if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick64Ramp1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "64x Inv";
	uiName = "64x Inv. Category Dummy";
};
datablock fxDTSBrickData(brick64CornerA1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/64cCAinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorA Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/64cCAinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/64cCAinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/64cCBinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorB Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/64cCBinv";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/64cCBinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/64cCCinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorC Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/64cCCinv";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/64cCCinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/64cCDinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorD Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/64cCDinv";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/64cCDinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/64cRinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x Ramp 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/64cRinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/64cRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/64cCAinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorA 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/64cCAinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/64cCAinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/64cCBinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorB 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/64cCBinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/64cCBinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/64cCCinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorC 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/64cCCinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/64cCCinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/64cCDinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorD 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/64cCDinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/64cCDinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/64cRinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x Ramp 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/64cRinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/64cRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/64cCAinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorA 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/64cCAinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/64cCAinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/64cCBinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorB 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/64cCBinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/64cCBinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/64cCCinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorC 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/64cCCinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/64cCCinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/64cCDinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorD 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/64cCDinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/64cCDinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/64cRinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x Ramp 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/64cRinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/64cRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/64cCAinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorA 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/64cCAinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/64cCAinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/64cCBinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorB 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/64cCBinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/64cCBinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/64cCCinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorC 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/64cCCinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/64cCCinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/64cCDinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x Inv";
	uiName = "64x CorD 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/64cCDinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/64cCDinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
