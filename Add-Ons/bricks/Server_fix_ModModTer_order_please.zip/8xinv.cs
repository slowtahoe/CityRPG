if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick8Ramp5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "8x Inv";
	uiName = "8x Inv. Category Dummy";
};
datablock fxDTSBrickData(brick8CornerA5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/8cCAinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorA Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCAinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/8cCAinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/8cCBinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorB Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCBinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/8cCBinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/8cCCinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorC Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCCinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/8cCCinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/8cCDinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorD Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCDinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/8cCDinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/8cRinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x Ramp Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cRinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/8cRinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/8cCAinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorA Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCAinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/8cCAinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/8cCBinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorB Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCBinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/8cCBinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/8cCCinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorC inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCCinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/8cCCinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/8cCDinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorD Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCDinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/8cCDinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/8cRinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x Ramp 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/8cRinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/8cRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/8cCAinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorA 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/8cCAinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/8cCAinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/8cCBinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorB 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/8cCBinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/8cCBinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/8cCCinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorC 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/8cCCinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/8cCCinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/8cCDinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorD 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/8cCDinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/8cCDinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/8cRinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x Ramp 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cRinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/8cRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/8cCAinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorA 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCAinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/8cCAinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/8cCBinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorB 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCBinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/8cCBinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/8cCCinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorC 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCCinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/8cCCinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/8cCDinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorD 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCDinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/8cCDinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/8cRinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x Ramp 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/8cRinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/8cRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/8cCAinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorA 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/8cCAinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/8cCAinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/8cCBinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorB 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/8cCBinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/8cCBinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/8cCCinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorC 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/8cCCinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/8cCCinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/8cCDinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x Inv";
	uiName = "8x CorD 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/8cCDinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/8cCDinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
