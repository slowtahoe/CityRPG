if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brick2WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongWedge L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongWedge R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongCornerA L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongCornerA R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongCornerB L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "741x LongCornerB R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongWedge L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongWedge R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongCornerA L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongCornerA R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongCornerB L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "154x LongCornerB R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
