datablock fxDTSBrickData(brick64Cube1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "64x";
	uiName = "234x Category Dummy";
};
datablock fxDTSBrickData(brick64Wedge1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cW.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Wedge";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cW";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cWCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cR.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Ramp";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cR";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cCA.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerA";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cCA";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cCACol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cCB.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerB";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cCB";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cCBCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cCC.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerC";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cCC";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cCCCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64cCD.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerD";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/64cCD";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/64cCDCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Cube2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64c3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Cube 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64c3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64c3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Wedge2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cW3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Wedge 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cW3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cW3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cR3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Ramp 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cR3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cCA3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerA 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cCA3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cCA3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cCB3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerB 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cCB3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cCB3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cCC3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerC 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cCC3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cCC3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/64cCD3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerD 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/64cCD3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/64cCD3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Cube3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64c1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Cube 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64c1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64c1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Wedge3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cW1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Wedge 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cW1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cW1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cR1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Ramp 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cR1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cCA1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerA 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cCA1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cCA1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cCB1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerB 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cCB1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cCB1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cCC1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerC 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cCC1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cCC1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/64cCD1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerD 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/64cCD1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/64cCD1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Cube4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64c1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Cube 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64c1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64c1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Wedge4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cW1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Wedge 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cW1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cW1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cR1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x Ramp 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cR1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerA4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cCA1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerA 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cCA1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cCA1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerB4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cCB1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerB 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cCB1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cCB1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerC4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cCC1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerC 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cCC1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cCC1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64CornerD4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/64cCD1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 64x";
	uiName = "234x CornerD 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/64cCD1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/64cCD1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick64Cube6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-8.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Cube 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-8.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Wedge 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Cube7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-16.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Cube 1/16h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-16.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Wedge 1/16h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Cube8Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-32.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Cube 1/32h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge8Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-32.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "234x Wedge 1/32h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
