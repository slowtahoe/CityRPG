if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4CornerALongL5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
// datablock fxDTSBrickData(brick4CornerCLongL5invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerC L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerCLongR5invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerC R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongL5invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerD L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongR5invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerD R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
	datablock fxDTSBrickData(brick4CornerALongL1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
// datablock fxDTSBrickData(brick4CornerCLongL1invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerC L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerCLongR1invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerC R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongL1invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerD L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongR1invFixedData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long Inv";
// 	uiName = "444x LongCornerD R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4CornerALongL3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerA R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "444x LongCornerB R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
