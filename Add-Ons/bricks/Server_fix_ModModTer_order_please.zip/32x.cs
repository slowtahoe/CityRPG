datablock fxDTSBrickData(brick32Cube5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Category Dummy";
};
datablock fxDTSBrickData(brick32Wedge5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cWSteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Wedge Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cWSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cWSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cRSteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Ramp Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cRSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cCASteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerA Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cCASteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cCASteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cCBSteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerB Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cCBSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cCBSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cCCSteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerC Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cCCSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cCCSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/32cCDSteep.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerD Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/32cCDSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/32cCDSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Cube1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32c.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Cube ";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Wedge1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cW.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Wedge";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cW";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cWCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cR.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Ramp";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cR";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cCA.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerA";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cCA";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cCACol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cCB.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerB";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cCB";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cCBCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cCC.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerC";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cCC";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cCCCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/32cCD.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerD";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/32cCD";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/32cCDCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Cube2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32c3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Cube 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32c3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32c3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Wedge2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cW3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Wedge 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cW3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cW3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cR3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cR3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cCA3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerA 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cCA3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cCA3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cCB3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerB 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cCB3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cCB3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cCC3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerC 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cCC3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cCC3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/32cCD3-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerD 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/32cCD3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/32cCD3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Cube3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32c1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Cube 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32c1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32c1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Wedge3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cW1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Wedge 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cW1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cW1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cR1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cR1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cCA1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerA 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cCA1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cCA1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cCB1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerB 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cCB1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cCB1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cCC1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerC 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cCC1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cCC1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/32cCD1-2.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerD 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/32cCD1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/32cCD1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Cube4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32c1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Cube 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32c1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32c1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Wedge4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cW1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Wedge 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cW1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cW1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cR1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cR1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCA1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerA 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCA1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCA1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCB1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerB 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCB1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCB1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCC1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerC 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCC1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCC1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCD1-4.blb";
	category = "ModTer";
	subCategory = "32x";
	uiName = "32x CornerD 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCD1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCD1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick32Cube6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32c1-8.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Cube 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32cW1-8.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Wedge 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brickModter32x32x5CubeData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/32cCD1-4.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x CornerD 1/4h";
	        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/32cCD1-4";
	        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/32cCD1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32Wedge7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32cW1-16.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Wedge 1/16h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64xFiller/64xCube1-32";
	        //collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64xFiller/64xCube1-32Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
