if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x Inv. Category Dummy";
	};
	datablock fxDTSBrickData(brick4CornerA5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCAinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = " 4x CornerA Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = " 4x CornerB Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = " 4x CornerC Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = " 4x CornerD Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp1invData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x Inv. Category Dummy 2";
	};
	datablock fxDTSBrickData(brick4CornerA1invData)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCAinv.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CornerA Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCAinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCAinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB1invData)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCBinv.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CornerB Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCBinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC1invData)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCCinv.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CornerC Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCCinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD1invData)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCDinv.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CornerD Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCDinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brickModter4x4x5RampInvdata)
	{
		uiName = "4x Ramp Inv 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Ramp Inv";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Ramp Inv.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5SlantDowndata)
	{
		uiName = "4x Slant- 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Slant-";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Slant-.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5SlantDownInvdata)
	{
		uiName = "4x Slant- Inv 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Slant- Inv";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Slant- Inv.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5CornerDowndata)
	{
		uiName = "4x Corner- 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Corner-";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Corner-.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5CornerDownInvdata)
	{
		uiName = "4x Corner- Inv 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Corner- Inv";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Corner- Inv.dts";
	};
}
