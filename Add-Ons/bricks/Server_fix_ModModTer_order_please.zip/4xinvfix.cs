if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4Ramp5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x Ramp Steep Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cRinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCAinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorA Steep Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorB Steep Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorC Steep Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorD Steep Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brick4Ramp1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cRinv.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x Ramp Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cRinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCAinv.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorA Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCAinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCAinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCBinv.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorB Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCBinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCCinv.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorC Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCCinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCDinv.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CorD Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCDinv";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4Ramp3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x Ramp 1/2h Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCAinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CornerA 1/2h Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CornerB 1/2h Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CornerC 1/2h Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "711x CornerD 1/2h Inv. Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
