datablock fxDTSBrickData(brick16WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongWedge L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongWedge R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongCornerA L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongCornerA R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongCornerB L Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "741x LongCornerB R Steep";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "741x LongCornerC L Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "741x LongCornerC R Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "741x LongCornerD L Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "741x LongCornerD R Steep";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick16WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB L";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB R";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "154x LongCornerC L";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "154x LongCornerC R";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "154x LongCornerD L";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "154x LongCornerD R";
//         //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick16WedgeLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB L 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB R 3/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB L 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB R 1/2h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongWedge R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerA R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB L 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "154x LongCornerB R 1/4h";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};

if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick16WedgeLongL6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-4.blb";
		category = "ModTer 2";
		subCategory = "16x Long";
		uiName = "154x LongWedge L 1/8h";
	        ////iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-4";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWL1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16WedgeLongR6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-4.blb";
		category = "ModTer 2";
		subCategory = "16x Long";
		uiName = "154x LongWedge R 1/8h";
	        ////iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-4";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWR1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
