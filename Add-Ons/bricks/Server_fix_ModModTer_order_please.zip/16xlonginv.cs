if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick16CornerALongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinvSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinvSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinvSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinvSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerC L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerC R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerD L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerD R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick16CornerALongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv.blb";
	category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerC L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerC R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerD L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long Inv";
// 	uiName = "444x LongCornerD R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick16CornerALongL2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA L 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA R 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB L 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB R 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA L 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA R 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB L 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB R 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA L 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerA R 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB L 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "16x Long Inv";
	uiName = "444x LongCornerB R 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
