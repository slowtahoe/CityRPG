if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick16Ramp5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "16x Inv";
	uiName = "16x Inv. Category Dummy";
};
datablock fxDTSBrickData(brick16CornerA5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/16cCAinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorA Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/16cCAinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/16cCAinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/16cCBinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorB Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/16cCBinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/16cCBinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/16cCCinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorC Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/16cCCinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/16cCCinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/16cCDinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorD Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/16cCDinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/16cCDinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/16cRinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x Ramp Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/16cRinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/16cRinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/16cCAinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorA Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/16cCAinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/16cCAinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/16cCBinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorB Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/16cCBinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/16cCBinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/16cCCinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorC Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/16cCCinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/16cCCinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/16cCDinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorD Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/16cCDinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/16cCDinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/16cRinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x Ramp 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/16cRinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/16cRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/16cCAinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorA 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/16cCAinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/16cCAinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/16cCBinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorB 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/16cCBinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/16cCBinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/16cCCinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorC 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/16cCCinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/16cCCinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/16cCDinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorD 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/16cCDinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/16cCDinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/16cRinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x Ramp 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/16cRinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/16cRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/16cCAinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorA 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/16cCAinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/16cCAinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/16cCBinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorB 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/16cCBinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/16cCBinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/16cCCinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorC 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/16cCCinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/16cCCinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/16cCDinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorD 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/16cCDinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/16cCDinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16Ramp4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/16cRinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x Ramp 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/16cRinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/16cRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerA4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/16cCAinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorA 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/16cCAinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/16cCAinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerB4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/16cCBinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorB 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/16cCBinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/16cCBinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerC4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/16cCCinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorC 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/16cCCinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/16cCCinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerD4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/16cCDinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 16x Inv";
	uiName = "16x CorD 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/16cCDinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/16cCDinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
