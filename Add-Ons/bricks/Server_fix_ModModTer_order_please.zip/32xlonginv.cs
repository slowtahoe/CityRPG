if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick32CornerALongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinvSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinvSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinvSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinvSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerC L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerC R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerD L Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR5invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinvSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerD R Steep Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick32CornerALongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv.blb";
	category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerC L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerC R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerD L Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR1invData)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinv.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long Inv";
// 	uiName = "444x LongCornerD R Inv.";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick32CornerALongL2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA L 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA R 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB L 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR2invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv3-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB R 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv3-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA L 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA R 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB L 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR3invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-2.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB R 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA L 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerA R 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB L 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR4invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-4.blb";
	Category = "ModTer 2";
	subCategory = "32x Long Inv";
	uiName = "444x LongCornerB R 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-4";
		//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
