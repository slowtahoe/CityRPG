if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brick2Cube5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Cube Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Wedge5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cWSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Wedge Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Ramp Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCASteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerA Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerB Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerC Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerD Steep Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Cube1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Cube Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Wedge1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cWFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Wedge Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x Ramp Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerA Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerB Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerC Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = "649x CornerD Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
