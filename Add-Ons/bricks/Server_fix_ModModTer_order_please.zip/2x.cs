if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brickModter2x2x10Cubedata)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x";
	uiName = "2x Category Dummy";
};
datablock fxDTSBrickData(brick2Wedge5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cWSteep.blb";
	category = "ModTer";
	subCategory = "2x";
	uiName = "2x Wedge Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/2xFiller/2xRampSteep";
        ////collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xFiller/2xRampSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x";
	uiName = "2x Category Dummy 2";
};
datablock fxDTSBrickData(brick2CornerA5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCASteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerA Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		////collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerB5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCBSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerB Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		////collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerC5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCCSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerC Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		////collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerD5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCDSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerD Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		////collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
datablock fxDTSBrickData(brickModter2x2x5Cubedata)
{
	uiName = "2x Cube ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Cube";

	hasPrint = 1;
	printAspectRatio = "ModTer";
};

datablock fxDTSBrickData(brickModter2x2x5Wedgedata)
{
	uiName = "2x Wedge ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Wedge";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Wedge.dts";
};

datablock fxDTSBrickData(brickModter2x2x5Rampdata)
{
	uiName = "2x Ramp ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Ramp";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Ramp.dts";
};

datablock fxDTSBrickData(brickModter2x2x5SlantUpdata)
{
	uiName = "2x Slant+ ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Slant+";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Slant+.dts";
};

datablock fxDTSBrickData(brickModter2x2x5SlantUpInvdata)
{
	uiName = "2x Slant+ Inv ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Slant+ Inv";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Slant+ Inv.dts";
};

datablock fxDTSBrickData(brickModter2x2x5CornerUpdata)
{
	uiName = "2x Corner+ ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Corner+";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Corner+.dts";
};

datablock fxDTSBrickData(brickModter2x2x5CornerUpInvdata)
{
	uiName = "2x Corner+ Inv ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Corner+ Inv";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	////collisionShapeName = "./collision/Corner+ Inv.dts";
};
