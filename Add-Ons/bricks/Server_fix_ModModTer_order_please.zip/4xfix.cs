if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4Cube5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Category Dummy";
	};
	datablock fxDTSBrickData(brick4Wedge5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cWSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Wedge Steep Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Category Dummy 2";
	};
	datablock fxDTSBrickData(brick4CornerA5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCASteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerA Steep Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerB Steep Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerC Steep Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerD Steep Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Cube1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4c.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Cube Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cW.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Wedge Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cR.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Ramp Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cR";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCA.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerA Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCA";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCACol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCB.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerB Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCB";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCC.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerC Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCC";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/4xFix/4cCD.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerD Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCD";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4Cube3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4c1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Cube 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cW1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Wedge 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cR1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x Ramp 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCA1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerA 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCB1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerB 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCC1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerC 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCD1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "751x CornerD 1/2h Fixed";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
