datablock fxDTSBrickData(brick8Cube5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "8x";
	uiName = "8x Category Dummy";
};
datablock fxDTSBrickData(brick8Wedge5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cWSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Wedge Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cWSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cWSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cRSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Ramp Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cRSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cCASteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerA Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCASteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cCASteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cCBSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerB Steep";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCBSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cCBSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cCCSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerC Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCCSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cCCSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD5Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Steep/8cCDSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerD Steep";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCDSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Steep/8cCDSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Cube1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8c.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Cube ";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Wedge1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cW.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Wedge";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cW";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cWCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cR.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Ramp";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cR";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cCA.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerA";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCA";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cCACol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cCB.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerB";
	iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCB";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cCBCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cCC.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerC";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCC";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cCCCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD1Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/8cCD.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerD";
        iconName = "Add-ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCD";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/Full/8cCDCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Cube2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8c3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Cube 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8c3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8c3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Wedge2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cW3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Wedge 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cW3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cW3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cR3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cR3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cCA3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerA 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cCA3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cCA3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cCB3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerB 3/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cCB3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cCB3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cCC3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerC 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cCC3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cCC3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD2Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/3-4/8cCD3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerD 3/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/3-4/8cCD3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/3-4/8cCD3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Cube3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8c1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Cube 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8c1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8c1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Wedge3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cW1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Wedge 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cW1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cW1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cR1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cR1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cCA1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerA 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCA1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cCA1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cCB1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerB 1/2h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCB1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cCB1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cCC1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerC 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCC1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cCC1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD3Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-2/8cCD1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerD 1/2h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCD1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-2/8cCD1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Cube4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8c1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Cube 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8c1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8c1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Wedge4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cW1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Wedge 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cW1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cW1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cR1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cR1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerA4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cCA1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerA 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cCA1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cCA1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerB4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cCB1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerB 1/4h";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cCB1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cCB1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerC4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cCC1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerC 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cCC1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cCC1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerD4Data)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/1-4/8cCD1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 8x";
	uiName = "8x CornerD 1/4h";
        iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-4/8cCD1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_BasicPack/Shapes/1-4/8cCD1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};