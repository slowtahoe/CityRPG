if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brickModter4x4x20Cubedata)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Category Dummy";
	};
	datablock fxDTSBrickData(brick4Wedge5Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = " 4x Wedge Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Category Dummy 2";
	};
	datablock fxDTSBrickData(brick4CornerA5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCASteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = " 4x CornerA Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = " 4x CornerB Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = " 4x CornerC Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = " 4x CornerD Steep";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Cube1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4c.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Cube";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cW.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Wedge";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cR.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Ramp";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cR";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCA.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerA";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCA";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCACol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCB.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerB";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCB";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCC.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerC";
	        iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCC";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD1Data)
	{
		brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCD.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerD";
	        iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCD";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brickModter4x4x5Cubedata)
	{
		uiName = "4x Cube 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Cube";

		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brickModter4x4x5Wedgedata)
	{
		uiName = "4x Wedge 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Wedge";

		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brickModter4x4x5Rampdata)
	{
		uiName = "4x Ramp 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Ramp";

		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brickModter4x4x5SlantUpdata)
	{
		uiName = "4x Slant+ 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Slant+";

		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brickModter4x4x5SlantUpInvdata)
	{
		uiName = "4x Slant+ Inv 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Slant+ Inv";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Slant+ Inv.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5CornerUpdata)
	{
		uiName = "4x Corner+ 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Corner+";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Corner+.dts";
	};

	datablock fxDTSBrickData(brickModter4x4x5CornerUpInvdata)
	{
		uiName = "4x Corner+ Inv 1/2h";
		brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_siba/4x4x5/icons/Corner+ Inv";

		hasPrint = 1;
		printAspectRatio = "ModTer";

		//collisionShapeName = "./collision/Corner+ Inv.dts";
	};
}
