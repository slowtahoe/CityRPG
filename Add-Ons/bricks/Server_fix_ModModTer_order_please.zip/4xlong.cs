if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4WedgeLongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWLSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongWedge L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWRSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongWedge R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongCornerA L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongCornerA R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongCornerB L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "741x LongCornerB R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
// datablock fxDTSBrickData(brick4CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "741x LongCornerC L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "741x LongCornerC R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "741x LongCornerD L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "741x LongCornerD R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
	datablock fxDTSBrickData(brick4WedgeLongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongWedge L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongWedge R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerA L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerA R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerB L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerB R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
	        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
// datablock fxDTSBrickData(brick4CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "154x LongCornerC L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "154x LongCornerC R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "154x LongCornerD L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick4CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "4x Long";
// 	uiName = "154x LongCornerD R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
//         //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4WedgeLongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongWedge L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongWedge R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerA L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerA R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerB L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "154x LongCornerB R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
			//CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}
