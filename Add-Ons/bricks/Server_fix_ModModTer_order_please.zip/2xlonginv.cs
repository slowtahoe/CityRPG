if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brick2CornerALongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerA L Steep Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerA R Steep Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerB L Steep Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerB R Steep Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerA L Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerALongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerA R Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerB L Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeL1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick2CornerBLongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "444x LongCornerB R Inv.";
        //iconName = "Add-Ons/Brick_ModModTer/BrickIcons/4xFiller/4xLongWedgeR1-2";
        //CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xFiller/4xLongWedgeR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
