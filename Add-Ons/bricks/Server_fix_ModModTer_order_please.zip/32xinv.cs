if(!isAddOnEnabled("Brick_ModTer_InvertedPack"))
	return;

datablock fxDTSBrickData(brick32Ramp5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "32x Inv";
	uiName = "32x Inv. Category Dummy";
};
datablock fxDTSBrickData(brick32CornerA5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/32cCAinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorA Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/32cCAinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/32cCAinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/32cCBinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorB Steep Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/32cCBinvSteep";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/32cCBinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/32cCCinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorC Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/32cCCinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/32cCCinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Steep/32cCDinvSteep.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorD Steep Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/32cCDinvSteep";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Steep/32cCDinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/32cRinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x Ramp Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/32cRinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/32cRinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/32cCAinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorA Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/32cCAinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/32cCAinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/32cCBinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorB Inv.";
	iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/32cCBinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/32cCBinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/32cCCinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorC Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/32cCCinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/32cCCinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD1InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/Full/32cCDinv.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorD Inv.";
        iconName = "Add-ons/Brick_ModTer_InvertedPack/BrickIcons/Full/32cCDinv";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/Full/32cCDinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/32cRinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x Ramp 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/32cRinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/32cRinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/32cCAinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorA 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/32cCAinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/32cCAinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/32cCBinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorB 3/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/32cCBinv3-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/32cCBinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/32cCCinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorC 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/32cCCinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/32cCCinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD2InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/3-4/32cCDinv3-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorD 3/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/3-4/32cCDinv3-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/3-4/32cCDinv3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/32cRinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x Ramp 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/32cRinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/32cRinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/32cCAinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorA 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/32cCAinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/32cCAinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/32cCBinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorB 1/2h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/32cCBinv1-2";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/32cCBinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/32cCCinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorC 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/32cCCinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/32cCCinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD3InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-2/32cCDinv1-2.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorD 1/2h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/32cCDinv1-2";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-2/32cCDinv1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32Ramp4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/32cRinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x Ramp 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/32cRinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/32cRinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerA4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/32cCAinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorA 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/32cCAinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/32cCAinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerB4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/32cCBinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorB 1/4h Inv.";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/32cCBinv1-4";
	//collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/32cCBinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerC4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/32cCCinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorC 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/32cCCinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/32cCCinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerD4InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_InvertedPack/Bricks/1-4/32cCDinv1-4.blb";
	category = "Baseplates";
	subCategory = "ModTer 32x Inv";
	uiName = "32x CorD 1/4h Inv.";
        iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-4/32cCDinv1-4";
        //collisionShapeName = "Add-Ons/Brick_ModTer_InvertedPack/Shapes/1-4/32cCDinv1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
