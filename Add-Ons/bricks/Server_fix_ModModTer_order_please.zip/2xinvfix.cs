if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brick2Ramp5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x Ramp Steep Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorA Steep Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorB Steep Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorC Steep Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorD Steep Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x Ramp Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorA Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorB Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorC Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = "659x CorD Inv. Fixed";
	iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
	//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
