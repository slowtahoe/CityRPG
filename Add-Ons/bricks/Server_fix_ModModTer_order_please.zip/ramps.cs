if(isAddOnEnabled("Brick_ModModTer_ChiselPack"))
{
	datablock fxDTSBrickData(brick16ChiselL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLSteep.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel L Steep";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChL.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel L";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChL";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselL2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChL3-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel L 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChL3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChL3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChL1-2.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel L 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChL1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChL1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselL4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChL1-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel L 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChL1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChL1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRSteep.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel R Steep";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChR.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel R";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChR";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselR2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChR3-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel R 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChR3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChR3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChR1-2.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel R 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChR1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChR1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16ChiselR4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChR1-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "481x Chisel R 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChR1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChR1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLSteep.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel L Steep";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick8ChiselL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChL.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel L";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChL";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselL2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChL3-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel L 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChL3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChL3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChL1-2.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel L 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChL1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChL1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselL4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChL1-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel L 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChL1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChL1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRSteep.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel R Steep";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	
	datablock fxDTSBrickData(brick8ChiselR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChR.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel R";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChR";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselR2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChR3-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel R 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChR3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChR3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChR1-2.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel R 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChR1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChR1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8ChiselR4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChR1-4.blb";
		category = "ModTer 2";
		subCategory = "Chisel";
		uiName = "271x Chisel R 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChR1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChR1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	if(isAddOnEnabled("Brick_ModTer_InvertedPack"))
	{
		datablock fxDTSBrickData(brick8ChiselL5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLinvSteep.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel L Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselL1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLinv.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel L Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselL2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLinv3-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel L 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselL3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLinv1-2.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel L 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselL4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChLinv1-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel L 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChLinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChLinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselR5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRinvSteep.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel R Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselR1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRinv.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel R Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselR2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRinv3-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel R 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselR3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRinv1-2.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel R 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8ChiselR4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/8x/8cChRinv1-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "271x Chisel R 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/8x/8cChRinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/8x/8cChRinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselL5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLinvSteep.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel L Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};

		datablock fxDTSBrickData(brick16ChiselL1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLinv.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel L Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselL2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLinv3-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel L 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselL3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLinv1-2.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel L 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselL4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChLinv1-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel L 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChLinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChLinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselR5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRinvSteep.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel R Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselR1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRinv.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel R Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselR2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRinv3-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel R 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselR3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRinv1-2.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel R 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16ChiselR4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_ChiselPack/Bricks/16x/16cChRinv1-4.blb";
			category = "ModTer 2";
			subCategory = "Chisel Inv";
			uiName = "481x Chisel R 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_ChiselPack/BrickIcons/16x/16cChRinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_ChiselPack/Shapes/16x/16cChRinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		
	}
}

if(isAddOnEnabled("Brick_ModModTer_90CornerCPack"))
{
	datablock fxDTSBrickData(brick16CornerC90L5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90LSteep.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC L Steep";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90LSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90LSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90L1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90L.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC L";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90L";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90LCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90L2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90L3-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC L 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90L3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90L3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90L3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90L1-2.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC L 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90L1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90L1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90L4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90L1-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC L 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90L1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90L1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90R5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90RSteep.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC R Steep";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90RSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90RSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90R1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90R.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC R";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90R";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90RCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90R2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90R3-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC R 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90R3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90R3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90R3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90R1-2.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC R 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90R1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90R1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerC90R4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90R1-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "481x 90° CornerC R 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90R1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90R1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90L5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90LSteep.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC L Steep";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90LSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90LSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick8CornerC90L1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90L.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC L";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90L";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90LCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90L2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90L3-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC L 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90L3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90L3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90L3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90L1-2.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC L 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90L1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90L1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90L4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90L1-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC L 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90L1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90L1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90R5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90RSteep.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC R Steep";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90RSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90RSteepCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	
	datablock fxDTSBrickData(brick8CornerC90R1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90R.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC R";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90R";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90RCol.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90R2Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90R3-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC R 3/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90R3-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90R3-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90R3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90R1-2.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC R 1/2h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90R1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90R1-2Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerC90R4Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90R1-4.blb";
		category = "ModTer 2";
		subCategory = "90° CornerC";
		uiName = "271x 90° CornerC R 1/4h";
	    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90R1-4";
		collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90R1-4Col.dts";
	    hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	if(isAddOnEnabled("Brick_ModTer_InvertedPack"))
	{
		datablock fxDTSBrickData(brick8CornerC90L5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90LinvSteep.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC L Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90LinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90LinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90L1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Linv.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC L Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Linv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90LinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90L2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Linv3-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC L 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Linv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Linv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90L3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Linv1-2.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC L 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Linv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Linv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90L4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Linv1-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC L 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Linv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Linv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90R5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90RinvSteep.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC R Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90RinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90RinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90R1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Rinv.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC R Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Rinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90RinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90R2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Rinv3-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC R 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Rinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Rinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90R3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Rinv1-2.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC R 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Rinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Rinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick8CornerC90R4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/8x/8cCC90Rinv1-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "271x 90° CorC R 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/8x/8cCC90Rinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/8x/8cCC90Rinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90L5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90LinvSteep.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC L Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90LinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90LinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};

		datablock fxDTSBrickData(brick16CornerC90L1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Linv.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC L Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Linv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90LinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90L2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Linv3-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC L 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Linv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Linv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90L3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Linv1-2.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC L 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Linv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Linv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90L4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Linv1-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC L 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Linv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Linv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90R5invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90RinvSteep.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC R Steep Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90RinvSteep";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90RinvSteepCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90R1invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Rinv.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC R Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Rinv";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90RinvCol.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90R2invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Rinv3-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC R 3/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Rinv3-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Rinv3-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90R3invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Rinv1-2.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC R 1/2h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Rinv1-2";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Rinv1-2Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		datablock fxDTSBrickData(brick16CornerC90R4invData)
		{
			brickFile = "Add-Ons/Brick_ModModTer_90CornerCPack/Bricks/16x/16cCC90Rinv1-4.blb";
			category = "ModTer 2";
			subCategory = "90° CornerC Inv";
			uiName = "481x 90° CorC R 1/4h Inv.";
		    iconName = "Add-Ons/Brick_ModModTer_90CornerCPack/BrickIcons/16x/16cCC90Rinv1-4";
			collisionShapeName = "Add-Ons/Brick_ModModTer_90CornerCPack/Shapes/16x/16cCC90Rinv1-4Col.dts";
		    hasPrint = 1;
			printAspectRatio = "ModTer";
			isWaterBrick = true;
		};
		
	}
}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////RAMPS/////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	datablock fxDTSBrickData(brick64x32Ramp1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "128x32 Ramp";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
datablock fxDTSBrickData(brick64x32Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "128x32 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick64x32Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "128x32 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick64x32Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "128x32 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick32x16Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x64 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick32x16Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x64 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick32x16Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x64 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick32x16Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x64 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick32x16Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x64 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick16x8Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x78 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick16x8Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x78 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick16x8Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x78 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick16x8Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x78 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick16x8Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x78 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick8x4Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x45 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick8x4Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x45 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick8x4Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x45 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick8x4Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x45 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick8x4Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x45 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4x2Ramp5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp Steep";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cR.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4x2Ramp3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cR1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp 1/2h";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cR1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4x2Ramp5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRSteepFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp Steep Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4x2Ramp3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cR1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x16 Ramp 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cR1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

//////////////////////////////////////////////inv//////////////////////////////////////////////


if(isAddOnEnabled("Brick_ModTer_InvertedPack"))
{
	datablock fxDTSBrickData(brick64x32Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "128x32 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick64x32Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "128x32 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick64x32Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "128x32 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick64x32Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "128x32 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick32x16Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x64 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick32x16Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x64 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick32x16Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x64 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick32x16Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x64 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick32x16Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x64 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick16x8Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x78 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick16x8Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x78 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick16x8Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x78 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick16x8Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x78 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick16x8Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x78 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick8x4Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x45 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick8x4Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x45 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick8x4Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x45 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick8x4Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x45 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick8x4Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x45 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4x2Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4x2Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_4xPack"))
{
	datablock fxDTSBrickData(brick4x2Ramp5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinvFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if(isAddOnEnabled("Brick_ModTer_siba") && isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
{
	datablock fxDTSBrickData(brick4x2Ramp3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x16 Ramp 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
