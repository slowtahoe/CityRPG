if(!isAddOnEnabled("Brick_ModTer_siba") || !isFile("Add-Ons/Brick_ModTer_siba/server.cs"))
	return;

datablock fxDTSBrickData(brick2Ramp5InvData)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x Inv";
	uiName = "2x Inv. Category Dummy";
};
datablock fxDTSBrickData(brick2CornerA5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCAinvSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CorA Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerB5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCBinvSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CorB Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerC5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCCinvSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CorC Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerD5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCDinvSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CorD Steep Inv.";
		iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
		//collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
datablock fxDTSBrickData(brickModter2x2x5RampInvdata)
{
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";
	category = "ModTer";
	subCategory = "2x Inv";
	uiName = "2x Inv. Category Dummy";
};

datablock fxDTSBrickData(brickModter2x2x5SlantDowndata)
{
	uiName = "2x Slant- ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x Inv";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Slant-";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	//collisionShapeName = "./collision/Slant-.dts";
};

datablock fxDTSBrickData(brickModter2x2x5SlantDownInvdata)
{
	uiName = "2x Slant- Inv ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x Inv";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Slant- Inv";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	//collisionShapeName = "./collision/Slant- Inv.dts";
};

datablock fxDTSBrickData(brickModter2x2x5CornerDowndata)
{
	uiName = "2x Corner- ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x Inv";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Corner-";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	//collisionShapeName = "./collision/Corner-.dts";
};

datablock fxDTSBrickData(brickModter2x2x5CornerDownInvdata)
{
	uiName = "2x Corner- Inv ";
	brickFile = "Add-Ons/Brick_ModTer_BasicPack/Bricks/Full/64c.blb";

	category = "ModTer";
	subCategory = "2x Inv";
	iconName = "Add-Ons/Brick_ModTer_siba/2x2x5/icons/Corner- Inv";

	hasPrint = 1;
	printAspectRatio = "ModTer";

	//collisionShapeName = "./collision/Corner- Inv.dts";
};
