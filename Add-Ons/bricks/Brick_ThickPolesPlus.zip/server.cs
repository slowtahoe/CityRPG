datablock fxDTSBrickData(brickVertThickPole1x1Data)
{
	brickFile = "./thickpolevertx1.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1 Vert Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x1VertThickPole";
};

datablock fxDTSBrickData(brickVertThickPole1X2Data)
{
	brickFile = "./thickpolevertx2.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x2 Vert Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x2VertThickPole";
};

datablock fxDTSBrickData(brickVertThickPole1X3Data)
{
	brickFile = "./thickpolevertx3.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x3 Vert Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x3VertThickPole";
};

datablock fxDTSBrickData(brickVertThickPoleXData)
{
	brickFile = "./thickpolex.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole X";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleX";
};

datablock fxDTSBrickData(brickVertThickPoleX2Data)
{
	brickFile = "./thickpolex2.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole X Top";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleXTop";
};

datablock fxDTSBrickData(brickVertThickPoleCornerData)
{
	brickFile = "./thickpolecorner.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole Corner";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleCorner";
};

datablock fxDTSBrickData(brickVertThickPoleCorner2Data)
{
	brickFile = "./thickpolecornertop.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole Corner Top";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleCornerTop";
};

datablock fxDTSBrickData(brickVertThickPoleTXData)
{
	brickFile = "./vertthickpoletx.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T X";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTX";
};

datablock fxDTSBrickData(brickVertThickPoleTUpData)
{
	brickFile = "./vertthickpoletup.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T Up";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTUp";
};

datablock fxDTSBrickData(brickVertThickPoleTDownData)
{
	brickFile = "./vertthickpoletdown.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T Down";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTDown";
};

datablock fxDTSBrickData(brickVertThickPoleTFlatData)
{
	brickFile = "./vertthickpoletflat.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T Flat";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTFlat";
};

datablock fxDTSBrickData(brickVertThickPoleTFlattopData)
{
	brickFile = "./vertthickpoletflattop.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T Flat Top";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTFlatTop";
};

datablock fxDTSBrickData(brickVertThickPoleTFlattop2Data)
{
	brickFile = "./vertthickpoletflattop2.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole T Side";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleTSide";
};

datablock fxDTSBrickData(brickVertThickPoleCornerUpData)
{
	brickFile = "./vertthickpolecornervert.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole Corner Up";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleCornerVert";
};

datablock fxDTSBrickData(brickVertThickPoleCornerDownData)
{
	brickFile = "./vertthickpolecornerdown.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "Vert Thick Pole Corner Down";
	iconName = "Add-Ons/Brick_ThickPolesPlus/VertThickPoleCornerDown";
};

// partial replacement of old thick poles because of shading issues
// i tried my best to make it work without having to revamp the
// whole pack but sometimes you have to take the leap...

datablock fxDTSBrickData(brickTPole1x1fData)
{
	brickFile = "./thickpolehorizx1f.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1f Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x1fThickPole";
};

datablock fxDTSBrickData(brickTPole1x1Data)
{
	brickFile = "./thickpolehorizx1.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1 Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x1ThickPole";
};

datablock fxDTSBrickData(brickHorizThickPole2XData)
{
	brickFile = "./thickpolehorizx2.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x2 Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x2ThickPole";
};

datablock fxDTSBrickData(brickTPole1x3Data)
{
	brickFile = "./thickpolehorizx3.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x3 Thick Pole";
	iconName = "Add-Ons/Brick_ThickPolesPlus/1x3ThickPole";
};