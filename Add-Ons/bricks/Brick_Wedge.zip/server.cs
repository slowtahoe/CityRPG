datablock fxDTSBrickData(brick2x3wedgeLData)
{
	brickFile = "./bricks/2x3wedgeL.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x3 Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3 wedge L";
	collisionShapeName = "./shapes/2x3wedgeL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x3FwedgeLData)
{
	brickFile = "./bricks/2x3FwedgeL.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x3F Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3F wedge L";
	collisionShapeName = "./shapes/2x3Fwedgeright.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x3wedgeRData)
{
	brickFile = "./bricks/2x3wedgeR.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x3 Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3 wedge R";
	collisionShapeName = "./shapes/2x3wedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x3FwedgeRData)
{
	brickFile = "./bricks/2x3FwedgeR.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x3F Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3F wedge R";
	collisionShapeName = "./shapes/2x3Fwedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4wedgeLData)
{
	brickFile = "./bricks/2x4wedgeL.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x4 Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 Wedge L";
	collisionShapeName = "./shapes/2x4wedgeright.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4FwedgeLData)
{
	brickFile = "./bricks/2x4FwedgeL.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x4F Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4F wedge L";
	collisionShapeName = "./shapes/2x4Fwedgeright.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4wedgeRData)
{
	brickFile = "./bricks/2x4wedgeR.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "2x4 Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 wedge R";
	collisionShapeName = "./shapes/2x4wedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4FwedgeRData)
{
	brickFile = "./bricks/2x4FwedgeR.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "2x4F Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4F wedge R";
	collisionShapeName = "./shapes/2x4Fwedgeleft.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x6wedgeLData)
{
	brickFile = "./bricks/3x6WingL.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "3x6F Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/3x6 Wing L";
	collisionShapeName = "./shapes/3x6wingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x6wedgeRData)
{
	brickFile = "./bricks/3x6WingR.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "3x6F Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/3x6 Wing R";
	collisionShapeName = "./shapes/3x6wingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x12wedgeLData)
{
	brickFile = "./bricks/3x12WingL.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "3x12F Wedge L";
	iconName = "Add-Ons/Brick_Wedge/icons/3x12 Wing L";
	collisionShapeName = "./shapes/3x12wingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x12wedgeRData)
{
	brickFile = "./bricks/3x12WingR.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "3x12F Wedge R";
	iconName = "Add-Ons/Brick_Wedge/icons/3x12 Wing R";
	collisionShapeName = "./shapes/3x12wingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x3wedgeData)
{
	brickFile = "./bricks/3x3wedge.blb";
	category = "Wedges";
	subCategory = "Bricks";
	uiName = "3x3 Wedge";
	iconName = "Add-Ons/Brick_Wedge/icons/3x3 wedge";
	collisionShapeName = "./shapes/3x3wedge.dts";
	orientationFix = 3;
};

//datablock fxDTSBrickData(brick1x1wedgeData)
//{
//	brickFile = "./bricks/1x1wedge.blb";
//	category = "Wedges";
//	subCategory = "Bricks";
//	uiName = "1x1 Wedge";
//	iconName = "Add-Ons/Brick_Wedge/icons/1x1wedge";
//	collisionShapeName = "./shapes/1x1wedge.dts";
//};

datablock fxDTSBrickData(brick3x3FwedgeData)
{
	brickFile = "./bricks/3x3Fwedge.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "3x3F Wedge";
	iconName = "Add-Ons/Brick_Wedge/icons/3x3F wedge";
	collisionShapeName = "./shapes/3x3Fwedge.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x4FwedgeData)
{
	brickFile = "./bricks/4x4wedge.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "4x4F Wedge";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4F Wedge";
	collisionShapeName = "./shapes/4x4wedge.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick6x6FwedgeData)
{
	brickFile = "./bricks/6x6wedge.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "6x6F Wedge";
	iconName = "Add-Ons/Brick_Wedge/icons/6x6F Wedge";
	collisionShapeName = "./shapes/6x6wedge.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick8x8FwedgeData)
{
	brickFile = "./bricks/8x8wedge.blb";
	category = "Wedges";
	subCategory = "Plates";
	uiName = "8x8F Wedge";
	iconName = "Add-Ons/Brick_Wedge/icons/8x8F wedge";
	collisionShapeName = "./shapes/8x8wedge.dts";
	orientationFix = 3;
};

//datablock fxDTSBrickData(brick1x1FwedgeData)
//{
//	brickFile = "./bricks/1x1Fwedge.blb";
//	category = "Wedges";
//	subCategory = "Plates";
//	uiName = "1x1F Wedge";
//	iconName = "Add-Ons/Brick_Wedge/icons/1x1Fwedge";
//	collisionShapeName = "./shapes/1x1Fwedge.dts";
//};

//datablock fxDTSBrickData(brick2x3x5wedgerightData)
//{
//	brickFile = "./bricks/2x3x5wedgeright.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "2x3x5 Wedge Right";
//	iconName = "Add-Ons/Brick_Wedge/icons/2x3x5wedgeright";
//	collisionShapeName = "./shapes/2x3x5wedgeright.dts";
//};

//datablock fxDTSBrickData(brick2x3x5wedgeleftData)
//{
//	brickFile = "./bricks/2x3x5wedgeleft.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "2x3x5 Wedge Left";
//	iconName = "Add-Ons/Brick_Wedge/icons/2x3x5wedgeleft";
//	collisionShapeName = "./shapes/2x3x5wedgeleft.dts";
//};

//datablock fxDTSBrickData(brick2x4x5wedgerightData)
//{
//	brickFile = "./bricks/2x4x5wedgeright.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "2x4x5 Wedge Right";
//	iconName = "Add-Ons/Brick_Wedge/icons/2x4x5wedgeright";
//	collisionShapeName = "./shapes/2x4x5wedgeright.dts";
//};

//datablock fxDTSBrickData(brick2x4x5wedgeleftData)
//{
//	brickFile = "./bricks/2x4x5wedgeleft.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "2x4x5 Wedge Left";
//	iconName = "Add-Ons/Brick_Wedge/icons/2x4x5wedgeleft";
//	collisionShapeName = "./shapes/2x4x5wedgeleft.dts";
//};

//datablock fxDTSBrickData(brick3x3x5wedgeData)
//{
//	brickFile = "./bricks/3x3x5wedge.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "3x3x5 Wedge";
//	iconName = "Add-Ons/Brick_Wedge/icons/3x3x5wedge";
//	collisionShapeName = "./shapes/3x3x5wedge.dts";
//};

//datablock fxDTSBrickData(brick1x1x5wedgeData)
//{
//	brickFile = "./bricks/1x1x5wedge.blb";
//	category = "Wedges";
//	subCategory = "5x Height";
//	uiName = "1x1x5 Wedge";
//	iconName = "Add-Ons/Brick_Wedge/icons/1x1x5wedge";
//	collisionShapeName = "./shapes/1x1x5wedge.dts";
//};

datablock fxDTSBrickData(brick4x4wingLData)
{
	brickFile = "./bricks/4x4wingL.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "4x4 Wing L";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 wing L";
	collisionShapeName = "./shapes/4x4wingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x4wingRData)
{
	brickFile = "./bricks/4x4wingR.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "4x4 Wing R";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 wing R";
	collisionShapeName = "./shapes/4x4wingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x8wingLData)
{
	brickFile = "./bricks/4x8wingL.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "4x8 Wing L";
	iconName = "Add-Ons/Brick_Wedge/icons/4x8 wing L";
	collisionShapeName = "./shapes/4x8wingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x8wingRData)
{
	brickFile = "./bricks/4x8wingR.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "4x8 Wing R";
	iconName = "Add-Ons/Brick_Wedge/icons/4x8 wing R";
	collisionShapeName = "./shapes/4x8wingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x8wingLData)
{
	brickFile = "./bricks/3x8WingL.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "3x8 Wing L";
	iconName = "Add-Ons/Brick_Wedge/icons/3x8 Wing L";
	collisionShapeName = "./shapes/3x8wingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick3x8wingRData)
{
	brickFile = "./bricks/3x8WingR.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "3x8 Wing R";
	iconName = "Add-Ons/Brick_Wedge/icons/3x8 Wing R";
	collisionShapeName = "./shapes/3x8wingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick6x12WingLData)
{
	brickFile = "./bricks/6x12WingL.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "6x12 Wing L";
	iconName = "Add-Ons/Brick_Wedge/icons/6x12 Wing L";
	collisionShapeName = "./shapes/6x12WingL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick6x12WingRData)
{
	brickFile = "./bricks/6x12WingR.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "6x12 Wing R";
	iconName = "Add-Ons/Brick_Wedge/icons/6x12 Wing R";
	collisionShapeName = "./shapes/6x12WingR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x9wingData)
{
	brickFile = "./bricks/4x9wing.blb";
	category = "Wedges";
	subCategory = "Wings";
	uiName = "4x9 Wing";
	iconName = "Add-Ons/Brick_Wedge/icons/4x9 Wing";
	collisionShapeName = "./shapes/4x9Wing.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4rampwedgeRData)
{
	brickFile = "./bricks/2x4rampwedgeR.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "2x4 Ramped R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 Ramped R";
	collisionShapeName = "./shapes/2x4RampedR.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x4rampwedgeLData)
{
	brickFile = "./bricks/2x4rampwedgeL.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "2x4 Ramped L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 Ramped L";
	collisionShapeName = "./shapes/2x4RampedL.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x4rampwedgeData)
{
	brickFile = "./bricks/4x4rampwedge.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "4x4 Ramped";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 Ramped";
	collisionShapeName = "./shapes/4x4Ramped.dts";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick4x4rampwedgeInvData)
{
	brickFile = "./bricks/4x4rampwedgeInv.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "4x4 Ramped Inv.";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 Ramped Inv.";
	collisionShapeName = "./shapes/4x4RampedInv.dts";
	orientationFix = 3;
};

//////////////////CURVED///////////////////////////

datablock fxDTSBrickData(brick2x6curvedRampWedgeRightData)
{
	brickFile = "./bricks/2x6curvedRampWedgeRight.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x6 Curved R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x6 Curved R";
	collisionShapeName = "./shapes/2x6CurvedR.dts";
	orientationFix = 1;
};


datablock fxDTSBrickData(brick2x6curvedRampWedgeRightInvData)
{
	brickFile = "./bricks/2x6curvedRampWedgeRightInv.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x6 Curved R Inv.";
	iconName = "Add-Ons/Brick_Wedge/icons/2x6 Curved R Inv.";
	collisionShapeName = "./shapes/2x6CurvedRInv.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x6curvedRampWedgeLeftData)
{
	brickFile = "./bricks/2x6curvedRampWedgeLeft.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x6 Curved L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x6 Curved L";
	collisionShapeName = "./shapes/2x6CurvedL.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x6curvedRampWedgeLeftInvData)
{
	brickFile = "./bricks/2x6curvedRampWedgeLeftInv.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x6 Curved L Inv.";
	iconName = "Add-Ons/Brick_Wedge/icons/2x6 Curved L Inv.";
	collisionShapeName = "./shapes/2x6CurvedLInv.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x3x8curvedLData)
{
	brickFile = "./bricks/2x3x8curvedL.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x3x8 Curved L";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3x8 curved L";
	collisionShapeName = "./shapes/2x3x8CurvedL.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x3x8curvedRData)
{
	brickFile = "./bricks/2x3x8curvedR.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "2x3x8 Curved R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x3x8 curved R";
	collisionShapeName = "./shapes/2x3x8CurvedR.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick10x3curvedLData)
{
	brickFile = "./bricks/10x3curvedL.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "3x10 Curved L";
	iconName = "Add-Ons/Brick_Wedge/icons/10x3 curved L";
	collisionShapeName = "./shapes/10x3CurvedL.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick10x3curvedRData)
{
	brickFile = "./bricks/10x3curvedR.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "3x10 Curved R";
	iconName = "Add-Ons/Brick_Wedge/icons/10x3 curved R";
	collisionShapeName = "./shapes/10x3CurvedR.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick16x4curvedData)
{
	brickFile = "./bricks/16x4curved.blb";
	category = "Wedges";
	subCategory = "Curved";
	uiName = "4x16 Curved";
	iconName = "Add-Ons/Brick_Wedge/icons/16x4 curved";
	collisionShapeName = "./shapes/16x4Curved.dts";
	orientationFix = 1;
};


///////////////////////NOT CURVED/////////////

datablock fxDTSBrickData ( brick4x4taperData )
{
	brickFile = "./bricks/4x4taper.blb";
	uiName = "4x4 Taper";
	category = "Wedges";
        subCategory = "Misc";
	orientationFix = 1;
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 Taper";
	collisionShapeName = "./shapes/4x4Taper.dts";
};

datablock fxDTSBrickData(brick4x6RampWedgeCutoutData)
{
	brickFile = "./bricks/4x6RampWedgeCutout.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "4x6 Ramped";
	iconName = "Add-Ons/Brick_Wedge/icons/4x6 Ramped";
	collisionShapeName = "./shapes/4x6Ramped.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick4x6RampedInvData)
{
	brickFile = "./bricks/4x6RampedInv.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "4x6 Ramped Inv.";
	iconName = "Add-Ons/Brick_Wedge/icons/4x6 Ramped Inv.";
	collisionShapeName = "./shapes/4x6RampedInv.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick6x8RampedData)
{
	brickFile = "./bricks/6x8Ramped.blb";
	category = "Wedges";
	subCategory = "Ramped";
	uiName = "6x8 Ramped";
	iconName = "Add-Ons/Brick_Wedge/icons/6x8 Ramped";
	collisionShapeName = "./shapes/6x8Ramped.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick2x4SlopedRData)
{
	brickFile = "./bricks/2x4SlopedR.blb";
	category = "Wedges";
	subCategory = "Misc";
	uiName = "2x4 Sloped R";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 Sloped R";
	orientationFix = 3;
	collisionShapeName = "./shapes/2x4slopedR.dts";
};

datablock fxDTSBrickData(brick2x4SlopedLData)
{
	brickFile = "./bricks/2x4SlopedL.blb";
	category = "Wedges";
	subCategory = "Misc";
	uiName = "2x4 Sloped L";
	orientationFix = 3;
	iconName = "Add-Ons/Brick_Wedge/icons/2x4 Sloped L";
	collisionShapeName = "./shapes/2x4slopedL.dts";
};

datablock fxDTSBrickData(brick2x4doublewedgeData)
{
	brickFile = "./bricks/2x4doublewedge.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "2x4F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/2x4F Arrow";
	collisionShapeName = "./shapes/2x4Arrow.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick3x4arrowData)
{
	brickFile = "./bricks/3x4arrow.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "3x4F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/3x4F Arrow";
	collisionShapeName = "./shapes/3x4Arrow.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick4x4arrowData)
{
	brickFile = "./bricks/4x4arrow.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "4x4F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/4x4F Arrow";
	collisionShapeName = "./shapes/4x4Arrow.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData(brick8x8arrowData)
{
	brickFile = "./bricks/8x8arrow.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "8x8F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/8x8F Arrow";
	collisionShapeName = "./shapes/8x8Arrow.dts";
	orientationFix = 1;
};

datablock fxDTSBrickData ( brick4x4wedgelinkedData )
{
	brickFile = "./bricks/4x4wedgelinked.blb";
	uiName = "4x4 Wedge Linked";
	category = "Wedges";
        subCategory = "Misc";
	orientationFix = 1;
	iconName = "Add-Ons/Brick_Wedge/icons/4x4 Wedge Linked";
	collisionShapeName = "./shapes/4x4wedgelinked.dts";
};

datablock fxDTSBrickData(brick3x6FwedgeData)
{
	brickFile = "./bricks/3x6Fwedge.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "3x6F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/3x6F wedge";
	collisionShapeName = "./shapes/3x6Fwedge.dts";
};

datablock fxDTSBrickData(brick4x6FwedgeData)
{
	brickFile = "./bricks/4x6Fwedge.blb";
	category = "Wedges";
	subCategory = "Arrows";
	uiName = "4x6F Arrow";
	iconName = "Add-Ons/Brick_Wedge/icons/4x6F wedge";
	collisionShapeName = "./shapes/4x6Fwedge.dts";
};