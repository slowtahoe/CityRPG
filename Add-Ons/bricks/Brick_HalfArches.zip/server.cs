// 1x2x1
datablock fxDTSBrickData(brick1x2halfarchData)
{
	brickFile = "./shapes/1x2halfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2 Half Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2halfarch";
	collisionShapeName = "./shapes/1x2halfarch.dts";
};

datablock fxDTSBrickData(brick1x2halfarchupData)
{
	brickFile = "./shapes/1x2halfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2 Half Arch Up";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2halfarchup";
	collisionShapeName = "./shapes/1x2halfarchup.dts";
};

datablock fxDTSBrickData(brick1x3doublehalfarchData)
{
	brickFile = "./shapes/1x3doublehalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3 Double H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3doublehalfarch";
	collisionShapeName = "./shapes/1x3doublehalfarch.dts";
};

datablock fxDTSBrickData(brick1x3doublehalfarchupData)
{
	brickFile = "./shapes/1x3doublehalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3 Double H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3doublehalfarchup";
	collisionShapeName = "./shapes/1x3doublehalfarchup.dts";
};

datablock fxDTSBrickData(brick1x1choppedhalfarchData)
{
	brickFile = "./shapes/1x1choppedhalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x1 Chopped H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x1choppedhalfarch";
	collisionShapeName = "./shapes/1x1choppedhalfarch.dts";
};

datablock fxDTSBrickData(brick1x1choppedhalfarchupData)
{
	brickFile = "./shapes/1x1choppedhalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x1 Chopped H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x1choppedhalfarchup";
	collisionShapeName = "./shapes/1x1choppedhalfarchup.dts";
};

// 1x3x1
datablock fxDTSBrickData(brick1x3halfarchData)
{
	brickFile = "./shapes/1x3halfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x1 Half Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3halfarch";
	collisionShapeName = "./shapes/1x3halfarch.dts";
};

datablock fxDTSBrickData(brick1x3halfarchupData)
{
	brickFile = "./shapes/1x3halfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x1 Half Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3halfarchup";
	collisionShapeName = "./shapes/1x3halfarchup.dts";
};

datablock fxDTSBrickData(brick1x5doublehalfarchData)
{
	brickFile = "./shapes/1x5doublehalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x5x1 Double H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x5doublehalfarch";
	collisionShapeName = "./shapes/1x5doublehalfarch.dts";
};

datablock fxDTSBrickData(brick1x5doublehalfarchupData)
{
	brickFile = "./shapes/1x5doublehalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x5x1 Double H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x5doublehalfarchup";
	collisionShapeName = "./shapes/1x5doublehalfarchup.dts";
};

datablock fxDTSBrickData(brick1x2choppedhalfarchData)
{
	brickFile = "./shapes/1x2choppedhalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2x1 Chopped H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2choppedhalfarch";
	collisionShapeName = "./shapes/1x2choppedhalfarch.dts";
};

datablock fxDTSBrickData(brick1x2choppedhalfarchupData)
{
	brickFile = "./shapes/1x2choppedhalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2x1 Chopped H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2choppedhalfarchup";
	collisionShapeName = "./shapes/1x2choppedhalfarchup.dts";
};

// 1x3x2
datablock fxDTSBrickData(brick1x3x2halfarchData)
{
	brickFile = "./shapes/1x3x2halfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x2 Half Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3x2halfarch";
	collisionShapeName = "./shapes/1x3x2halfarch.dts";
};

datablock fxDTSBrickData(brick1x3x2halfarchupData)
{
	brickFile = "./shapes/1x3x2halfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x2 Half Arch Up";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3x2halfarchup";
	collisionShapeName = "./shapes/1x3x2halfarchup.dts";
};

datablock fxDTSBrickData(brick1x5x2doublehalfarchData)
{
	brickFile = "./shapes/1x5x2doublehalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x5x2 Double H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x5x2doublehalfarch";
	collisionShapeName = "./shapes/1x5x2doublehalfarch.dts";
};

datablock fxDTSBrickData(brick1x5x2doublehalfarchupData)
{
	brickFile = "./shapes/1x5x2doublehalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x5x2 Double H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x5x2doublehalfarchup";
	collisionShapeName = "./shapes/1x5x2doublehalfarchup.dts";
};

datablock fxDTSBrickData(brick1x2x2choppedhalfarchData)
{
	brickFile = "./shapes/1x2x2choppedhalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2x2 Chopped H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2x2choppedhalfarch";
	collisionShapeName = "./shapes/1x2x2choppedhalfarch.dts";
};

datablock fxDTSBrickData(brick1x2x2choppedhalfarchupData)
{
	brickFile = "./shapes/1x2x2choppedhalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2x2 Chopped H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2x2choppedhalfarchup";
	collisionShapeName = "./shapes/1x2x2choppedhalfarchup.dts";
};

// 1x4x3
datablock fxDTSBrickData(brick1x4x3halfarchData)
{
	brickFile = "./shapes/1x4x3halfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x4x3 Half Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x4x3halfarch";
	collisionShapeName = "./shapes/1x4x3halfarch.dts";
};

datablock fxDTSBrickData(brick1x4x3halfarchupData)
{
	brickFile = "./shapes/1x4x3halfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x4x3 H Arch Up";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x4x3halfarchup";
	collisionShapeName = "./shapes/1x4x3halfarchup.dts";
};

datablock fxDTSBrickData(brick1x7x3doublehalfarchData)
{
	brickFile = "./shapes/1x7x3doublehalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x7x3 Double H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x7x3doublehalfarch";
	collisionShapeName = "./shapes/1x7x3doublehalfarch.dts";
};

datablock fxDTSBrickData(brick1x7x3doublehalfarchupData)
{
	brickFile = "./shapes/1x7x3doublehalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x7x3 Double H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x7x3doublehalfarchup";
	collisionShapeName = "./shapes/1x7x3doublehalfarchup.dts";
};

datablock fxDTSBrickData(brick1x3x3choppedhalfarchData)
{
	brickFile = "./shapes/1x3x3choppedhalfarch.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x3 Chopped H Arch";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3x3choppedhalfarch";
	collisionShapeName = "./shapes/1x3x3choppedhalfarch.dts";
};

datablock fxDTSBrickData(brick1x3x3choppedhalfarchupData)
{
	brickFile = "./shapes/1x3x3choppedhalfarchup.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x3 Chopped H Arch U";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3x3choppedhalfarchup";
	collisionShapeName = "./shapes/1x3x3choppedhalfarchup.dts";
};

//caps
datablock fxDTSBrickData(brick1x2x1archcapData)
{
	brickFile = "./shapes/1x2x1archcap.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x2x1 Arch Cap";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x2x1archcap";
};

datablock fxDTSBrickData(brick1x3x2archcapData)
{
	brickFile = "./shapes/1x3x2archcap.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x3x2 Arch Cap";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x3x2archcap";
};

datablock fxDTSBrickData(brick1x4x2archcapData)
{
	brickFile = "./shapes/1x4x2archcap.blb";
	category = "Rounds";
	subCategory = "Half Arches";
	uiName = "1x4x2 Arch Cap";
	iconName = "Add-Ons/Brick_Halfarches/icons/1x4x2archcap";
};