if($AddOnLoaded__["Brick_ModTer_siba"] $= "")
	return;

datablock fxDTSBrickData(brick2Cube5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Cube Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cSteep";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Wedge5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cWSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Wedge Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cWSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cWSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Ramp Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cRSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCASteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerA Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCASteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCASteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerB Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCBSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCBSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerC Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCCSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCCSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerD Steep Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCDSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCDSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Cube1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Cube Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8c";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Wedge1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cWFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Wedge Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cW";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Wedge.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x Ramp Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cR";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Ramp.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerA Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCA";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Slant+.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerB Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCB";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Slant+ Inv.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerC Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCC";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Corner+.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDFix.blb";
	category = "ModTer";
	subCategory = "2x Fixed";
	uiName = " 2x CornerD Fixed";
	iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCD";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Corner+ Inv.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x Ramp Steep Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cRinvSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cRinvSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorA Steep Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCAinvSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCAinvSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorB Steep Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCBinvSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCBinvSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorC Steep Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCCinvSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCCinvSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD5InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDinvSteepFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorD Steep Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCDinvSteep";
	collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCDinvSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2Ramp1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cRinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x Ramp Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cRinv";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Ramp Inv.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerA1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCAinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorA Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCAinv";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Slant-.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerB1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCBinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorB Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCBinv";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Slant- Inv.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerC1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCCinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorC Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCCinv";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Corner-.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerD1InvFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xFix/2cCDinvFix.blb";
	category = "ModTer";
	subCategory = "2x Inv Fixed";
	uiName = " 2x CorD Inv. Fixed";
	iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCDinv";
	collisionShapeName = "Add-Ons/Brick_ModTer_siba/2x2x5/collision/Corner- Inv.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
};