/////////printwater/////////
if(isObject(brick8cWatertestData))
{
	brick8cWatertestData.category = "ModTer";
	brick8cWatertestData.subCategory = "Decor";
	brick8cWatertestData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/8cWater";
}

if(isObject(brick16cWatertestData))
{
	brick16cWatertestData.category = "ModTer";
	brick16cWatertestData.subCategory = "Decor";
	brick16cWatertestData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/16cWater";
}

if(isObject(brick32cWatertestData))
{
	brick32cWatertestData.category = "ModTer";
	brick32cWatertestData.subCategory = "Decor";
	brick32cWatertestData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/32cWater";
}

/////////decors/////////

if(isObject(brickModTerOakTreeLarge2Data))
{
	brickModTerOakTreeLarge2Data.category = "ModTer";
	brickModTerOakTreeLarge2Data.subCategory = "Decor";
	brickModTerOakTreeLarge2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/oaktree_large";
}
if(isObject(brickModTerOakTreeMedium2Data))
{
	brickModTerOakTreeMedium2Data.category = "ModTer";
	brickModTerOakTreeMedium2Data.subCategory = "Decor";
	brickModTerOakTreeMedium2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/oaktree_medium";
}
if(isObject(brickOakTreeSmall2Data))
{
	brickOakTreeSmall2Data.category = "ModTer";
	brickOakTreeSmall2Data.subCategory = "Decor";
	brickOakTreeSmall2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/oaktree_small";
}
if(isObject(brickModTerPineTreeLargeData))
{
	brickModTerPineTreeLargeData.category = "ModTer";
	brickModTerPineTreeLargeData.subCategory = "Decor";
	brickModTerPineTreeLargeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/pinetree_large";
}
if(isObject(brickModTerPineTreeMediumData))
{
	brickModTerPineTreeMediumData.category = "ModTer";
	brickModTerPineTreeMediumData.subCategory = "Decor";
	brickModTerPineTreeMediumData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/pinetree_medium";
}
if(isObject(brickModTerPineTreeSmallData))
{
	brickModTerPineTreeSmallData.category = "ModTer";
	brickModTerPineTreeSmallData.subCategory = "Decor";
	brickModTerPineTreeSmallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/pinetree_small";
}
if(isObject(brickModTerBananaPalmLargeData))
{
	brickModTerBananaPalmLargeData.category = "ModTer";
	brickModTerBananaPalmLargeData.subCategory = "Decor";
	brickModTerBananaPalmLargeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/bananapalm_large";
}
if(isObject(brickModTerBananaPalmMediumData))
{
	brickModTerBananaPalmMediumData.category = "ModTer";
	brickModTerBananaPalmMediumData.subCategory = "Decor";
	brickModTerBananaPalmMediumData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/bananapalm_medium";
}
if(isObject(brickModTerBananaPalmMedium2Data))
{
	brickModTerBananaPalmMedium2Data.category = "ModTer";
	brickModTerBananaPalmMedium2Data.subCategory = "Decor";
	brickModTerBananaPalmMedium2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/bananapalm_medium2";
}
if(isObject(brickModTerBananaPalmSmallData))
{
	brickModTerBananaPalmSmallData.category = "ModTer";
	brickModTerBananaPalmSmallData.subCategory = "Decor";
	brickModTerBananaPalmSmallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/bananapalm_small";
}
if(isObject(brickModTerDeadTreeLargeData))
{
	brickModTerDeadTreeLargeData.category = "ModTer";
	brickModTerDeadTreeLargeData.subCategory = "Decor";
	brickModTerDeadTreeLargeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/deadtree_large";
}
if(isObject(brickModTerDeadTreeMediumData))
{
	brickModTerDeadTreeMediumData.category = "ModTer";
	brickModTerDeadTreeMediumData.subCategory = "Decor";
	brickModTerDeadTreeMediumData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/deadtree_medium";
}
if(isObject(brickModTerDeadTreeSmallData))
{
	brickModTerDeadTreeSmallData.category = "ModTer";
	brickModTerDeadTreeSmallData.subCategory = "Decor";
	brickModTerDeadTreeSmallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/deadtree_small";
}
if(isObject(brickModTerGrassShortData))
{
	brickModTerGrassShortData.category = "ModTer";
	brickModTerGrassShortData.subCategory = "Decor";
	brickModTerGrassShortData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/grass_short";
}
if(isObject(brickModTerGrassTallData))
{
	brickModTerGrassTallData.category = "ModTer";
	brickModTerGrassTallData.subCategory = "Decor";
	brickModTerGrassTallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/grass_tall";
}
if(isObject(brickModTerThickGrassShortData))
{
	brickModTerThickGrassShortData.category = "ModTer";
	brickModTerThickGrassShortData.subCategory = "Decor";
	brickModTerThickGrassShortData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/thickgrass_short";
}
if(isObject(brickModTerThickGrassTallData))
{
	brickModTerThickGrassTallData.category = "ModTer";
	brickModTerThickGrassTallData.subCategory = "Decor";
	brickModTerThickGrassTallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/thickgrass_tall";
}
if(isObject(brickModTerPlant1Data))
{
	brickModTerPlant1Data.category = "ModTer";
	brickModTerPlant1Data.subCategory = "Decor";
	brickModTerPlant1Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/plant1";
}
if(isObject(brickModTerPlant2Data))
{
	brickModTerPlant2Data.category = "ModTer";
	brickModTerPlant2Data.subCategory = "Decor";
	brickModTerPlant2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/plant2";
}
if(isObject(brickModTerPlant3Data))
{
	brickModTerPlant3Data.category = "ModTer";
	brickModTerPlant3Data.subCategory = "Decor";
	brickModTerPlant3Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/plant3";
}
if(isObject(brickModTerPlant4Data))
{
	brickModTerPlant4Data.category = "ModTer";
	brickModTerPlant4Data.subCategory = "Decor";
	brickModTerPlant4Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/plant3";
}
if(isObject(brickModTerCactus1Data))
{
	brickModTerCactus1Data.category = "ModTer";
	brickModTerCactus1Data.subCategory = "Decor";
	brickModTerCactus1Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/cactus1";
}
if(isObject(brickModTerCactus2Data))
{
	brickModTerCactus2Data.category = "ModTer";
	brickModTerCactus2Data.subCategory = "Decor";
	brickModTerCactus2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/cactus2";
}
if(isObject(brickModTerCactus3Data))
{
	brickModTerCactus3Data.category = "ModTer";
	brickModTerCactus3Data.subCategory = "Decor";
	brickModTerCactus3Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/cactus3";
}
if(isObject(brickModTerCactus4Data))
{
	brickModTerCactus4Data.category = "ModTer";
	brickModTerCactus4Data.subCategory = "Decor";
	brickModTerCactus4Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/cactus4";
}
if(isObject(brickModTerCactus5Data))
{
	brickModTerCactus5Data.category = "ModTer";
	brickModTerCactus5Data.subCategory = "Decor";
	brickModTerCactus5Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/cactus5";
}
if(isObject(brickModTerRockLargeData))
{
	brickModTerRockLargeData.category = "ModTer";
	brickModTerRockLargeData.subCategory = "Decor";
	brickModTerRockLargeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/rock_large";
}
if(isObject(brickModTerRockMediumData))
{
	brickModTerRockMediumData.category = "ModTer";
	brickModTerRockMediumData.subcategory = "Decor";
	brickModTerRockMediumData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/rock_medium";
}
if(isObject(brickModTerRockMedium2Data))
{
	brickModTerRockMedium2Data.category = "ModTer";
	brickModTerRockMedium2Data.subCategory = "Decor";
	brickModTerRockMedium2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/rock_medium2";
}
if(isObject(brickModTerRockSmallData))
{
	brickModTerRockSmallData.category = "ModTer";
	brickModTerRockSmallData.subCategory = "Decor";
	brickModTerRockSmallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/rock_small";
}
if(isObject(brickModTerBush1Data))
{
	brickModTerBush1Data.category = "ModTer";
	brickModTerBush1Data.subCategory = "Decor";
	brickModTerBush1Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/bush1";
}
if(isObject(brickModTerMushroomLargeData))
{
	brickModTerMushroomLargeData.category = "ModTer";
	brickModTerMushroomLargeData.subCategory = "Decor";
	brickModTerMushroomLargeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/mushroom_large";
}
if(isObject(brickModTerMushroomMediumData))
{
	brickModTerMushroomMediumData.category = "ModTer";
	brickModTerMushroomMediumData.subCategory = "Decor";
	brickModTerMushroomMediumData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/mushroom_large";
}
if(isObject(brickModTerMushroomSmallData))
{
	brickModTerMushroomSmallData.category = "ModTer";
	brickModTerMushroomSmallData.subCategory = "Decor";
	brickModTerMushroomSmallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/mushroom_small";
}
if(isObject(brickModTerShellData))
{
	brickModTerShellData.category = "ModTer";
	brickModTerShellData.subCategory = "Decor";
	brickModTerShellData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/shell";
}
if(isObject(brickModTerStarfishData))
{
	brickModTerStarfishData.category = "ModTer";
	brickModTerStarfishData.subCategory = "Decor";
	brickModTerStarfishData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/starfish";
}
if(isObject(brickModTerSanddollarData))
{
	brickModTerSanddollarData.category = "ModTer";
	brickModTerSanddollarData.subCategory = "Decor";
	brickModTerSanddollarData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/sanddollar";
}
if(isObject(brickModTerTreeStump1Data))
{
	brickModTerTreeStump1Data.category = "ModTer";
	brickModTerTreeStump1Data.subCategory = "Decor";
	brickModTerTreeStump1Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/treestump1";
}
if(isObject(brickModTerTreeStump2Data))
{
	brickModTerTreeStump2Data.category = "ModTer";
	brickModTerTreeStump2Data.subCategory = "Decor";
	brickModTerTreeStump2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/treestump2";
}

/////////test bricks/////////

if(isObject(brickModTerTestData))
{
	brickModTerTestData.category = "ModTer";
	brickModTerTestData.subCategory = "Decor";
	brickModTerTestData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/test";
}
if(isObject(brickModTerTest2Data))
{
	brickModTerTest2Data.category = "ModTer";
	brickModTerTest2Data.subCategory = "Decor";
	brickModTerTest2Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/test";
}
if(isObject(brickModTerTest3Data))
{
	brickModTerTest3Data.category = "ModTer";
	brickModTerTest3Data.subCategory = "Decor";
	brickModTerTest3Data.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/Decor/test";
}