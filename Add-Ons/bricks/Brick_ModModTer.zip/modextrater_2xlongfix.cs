if($AddOnLoaded__["Brick_ModTer_siba"] $= "")
	return;

datablock fxDTSBrickData(brick2WedgeLongL1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongWLFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongWedge L Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongR1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongWRFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongWedge R Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCALFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerA L Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCARFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerA R Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBLFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerB L Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR1FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBRFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerB R Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongL5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongWLSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongWedge L Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongR5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongWRSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongWedge R Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCALSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerA L Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCARSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerA R Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBLSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerB L Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR5FixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBRSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Fixed";
	uiName = "2x LongCornerB R Steep Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData(brick2CornerALongL1invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCALinvFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorA L Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR1invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCARinvFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorA R Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL1invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBLinvFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorB L Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR1invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBRinvFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorB R Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL5invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCALinvSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorA L Steep Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR5invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCARinvSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorA R Steep Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL5invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBLinvSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorB L Steep Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR5invFixedData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLongFix/2cLongCBRinvSteepFix.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv Fixed";
	uiName = "2x LCorB R Steep Inv. Fixed";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};