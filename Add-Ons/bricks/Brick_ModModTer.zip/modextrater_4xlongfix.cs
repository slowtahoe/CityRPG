if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4WedgeLongL1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWLFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge L Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWLCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWRFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge R Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWRCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCALFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA L Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCARFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA R Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBLFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB L Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBRFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB R Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongL5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWLSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge L Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWLSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWLSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWRSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge R Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWRSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWRSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCALSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA L Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCARSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA R Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBLSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB L Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBRSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB R Steep Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}
if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4WedgeLongL3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWL1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge L 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongWR1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongWedge R 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCAL1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA L 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCAL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCAR1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerA R 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCAR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBL1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB L 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBR1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Fixed";
		uiName = "4x LongCornerB R 1/2h Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4CornerALongL1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCALinvFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA L Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCARinvFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA R Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBLinvFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB L Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBRinvFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB R Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCALinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA L Steep Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCARinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA R Steep Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBLinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB L Steep Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBRinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB R Steep Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}
if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4CornerALongL3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCALinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA L 1/2h Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCARinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorA R 1/2h Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBLinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB L 1/2h Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLongFix/4cLongCBRinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv Fixed";
		uiName = "4x LCorB R 1/2h Inv. Fixed";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}