//2x2x5
if(isObject(brickModter2x2x5CubeData))
{
	//brickModter2x2x5CubeData.uiName = "2x Cube";
	brickModter2x2x5CubeData.category = "ModTer";
	brickModter2x2x5CubeData.subCategory = "2x";
	brickModter2x2x5CubeData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8c";

}

if(isObject(brickModter2x2x5WedgeData))
{
	//brickModter2x2x5WedgeData.uiName = "2x Wedge";
	brickModter2x2x5WedgeData.category = "ModTer";
	brickModter2x2x5WedgeData.subCategory = "2x";
	brickModter2x2x5WedgeData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cW.blb";
	brickModter2x2x5WedgeData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cW";
}

if(isObject(brickModter2x2x5RampData))
{
	//brickModter2x2x5RampData.uiName = "2x Ramp";
	brickModter2x2x5RampData.category = "ModTer";
	brickModter2x2x5RampData.subCategory = "2x";
	brickModter2x2x5RampData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cR";
}

if(isObject(brickModter2x2x5SlantUpData))
{
	//brickModter2x2x5SlantUpData.uiName = "2x CornerA";
	brickModter2x2x5SlantUpData.category = "ModTer";
	brickModter2x2x5SlantUpData.subCategory = "2x";
	brickModter2x2x5SlantUpData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCA.blb";
	brickModter2x2x5SlantUpData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCA";
}

if(isObject(brickModter2x2x5SlantUpInvData))
{
	//brickModter2x2x5SlantUpInvData.uiName = "2x CornerB";
	brickModter2x2x5SlantUpInvData.category = "ModTer";
	brickModter2x2x5SlantUpInvData.subCategory = "2x";
	brickModter2x2x5SlantUpInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCB.blb";
	brickModter2x2x5SlantUpInvData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCB";
}

if(isObject(brickModter2x2x5CornerUpData))
{
	//brickModter2x2x5CornerUpData.uiName = "2x CornerC";
	brickModter2x2x5CornerUpData.category = "ModTer";
	brickModter2x2x5CornerUpData.subCategory = "2x";
	brickModter2x2x5CornerUpData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCC.blb";
	brickModter2x2x5CornerUpData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCC";
}

if(isObject(brickModter2x2x5CornerUpInvData))
{
	//brickModter2x2x5CornerUpInvData.uiName = "2x CornerD";
	brickModter2x2x5CornerUpInvData.category = "ModTer";
	brickModter2x2x5CornerUpInvData.subCategory = "2x";
	brickModter2x2x5CornerUpInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCD.blb";
	brickModter2x2x5CornerUpInvData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCD";
}

if(isObject(brickModter2x2x5RampInvData))
{
	//brickModter2x2x5RampInvData.uiName = "2x Ramp Inv.";
	brickModter2x2x5RampInvData.category = "ModTer";
	brickModter2x2x5RampInvData.subCategory = "2x Inv";
	brickModter2x2x5RampInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cRinv";
}

if(isObject(brickModter2x2x5SlantDownData))
{
	//brickModter2x2x5SlantDownData.uiName = "2x CorA Inv.";
	brickModter2x2x5SlantDownData.category = "ModTer";
	brickModter2x2x5SlantDownData.subCategory = "2x Inv";
	brickModter2x2x5SlantDownData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCAinv.blb";
	brickModter2x2x5SlantDownData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCAinv";
}

if(isObject(brickModter2x2x5SlantDownInvData))
{
	//brickModter2x2x5SlantDownInvData.uiName = "2x CorB Inv.";
	brickModter2x2x5SlantDownInvData.category = "ModTer";
	brickModter2x2x5SlantDownInvData.subCategory = "2x Inv";
	brickModter2x2x5SlantDownInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCBinv.blb";
	brickModter2x2x5SlantDownInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCBinv";
}

if(isObject(brickModter2x2x5CornerDownData))
{
	//brickModter2x2x5CornerDownData.uiName = "2x CorC Inv.";
	brickModter2x2x5CornerDownData.category = "ModTer";
	brickModter2x2x5CornerDownData.subCategory = "2x Inv";
	brickModter2x2x5CornerDownData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCCinv.blb";
	brickModter2x2x5CornerDownData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCCinv";
}

if(isObject(brickModter2x2x5CornerDownInvData))
{
	//brickModter2x2x5CornerDownInvData.uiName = "2x CorD Inv.";
	brickModter2x2x5CornerDownInvData.category = "ModTer";
	brickModter2x2x5CornerDownInvData.subCategory = "2x Inv";
	brickModter2x2x5CornerDownInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCDinv.blb";
	brickModter2x2x5CornerDownInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCDinv";
}

//2xFiller
if(isObject(brickModter2x4x10CubeData))
{
	brickModter2x4x10CubeData.category = "ModTer";
	brickModter2x4x10CubeData.subCategory = "Filler";
	brickModter2x4x10CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x4 V";
}

if(isObject(brickModter2x8x5CubeData))
{
	brickModter2x8x5CubeData.category = "ModTer";
	brickModter2x8x5CubeData.subCategory = "Filler";
	brickModter2x8x5CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x H";
}

if(isObject(brickModter2x4x5CubeData))
{
	brickModter2x4x5CubeData.category = "ModTer";
	brickModter2x4x5CubeData.subCategory = "Filler";
	brickModter2x4x5CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x H";
}

if(isObject(brickModter2x2x20CubeData))
{
	brickModter2x2x20CubeData.category = "ModTer";
	brickModter2x2x20CubeData.subCategory = "Filler";
	brickModter2x2x20CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x V";
}

if(isObject(brickModter2x2x10CubeData))
{
	//brickModter2x2x10CubeData.uiName = "2x Cube Steep";
	brickModter2x2x10CubeData.category = "ModTer";
	brickModter2x2x10CubeData.subCategory = "2x";
	brickModter2x2x10CubeData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cSteep";
}

//4x4x5
if(isObject(brickModter4x4x5CubeData))
{
	brickModter4x4x5CubeData.category = "ModTer";
	brickModter4x4x5CubeData.subCategory = "4x";
	brickModter4x4x5CubeData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8c1-2";
}

if(isObject(brickModter4x4x5WedgeData))
{
	brickModter4x4x5WedgeData.category = "ModTer";
	brickModter4x4x5WedgeData.subCategory = "4x";
	brickModter4x4x5WedgeData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cW1-2";
}

if(isObject(brickModter4x4x5RampData))
{
	brickModter4x4x5RampData.category = "ModTer";
	brickModter4x4x5RampData.subCategory = "4x";
	brickModter4x4x5RampData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cR1-2";
}

if(isObject(brickModter4x4x5SlantUpData))
{
	//brickModter4x4x5SlantUpData.uiName = "4x CornerA 1/2h";
	brickModter4x4x5SlantUpData.category = "ModTer";
	brickModter4x4x5SlantUpData.subCategory = "4x";
	brickModter4x4x5SlantUpData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCA1-2.blb";
	brickModter4x4x5SlantUpData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCA1-2";
}

if(isObject(brickModter4x4x5SlantUpInvData))
{
	//brickModter4x4x5SlantUpInvData.uiName = "4x CornerB 1/2h";
	brickModter4x4x5SlantUpInvData.category = "ModTer";
	brickModter4x4x5SlantUpInvData.subCategory = "4x";
	brickModter4x4x5SlantUpInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCB1-2.blb";
	brickModter4x4x5SlantUpInvData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCB1-2";
}

if(isObject(brickModter4x4x5CornerUpData))
{
	//brickModter4x4x5CornerUpData.uiName = "4x CornerC 1/2h";
	brickModter4x4x5CornerUpData.category = "ModTer";
	brickModter4x4x5CornerUpData.subCategory = "4x";
	brickModter4x4x5CornerUpData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCC1-2.blb";
	brickModter4x4x5CornerUpData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCC1-2";
}

if(isObject(brickModter4x4x5CornerUpInvData))
{
	//brickModter4x4x5CornerUpInvData.uiName = "4x CornerD 1/2h";
	brickModter4x4x5CornerUpInvData.category = "ModTer";
	brickModter4x4x5CornerUpInvData.subCategory = "4x";
	brickModter4x4x5CornerUpInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCD1-2.blb";
	brickModter4x4x5CornerUpInvData.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCD1-2";
}

if(isObject(brickModter4x4x5RampInvData))
{
	brickModter4x4x5RampInvData.category = "ModTer";
	brickModter4x4x5RampInvData.subCategory = "4x Inv";
	brickModter4x4x5RampInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cRinv1-2";
}

if(isObject(brickModter4x4x5SlantDownData))
{
	//brickModter4x4x5SlantDownData.uiName = "4x CorA 1/2h Inv.";
	brickModter4x4x5SlantDownData.category = "ModTer";
	brickModter4x4x5SlantDownData.subCategory = "4x Inv";
	brickModter4x4x5SlantDownData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCAinv1-2.blb";
	brickModter4x4x5SlantDownData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCAinv1-2";
}

if(isObject(brickModter4x4x5SlantDownInvData))
{
	//brickModter4x4x5SlantDownInvData.uiName = "4x CorB 1/2h Inv.";
	brickModter4x4x5SlantDownInvData.category = "ModTer";
	brickModter4x4x5SlantDownInvData.subCategory = "4x Inv";
	brickModter4x4x5SlantDownInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBinv1-2.blb";
	brickModter4x4x5SlantDownInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCBinv1-2";
}

if(isObject(brickModter4x4x5CornerDownData))
{
	//brickModter4x4x5CornerDownData.uiName = "4x CorC 1/2h Inv.";
	brickModter4x4x5CornerDownData.category = "ModTer";
	brickModter4x4x5CornerDownData.subCategory = "4x Inv";
	brickModter4x4x5CornerDownData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCinv1-2.blb";
	brickModter4x4x5CornerDownData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCCinv1-2";
}

if(isObject(brickModter4x4x5CornerDownInvData))
{
	//brickModter4x4x5CornerDownInvData.uiName = "4x CorD 1/2h Inv.";
	brickModter4x4x5CornerDownInvData.category = "ModTer";
	brickModter4x4x5CornerDownInvData.subCategory = "4x Inv";
	brickModter4x4x5CornerDownInvData.brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDinv1-2.blb";
	brickModter4x4x5CornerDownInvData.iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCDinv1-2";
}

//4xFiller
if(isObject(brickModter4x8x5Cubedata))
{
	brickModter4x8x5Cubedata.category = "ModTer";
	brickModter4x8x5Cubedata.subCategory = "Filler";
	brickModter4x8x5Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h 2x H";
}

if(isObject(brickModter4x12x5Cubedata))
{
	brickModter4x12x5Cubedata.category = "ModTer";
	brickModter4x12x5Cubedata.subCategory = "Filler";
	brickModter4x12x5Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h 3x H";
}

if(isObject(brickModter4x16x5Cubedata))
{
	brickModter4x16x5Cubedata.category = "ModTer";
	brickModter4x16x5Cubedata.subCategory = "Filler";
	brickModter4x16x5Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h 4x H";
}

if(isObject(brickModter4x8x5Rampdata))
{
	brickModter4x8x5Rampdata.category = "ModTer";
	brickModter4x8x5Rampdata.subCategory = "Filler";
	brickModter4x8x5Rampdata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h Ramp 2x H";
}

if(isObject(brickModter4x12x5Rampdata))
{
	brickModter4x12x5Rampdata.category = "ModTer";
	brickModter4x12x5Rampdata.subCategory = "Filler";
	brickModter4x12x5Rampdata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h Ramp 3x H";
}

if(isObject(brickModter4x16x5Rampdata))
{
	brickModter4x16x5Rampdata.category = "ModTer";
	brickModter4x16x5Rampdata.subCategory = "Filler";
	brickModter4x16x5Rampdata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x 1-2h Ramp 4x H";
}

if(isObject(brickModter4x8x20Cubedata))
{
	brickModter4x8x20Cubedata.category = "ModTer";
	brickModter4x8x20Cubedata.subCategory = "Filler";
	brickModter4x8x20Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x4 V";
}

if(isObject(brickModter4x16x10Cubedata))
{
	brickModter4x16x10Cubedata.category = "ModTer";
	brickModter4x16x10Cubedata.subCategory = "Filler";
brickModter4x16x10Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x H";
}

if(isObject(brickModter4x8x10Cubedata))
{
	brickModter4x8x10Cubedata.category = "ModTer";
	brickModter4x8x10Cubedata.subCategory = "Filler";
	brickModter4x8x10Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x H";
}

if(isObject(brickModter4x4x40Cubedata))
{
	brickModter4x4x40Cubedata.category = "ModTer";
	brickModter4x4x40Cubedata.subCategory = "Filler";
	brickModter4x4x40Cubedata.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x V";
}

if(isObject(brickModter4x4x20Cubedata))
{
	//brickModter4x4x20Cubedata.uiName = "4x Cube Steep";
	brickModter4x4x20Cubedata.category = "ModTer";
	brickModter4x4x20Cubedata.subCategory = "4x";
	brickModter4x4x20Cubedata.iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cSteep";
}

//fence
if(isObject(brickModter2x2FenceEndData))
{
	brickModter2x2FenceEndData.category = "ModTer";
	brickModter2x2FenceEndData.subCategory = "Fence";
	brickModter2x2FenceEndData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x2FenceEnd";
}

if(isObject(brickModter2x2FenceData))
{
	brickModter2x2FenceData.category = "ModTer";
	brickModter2x2FenceData.subCategory = "Fence";
	brickModter2x2FenceData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x2Fence";
}

if(isObject(brickModter2x4FenceData))
{
	brickModter2x4FenceData.category = "ModTer";
	brickModter2x4FenceData.subCategory = "Fence";
	brickModter2x4FenceData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x4Fence";
}

if(isObject(brickModter2x6FenceData))
{
	brickModter2x6FenceData.category = "ModTer";
	brickModter2x6FenceData.subCategory = "Fence";
	brickModter2x6FenceData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x6Fence";
}

if(isObject(brickModter2x8FenceData))
{
	brickModter2x8FenceData.category = "ModTer";
	brickModter2x8FenceData.subCategory = "Fence";
	brickModter2x8FenceData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x8Fence";
}

if(isObject(brickModter2x16FenceData))
{
	brickModter2x16FenceData.category = "ModTer";
	brickModter2x16FenceData.subCategory = "Fence";
	brickModter2x16FenceData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x16Fence";
}

if(isObject(brickModter2x2FenceCData))
{
	brickModter2x2FenceCData.category = "ModTer";
	brickModter2x2FenceCData.subCategory = "Fence";
	brickModter2x2FenceCData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x2FenceC";
}

if(isObject(brickModter2x2FenceTData))
{
	brickModter2x2FenceTData.category = "ModTer";
	brickModter2x2FenceTData.subCategory = "Fence";
	brickModter2x2FenceTData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x2FenceT";
}

//adapter
if(isObject(brickModter2xto4xAdapterLData))
{
	brickModter2xto4xAdapterLData.category = "ModTer";
	brickModter2xto4xAdapterLData.subCategory = "Adapter";
	brickModter2xto4xAdapterLData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x to 4x Adapter L";
}

if(isObject(brickModter2xto4xAdapterRData))
{
	brickModter2xto4xAdapterRData.category = "ModTer";
	brickModter2xto4xAdapterRData.subCategory = "Adapter";
	brickModter2xto4xAdapterRData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/2x to 4x Adapter R";
}

if(isObject(brickModter4xto2xAdapterLData))
{
	brickModter4xto2xAdapterLData.category = "ModTer";
	brickModter4xto2xAdapterLData.subCategory = "Adapter";
	brickModter4xto2xAdapterLData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x to 2x Adapter L";
}

if(isObject(brickModter4xto2xAdapterRData))
{
	brickModter4xto2xAdapterRData.category = "ModTer";
	brickModter4xto2xAdapterRData.subCategory = "Adapter";
	brickModter4xto2xAdapterRData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x to 2x Adapter R";
}

if(isObject(brickModter4xto8xAdapterLData))
{
	brickModter4xto8xAdapterLData.category = "ModTer";
	brickModter4xto8xAdapterLData.subCategory = "Adapter";
	brickModter4xto8xAdapterLData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x to 8x Adapter L";
}

if(isObject(brickModter4xto8xAdapterRData))
{
	brickModter4xto8xAdapterRData.category = "ModTer";
	brickModter4xto8xAdapterRData.subCategory = "Adapter";
	brickModter4xto8xAdapterRData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x to 8x Adapter R";
}

if(isObject(brickModter8xto4xAdapterLData))
{
	brickModter8xto4xAdapterLData.category = "ModTer";
	brickModter8xto4xAdapterLData.subCategory = "Adapter";
	brickModter8xto4xAdapterLData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8x to 4x Adapter L";
}

if(isObject(brickModter8xto4xAdapterRData))
{
	brickModter8xto4xAdapterRData.category = "ModTer";
	brickModter8xto4xAdapterRData.subCategory = "Adapter";
	brickModter8xto4xAdapterRData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8x to 4x Adapter R";
}

//misc
if(isObject(brickModter16x16x5CubeData))
{
	brickModter16x16x5CubeData.category = "ModTer";
	brickModter16x16x5CubeData.subCategory = "16x";
	brickModter16x16x5CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16c1-8";
}

if(isObject(brickModter32x32x5CubeData))
{
	brickModter32x32x5CubeData.category = "ModTer";
	brickModter32x32x5CubeData.subCategory = "32x";
	brickModter32x32x5CubeData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32c1-16";
}

if(isObject(brickModter4x12x10BenchData))
{
	brickModter4x12x10BenchData.category = "ModTer";
	brickModter4x12x10BenchData.subCategory = "Street Props";
	brickModter4x12x10BenchData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4x12Bench";
}

if(isObject(brickModter32x2x25RailData))
{
	brickModter32x2x25RailData.category = "ModTer";
	brickModter32x2x25RailData.subCategory = "Filler";
	brickModter32x2x25RailData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/32xRail1-4";
}

if(isObject(brickModter16x2x15RailData))
{
	brickModter16x2x15RailData.category = "ModTer";
	brickModter16x2x15RailData.subCategory = "Filler";
	brickModter16x2x15RailData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/16xRail1-4";
}

if(isObject(brickModter8x2x10RailData))
{
	brickModter8x2x10RailData.category = "ModTer";
	brickModter8x2x10RailData.subCategory = "Filler";
	brickModter8x2x10RailData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8xRail1-4";
}

if(isObject(brickModter2x4x1StreetbulbData))
{
	brickModter2x4x1StreetbulbData.category = "ModTer";
	brickModter2x4x1StreetbulbData.subCategory = "Street Props";
	brickModter2x4x1StreetbulbData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/Streetbulb";
}

if(isObject(brickModter2x26x46StreetlightData))
{
	brickModter2x26x46StreetlightData.category = "ModTer";
	brickModter2x26x46StreetlightData.subCategory = "Street Props";
	brickModter2x26x46StreetlightData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/Streetlight";
}

if(isObject(brickModter2x26x46StreetlightDoubleData))
{
	brickModter2x26x46StreetlightDoubleData.category = "ModTer";
	brickModter2x26x46StreetlightDoubleData.subCategory = "Street Props";
	brickModter2x26x46StreetlightDoubleData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/StreetlightDouble";
}

if(isObject(brickModter8x8x5RailroadData))
{
	brickModter8x8x5RailroadData.category = "ModTer";
	brickModter8x8x5RailroadData.subCategory = "Railroad";
	brickModter8x8x5RailroadData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8xRailroad";
}

if(isObject(brickModter8x8x5RailroadCrossingData))
{
	brickModter8x8x5RailroadCrossingData.category = "ModTer";
	brickModter8x8x5RailroadCrossingData.subCategory = "Railroad";
	brickModter8x8x5RailroadCrossingData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8xRailroadCrossing";
}

if(isObject(brickModter8x8x5RailroadRampData))
{
	brickModter8x8x5RailroadRampData.category = "ModTer";
	brickModter8x8x5RailroadRampData.subCategory = "Railroad";
	brickModter8x8x5RailroadRampData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8xRailroadRamp";
}

if(isObject(brickModter4xCubeWallData))
{
	brickModter4xCubeWallData.category = "ModTer";
	brickModter4xCubeWallData.subCategory = "Filler";
	brickModter4xCubeWallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/4xCubeWall";
}

if(isObject(brickModter8xCubeWallData))
{
	brickModter8xCubeWallData.category = "ModTer";
	brickModter8xCubeWallData.subCategory = "Filler";
	brickModter8xCubeWallData.iconName = "Add-Ons/Brick_ModModTer/BrickIcons/siba/8xCubeWall";
}
