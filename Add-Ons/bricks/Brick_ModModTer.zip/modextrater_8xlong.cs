datablock fxDTSBrickData(brick8WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick8CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerC L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerC R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerD L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerD R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick8WedgeLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR3-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-2.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWL1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWR1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAL1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCAR1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCAR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBL1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBR1-4.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongWedge R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongWRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerA R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "8x Long";
	uiName = "8x LongCornerB R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick8CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerC L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerC R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerD L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick8CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "8x Long";
// 	uiName = "8x LongCornerD R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick8CornerALongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick8CornerCLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorC L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerCLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorC R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerDLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorD L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerDLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorD R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	datablock fxDTSBrickData(brick8CornerALongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCALinvSteep.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCALinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerALongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCARinvSteep.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorA R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCARinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBLinvSteep.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBLinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8CornerBLongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCBRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "8x Long Inv";
		uiName = "8x LCorB R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCBRinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick8CornerCLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorC L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerCLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCCRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorC R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCCRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCCRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerDLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorD L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick8CornerDLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8xLong/8cLongCDRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "8x Long Inv";
	// 	uiName = "8x LCorD R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCDRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8xLong/8cLongCDRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
}