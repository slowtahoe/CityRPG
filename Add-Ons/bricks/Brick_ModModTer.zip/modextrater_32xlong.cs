datablock fxDTSBrickData(brick32WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerC L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerC R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerD L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerD R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick32WedgeLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBL3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBR3-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBL1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBR1-2.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCAR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCAR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCAR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBL1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBR1-4.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongWedge R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerA R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "32x Long";
	uiName = "32x LongCornerB R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick32CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerC L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerC R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerD L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick32CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "32x Long";
// 	uiName = "32x LongCornerD R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick32WedgeLongL6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-8.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "32x LongWedge L 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongR6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-8.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "32x LongWedge R 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongL7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWL1-16.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "32x LongWedge L 1/16h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWL1-16";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWL1-16Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32WedgeLongR7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongWR1-16.blb";
		category = "ModTer 2";
		subCategory = "32x Long";
		uiName = "32x LongWedge R 1/16h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongWR1-16";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongWR1-16Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick32CornerALongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALinv.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARinv.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLinv.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRinv.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick32CornerCLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorC L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerCLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorC R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerDLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorD L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerDLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorD R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	datablock fxDTSBrickData(brick32CornerALongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCALinvSteep.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCALinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCALinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerALongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCARinvSteep.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorA R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCARinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCARinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBLinvSteep.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBLinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBLinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32CornerBLongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCBRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "32x Long Inv";
		uiName = "32x LCorB R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCBRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCBRinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick32CornerCLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorC L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerCLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCCRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorC R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCCRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCCRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerDLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorD L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick32CornerDLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32xLong/32cLongCDRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "32x Long Inv";
	// 	uiName = "32x LCorD R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32xLong/32cLongCDRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32xLong/32cLongCDRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
}