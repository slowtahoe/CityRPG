//function made by eagle517, thanks eagle517
//mostly gets used in the companion add-on
function isAddOnEnabled(%addOnName)
{
	if ($GameModeArg $= "")
		return $AddOn__[getSafeVariableName(%addOnName)] == 1;
	else {
		%count = $GameMode::AddOnCount;
		for (%i = 0; %i < %count; %i++) {
			if ($GameMode::AddOn[%i] $= %addOnName)
				return true;
		}
	}

	return false;
}

if(isAddOnEnabled("Brick_ModTer_BasicPack") && !isObject(brick64Cube1Data) || isAddOnEnabled("Brick_ModTer_InvertedPack") && !isObject(brick64Ramp1InvData) || isAddOnEnabled("Brick_ModTer_4xPack") && !isObject(brick4Cube1Data) || isAddOnEnabled("Brick_ModTer_siba") && !isObject(brickModter2x4x10CubeData) || isAddOnEnabled("Brick_ModTer_DecorPack") && !isObject(brick8cWatertestData))
{
	schedule(1000, 0, messageAll, '', "ERROR: Place ModModTer after all other ModTer packs in the gamemode.txt file!");
	return;
}

exec("./modter_basic.cs");
exec("./modter_inverted.cs");
exec("./modter_4x.cs");
exec("./modter_siba.cs");
exec("./modter_decor.cs");
exec("./modextrater_32xlong.cs");
exec("./modextrater_16xlong.cs");
exec("./modextrater_8xlong.cs");
exec("./modextrater_4xlong.cs");
exec("./modextrater_4xlongfix.cs");
exec("./modextrater_2xlong.cs");
exec("./modextrater_2xlongfix.cs");
exec("./modextrater_extend.cs");
exec("./modextrater_4xfix.cs");
exec("./modextrater_2xfix.cs");