/////////////////////////////////////////////////////////////////////2x////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick2Wedge5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cWSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x Wedge Steep";
			iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cWSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cWSteepCol.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick2Ramp5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cRSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x Ramp Steep";
			iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cRSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cRSteepCol.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick2Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cRinvSteep.blb";
		category = "ModTer";
		subCategory = "2x Inv";
		uiName = "2x Ramp Steep Inv.";
			iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cRinvSteepCol.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick2CornerA5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCASteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerA Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCASteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCASteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerB5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCBSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerB Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCBSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCBSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerC5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCCSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerC Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCCSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCCSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerD5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCDSteep.blb";
		category = "ModTer";
		subCategory = "2x";
		uiName = "2x CornerD Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCDSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCDSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerA5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCAinvSteep.blb";
		category = "ModTer";
		subCategory = "2x Inv";
		uiName = "2x CorA Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCAinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCAinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerB5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCBinvSteep.blb";
		category = "ModTer";
		subCategory = "2x Inv";
		uiName = "2x CorB Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCBinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCBinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerC5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCCinvSteep.blb";
		category = "ModTer";
		subCategory = "2x Inv";
		uiName = "2x CorC Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCCinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCCinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick2CornerD5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/2x/2cCDinvSteep.blb";
		category = "ModTer";
		subCategory = "2x Inv";
		uiName = "2x CorD Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCDinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2x/2cCDinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

/////////////////////////////////////////////////////////////////////4x////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brickModter4x4x20Cubedata)
	{
		uiName = "4x Cube 2x V";
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cSteep";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cWSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Wedge Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cWSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cWSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cRSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x Ramp Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCASteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerA Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCASteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCASteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerB Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCBSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCBSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerC Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCCSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCCSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDSteep.blb";
		category = "ModTer";
		subCategory = "4x";
		uiName = "4x CornerD Steep";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCDSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCDSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cRinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCAinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CorA Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCAinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCAinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCBinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CorB Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCBinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCBinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCCinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CorC Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCCinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCCinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4cCDinvSteep.blb";
		category = "ModTer";
		subCategory = "4x Inv";
		uiName = "4x CorD Steep Inv.";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCDinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCDinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};





	datablock fxDTSBrickData(brick4x2Ramp1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cR.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4x2Ramp5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp Steep";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4x2Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4x2Ramp3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cR1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp 1/2h";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cR1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4x/4x2cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

/////////////////////////////////////////////////////////////////////8x////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData(brick8x4Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x4 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8x4Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x4 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8x4Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x4 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8x4Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x4 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick8x4Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "8x4 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick8x4Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x4 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8x4Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x4 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8x4Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x4 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8x4Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x4 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick8x4Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/8x/8x4cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "8x4 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/8x/8x4cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick16Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16cW1-8.blb";
		category = "ModTer";
		subCategory = "16x";
		uiName = "16x Wedge 1/8h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16cW1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16cW1-8Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}

datablock fxDTSBrickData(brick16x8Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x8 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16x8Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x8 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16x8Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x8 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16x8Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x8 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16x8Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "16x8 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick16x8Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x8 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16x8Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x8 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16x8Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x8 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16x8Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x8 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16x8Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16x/16x8cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "16x8 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16x/16x8cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16x/16x8cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick32Cube6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32c1-8.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Cube 1/8h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32c1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32c1-8Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick32Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32cW1-8.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Wedge 1/8h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32cW1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32cW1-8Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick32Wedge7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32cW1-16.blb";
		category = "ModTer";
		subCategory = "32x";
		uiName = "32x Wedge 1/16h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32cW1-16";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32cW1-16Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}

datablock fxDTSBrickData(brick32x16Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "32x16 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32x16Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "32x16 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32x16Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "32x16 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32x16Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "32x16 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick32x16Ramp5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRSteep.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "32x16 Ramp Steep";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRSteep";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRSteepCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick32x16Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "32x16 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32x16Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "32x16 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32x16Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "32x16 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32x16Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "32x16 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick32x16Ramp5InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/32x/32x16cRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "32x16 Ramp Steep Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/32x/32x16cRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/32x/32x16cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick64Cube6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-8.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Cube 1/8h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64c1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64c1-8Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Cube7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-16.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Cube 1/16h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64c1-16";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64c1-16Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Cube8Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64c1-32.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Cube 1/32h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64c1-32";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64c1-32Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-8.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Wedge 1/8h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64cW1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64cW1-8Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge7Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-16.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Wedge 1/16h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64cW1-16";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64cW1-16Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};

	datablock fxDTSBrickData(brick64Wedge8Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64cW1-32.blb";
		category = "ModTer";
		subCategory = "64x";
		uiName = "64x Wedge 1/32h";
			iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64cW1-32";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64cW1-32Col.dts";
			hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}

datablock fxDTSBrickData(brick64x32Ramp1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x32 Ramp";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRCol.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64x32Ramp2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR3-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x32 Ramp 3/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR3-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR3-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64x32Ramp3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR1-2.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x32 Ramp 1/2h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR1-2";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR1-2Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick64x32Ramp4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cR1-4.blb";
	category = "ModTer 2";
	subCategory = "Ramp";
	uiName = "64x32 Ramp 1/4h";
	iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cR1-4";
	CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cR1-4Col.dts";
	hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick64x32Ramp1InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x32 Ramp Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick64x32Ramp2InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv3-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x32 Ramp 3/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv3-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick64x32Ramp3InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv1-2.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x32 Ramp 1/2h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick64x32Ramp4InvData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/64x/64x32cRinv1-4.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "64x32 Ramp 1/4h Inv.";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/64x/64x32cRinv1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/64x/64x32cRinv1-4Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	isWaterBrick = true;
	};
}