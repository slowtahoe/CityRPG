if($AddOnLoaded__["Brick_ModTer_siba"] $= "")
	return;

datablock fxDTSBrickData(brick2WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongWL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongWedge L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongWR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongWedge R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerA L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerA R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerB L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerB R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongWedge L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongWedge R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongWRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerA L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerA R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerB L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long";
	uiName = "2x LongCornerB R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

datablock fxDTSBrickData(brick2CornerALongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCALinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorA L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCARinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorA R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBLinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorB L Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR1invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBRinv.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorB R Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRinvCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCALinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorA L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCALinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerALongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCARinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorA R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCARinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongL5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBLinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorB L Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBLinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};
datablock fxDTSBrickData(brick2CornerBLongR5invData)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/2xLong/2cLongCBRinvSteep.blb";
	category = "ModTer 2";
	subCategory = "2x Long Inv";
	uiName = "2x LCorB R Steep Inv.";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinvSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/2xLong/2cLongCBRinvSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
};