datablock fxDTSBrickData(brick16WedgeLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBL.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB L";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBL";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR1Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBR.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB R";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBR";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCL.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerC L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCR.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerC R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDL.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerD L";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDL";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDLCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR1Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDR.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerD R";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDR";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDRCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
datablock fxDTSBrickData(brick16WedgeLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBL3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB L 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBL3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBL3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR2Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBR3-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB R 3/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBR3-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBR3-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBL1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB L 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBL1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBL1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR3Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBR1-2.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB R 1/2h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBR1-2";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBR1-2Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCAR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCAR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCAR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBL1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB L 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBL1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBL1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR4Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBR1-4.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB R 1/4h";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBR1-4";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBR1-4Col.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWLSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16WedgeLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWRSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongWedge R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerALongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerA R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongL5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB L Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brick16CornerBLongR5Data)
{
	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRSteep.blb";
	category = "ModTer 2";
	subCategory = "16x Long";
	uiName = "16x LongCornerB R Steep";
        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRSteep";
		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRSteepCol.dts";
        hasPrint = 1;
	printAspectRatio = "ModTer";
	isWaterBrick = true;
};
// datablock fxDTSBrickData(brick16CornerCLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerC L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerCLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerC R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongL5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDLSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerD L Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDLSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDLSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };
// datablock fxDTSBrickData(brick16CornerDLongR5Data)
// {
// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDRSteep.blb";
// 	category = "ModTer 2";
// 	subCategory = "16x Long";
// 	uiName = "16x LongCornerD R Steep";
//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDRSteep";
// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDRSteepCol.dts";
//         hasPrint = 1;
// 	printAspectRatio = "ModTer";
// 	isWaterBrick = true;
// };

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick16WedgeLongL6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWL1-8.blb";
		category = "ModTer 2";
		subCategory = "16x Long";
		uiName = "16x LongWedge L 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWL1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWL1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16WedgeLongR6Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongWR1-8.blb";
		category = "ModTer 2";
		subCategory = "16x Long";
		uiName = "16x LongWedge R 1/8h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongWR1-8";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongWR1-8Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_InvertedPack"] == 1)
{
	datablock fxDTSBrickData(brick16CornerALongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALinv.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARinv.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLinv.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRinv.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick16CornerCLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorC L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerCLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorC R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerDLongL1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDLinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorD L Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDLinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDLinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerDLongR1invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDRinv.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorD R Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDRinv";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDRinvCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	datablock fxDTSBrickData(brick16CornerALongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongL2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB L 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongR2invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRinv3-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB R 3/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRinv3-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRinv3-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongL4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB L 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongR4invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRinv1-4.blb";
		Category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB R 1/4h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRinv1-4";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRinv1-4Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCALinvSteep.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCALinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCALinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerALongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCARinvSteep.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorA R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCARinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCARinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBLinvSteep.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBLinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBLinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick16CornerBLongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCBRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "16x Long Inv";
		uiName = "16x LCorB R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCBRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCBRinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		isWaterBrick = true;
	};
	// datablock fxDTSBrickData(brick16CornerCLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorC L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerCLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCCRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorC R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCCRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCCRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerDLongL5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDLinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorD L Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDLinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDLinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
	// datablock fxDTSBrickData(brick16CornerDLongR5invData)
	// {
	// 	brickFile = "Add-Ons/Brick_ModModTer/Bricks/16xLong/16cLongCDRinvSteep.blb";
	// 	category = "ModTer 2";
	// 	subCategory = "16x Long Inv";
	// 	uiName = "16x LCorD R Steep Inv.";
	//         iconName = "Add-Ons/Brick_ModModTer/BrickIcons/16xLong/16cLongCDRinvSteep";
	// 		CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/16xLong/16cLongCDRinvSteepCol.dts";
	//         hasPrint = 1;
	// 	printAspectRatio = "ModTer";
	// 	isWaterBrick = true;
	// };
}