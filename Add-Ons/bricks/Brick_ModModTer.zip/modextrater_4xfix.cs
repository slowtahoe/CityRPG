if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4Cube5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x Cube Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cSteep";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cWSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x Wedge Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cWSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cWSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x Ramp Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cRSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCASteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerA Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCASteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCASteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerB Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCBSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCBSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerC Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCCSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCCSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerD Steep Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Steep/8cCDSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCDSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}
if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4Cube3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4c1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x Cube 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8c1-2";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Wedge3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cW1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x Wedge 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cW1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Wedge.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cR1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x Ramp 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cR1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Ramp.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCA1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerA 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCA1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Slant+.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCB1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerB 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCB1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Slant+ Inv.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCC1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerC 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCC1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Corner+.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCD1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x CornerD 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/1-2/8cCD1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Corner+ Inv.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x Ramp 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cRinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Ramp Inv.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCAinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = " 4x CornerA 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCAinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Slant-.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = " 4x CornerB 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCBinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Slant- Inv.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = " 4x CornerC 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCCinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Corner-.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDinv1-2Fix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = " 4x CornerD 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/1-2/8cCDinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModTer_siba/4x4x5/collision/Corner- Inv.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4Cube1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = " 4x Cube Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8c";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brick4Wedge1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cWFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x Wedge Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cW";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brick4Ramp1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x Ramp Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cR";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp5invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x Ramp Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cRinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerA5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCAinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorA Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCAinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCAinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerB5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorB Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCBinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCBinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerC5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorC Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCCinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCCinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4CornerD5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDinvSteepFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorD Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Steep/8cCDinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4cCDinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4Ramp1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cRinvFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x Ramp Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cRinv";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerA1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCAFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x CornerA Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCA";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCACol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerA1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCAinvFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorA Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCAinv";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCAinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerB1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x CornerB Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCB";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerB1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCBinvFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorB Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCBinv";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerC1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x CornerC Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCC";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerC1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCCinvFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorC Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCCinv";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4CornerD1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDFix.blb";
		category = "ModTer";
		subCategory = "4x Fixed";
		uiName = "4x CornerD Fixed";
		iconName = "Add-Ons/Brick_ModTer_BasicPack/BrickIcons/Full/8cCD";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};

	datablock fxDTSBrickData(brick4CornerD1invFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4cCDinvFix.blb";
		category = "ModTer";
		subCategory = "4x Inv Fixed";
		uiName = "4x CorD Inv. Fixed";
		iconName = "Add-Ons/Brick_ModTer_InvertedPack/BrickIcons/Full/8cCDinv";
		collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};




	datablock fxDTSBrickData(brick4x2Ramp1FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cRFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4x2Ramp5FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cRSteepFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp Steep Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp1InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cRinvFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	
	datablock fxDTSBrickData(brick4x2Ramp5InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cRinvSteepFix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp Steep Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinvSteep";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinvSteepCol.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}

if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4x2Ramp3FixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cR1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "Ramp";
		uiName = "4x2 Ramp 1/2h Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cR1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cR1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
	datablock fxDTSBrickData(brick4x2Ramp3InvFixedData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xFix/4x2cRinv1-2Fix.blb";
		category = "ModTer 2";
		subCategory = "Ramp Inv";
		uiName = "4x2 Ramp 1/2h Inv. Fixed";
		iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8x/8x4cRinv1-2";
		collisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4x/4x2cRinv1-2Col.dts";
		hasPrint = 1;
		printAspectRatio = "ModTer";
	};
}