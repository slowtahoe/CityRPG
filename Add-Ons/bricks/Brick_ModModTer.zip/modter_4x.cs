/////////////////////////////////////////////////////////////////////4x/////////////////////////////////////////////////////////////////////

if(isObject(brick4Cube1Data))
{
	brick4Cube1Data.category = "ModTer";
	brick4Cube1Data.subCategory = "4x";
}

if(isObject(brick4Wedge1Data))
{
	brick4Wedge1Data.category = "ModTer";
	brick4Wedge1Data.subCategory = "4x";
}

if(isObject(brick4Ramp1Data))
{
	brick4Ramp1Data.category = "ModTer";
	brick4Ramp1Data.subCategory = "4x";
}

if(isObject(brick4Ramp1invData))
{
	brick4Ramp1invData.category = "ModTer";
	brick4Ramp1invData.subCategory = "4x Inv";
}

if(isObject(brick4CornerA1Data))
{
	brick4CornerA1Data.category = "ModTer";
	brick4CornerA1Data.subCategory = "4x";
}

if(isObject(brick4CornerA1invData))
{
	brick4CornerA1invData.category = "ModTer";
	brick4CornerA1invData.subCategory = "4x Inv";
	//brick4CornerA1invData.uiName = "4x CorA Inv.";
}

if(isObject(brick4CornerB1Data))
{
	brick4CornerB1Data.category = "ModTer";
	brick4CornerB1Data.subCategory = "4x";
}

if(isObject(brick4CornerB1invData))
{
	brick4CornerB1invData.category = "ModTer";
	brick4CornerB1invData.subCategory = "4x Inv";
	//brick4CornerB1invData.uiName = "4x CorB Inv.";
}

if(isObject(brick4CornerC1Data))
{
	brick4CornerC1Data.category = "ModTer";
	brick4CornerC1Data.subCategory = "4x";
}

if(isObject(brick4CornerC1invData))
{
	brick4CornerC1invData.category = "ModTer";
	brick4CornerC1invData.subCategory = "4x Inv";
	//brick4CornerC1invData.uiName = "4x CorC Inv.";
}

if(isObject(brick4CornerD1Data))
{
	brick4CornerD1Data.category = "ModTer";
	brick4CornerD1Data.subCategory = "4x";
}

if(isObject(brick4CornerD1invData))
{
	brick4CornerD1invData.category = "ModTer";
	brick4CornerD1invData.subCategory = "4x Inv";
	//brick4CornerD1invData.uiName = "4x CorD Inv.";
}