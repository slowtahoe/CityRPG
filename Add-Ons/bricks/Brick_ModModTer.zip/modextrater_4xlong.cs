if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4WedgeLongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWLCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWRCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCAL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCAR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBL.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB L";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBR.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB R";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWLSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWLSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWLSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWRSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWRSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWRSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCALSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCARSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBLSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB L Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBRSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB R Steep";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}
if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4WedgeLongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4WedgeLongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongWR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongWedge R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongWR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongWR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCAL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCAL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCAR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerA R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCAR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCAR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBL1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB L 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBL1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBL1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3Data)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBR1-2.blb";
		category = "ModTer 2";
		subCategory = "4x Long";
		uiName = "4x LongCornerB R 1/2h";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBR1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBR1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}

/////////////////////////////////////////////////////////////////////inv////////////////////////////////////////////////////////////////////

if($AddOnLoaded__["Brick_ModTer_4xPack"] == 1)
{
	datablock fxDTSBrickData(brick4CornerALongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCALinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCARinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBLinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB L Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR1invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBRinv.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB R Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinvCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCALinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCARinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBLinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB L Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR5invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBRinvSteep.blb";
		category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB R Steep Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinvSteep";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinvSteepCol.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}
if($AddOnLoaded__["Brick_ModTer_siba"] == 1)
{
	datablock fxDTSBrickData(brick4CornerALongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCALinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCALinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCALinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerALongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCARinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorA R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCARinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCARinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongL3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBLinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB L 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBLinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBLinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
	datablock fxDTSBrickData(brick4CornerBLongR3invData)
	{
		brickFile = "Add-Ons/Brick_ModModTer/Bricks/4xLong/4cLongCBRinv1-2.blb";
		Category = "ModTer 2";
		subCategory = "4x Long Inv";
		uiName = "4x LCorB R 1/2h Inv.";
	        iconName = "Add-Ons/Brick_ModModTer/BrickIcons/8xLong/8cLongCBRinv1-2";
			CollisionShapeName = "Add-Ons/Brick_ModModTer/Shapes/4xLong/4cLongCBRinv1-2Col.dts";
	        hasPrint = 1;
		printAspectRatio = "ModTer";
		//isWaterBrick = true;
	};
}