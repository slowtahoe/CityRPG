datablock fxDTSBrickData(brick2x2_wooden_ladderData) {
	brickFile = "./2x2_wooden_ladder.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Ladder";
	iconName = "Add-ons/Brick_Ladder/ladder.png";
};