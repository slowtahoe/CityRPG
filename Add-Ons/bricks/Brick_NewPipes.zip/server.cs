//horizontal
datablock fxDTSBrickData(brickPipeCapHorizontalData)
{
	brickFile = "./bricks/horizontal/cap.blb";
	uiName = "Pipe Cap Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_cap";
};
datablock fxDTSBrickData(brickPipeCapEndHorizontalData)
{
	brickFile = "./bricks/horizontal/cap_end.blb";
	uiName = "Pipe Cap End Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_cap_end";
};
datablock fxDTSBrickData(brickPipeEndHorizontalData)
{
	brickFile = "./bricks/horizontal/end.blb";
	uiName = "Pipe End Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_end";
};
datablock fxDTSBrickData(brickPipe1x2EndsHorizontalData)
{
	brickFile = "./bricks/horizontal/1x_2end.blb";
	uiName = "Pipe 1x 2 Ends Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_1x_2end";
};
datablock fxDTSBrickData(brickPipe1x1EndHorizontalData)
{
	brickFile = "./bricks/horizontal/1x_1end.blb";
	uiName = "Pipe 1x 1 End Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_1x_1end";
};
datablock fxDTSBrickData(brickPipe1xHorizontalData)
{
	brickFile = "./bricks/horizontal/1x.blb";
	uiName = "Pipe 1x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_1x";
};
datablock fxDTSBrickData(brickPipe2xHorizontalData)
{
	brickFile = "./bricks/horizontal/2x.blb";
	uiName = "Pipe 2x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_2x";
};
datablock fxDTSBrickData(brickPipe3xHorizontalData)
{
	brickFile = "./bricks/horizontal/3x.blb";
	uiName = "Pipe 3x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_3x";
};
datablock fxDTSBrickData(brickPipe4xHorizontalData)
{
	brickFile = "./bricks/horizontal/4x.blb";
	uiName = "Pipe 4x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_4x";
};
datablock fxDTSBrickData(brickPipe5xHorizontalData)
{
	brickFile = "./bricks/horizontal/5x.blb";
	uiName = "Pipe 5x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_5x";
};
datablock fxDTSBrickData(brickPipe6xHorizontalData)
{
	brickFile = "./bricks/horizontal/6x.blb";
	uiName = "Pipe 6x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_6x";
};
datablock fxDTSBrickData(brickPipe7xHorizontalData)
{
	brickFile = "./bricks/horizontal/7x.blb";
	uiName = "Pipe 7x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_7x";
};
datablock fxDTSBrickData(brickPipe8xHorizontalData)
{
	brickFile = "./bricks/horizontal/8x.blb";
	uiName = "Pipe 8x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_8x";
};
datablock fxDTSBrickData(brickPipe9xHorizontalData)
{
	brickFile = "./bricks/horizontal/9x.blb";
	uiName = "Pipe 9x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_9x";
};
datablock fxDTSBrickData(brickPipe10xHorizontalData)
{
	brickFile = "./bricks/horizontal/10x.blb";
	uiName = "Pipe 10x Horizontal";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_10x";
};

//vertical
datablock fxDTSBrickData(brickPipeCapVerticalDownData)
{
	brickFile = "./bricks/vertical/cap_down.blb";
	uiName = "Pipe Cap Vertical Down";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_cap_down";
};
datablock fxDTSBrickData(brickPipeCapVerticalUpData)
{
	brickFile = "./bricks/vertical/cap_up.blb";
	uiName = "Pipe Cap Vertical Up";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_cap_up";
};
datablock fxDTSBrickData(brickPipeCapEndVerticalDownData)
{
	brickFile = "./bricks/vertical/cap_end_down.blb";
	uiName = "Pipe Cap End Vertical Down";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_cap_end_down";
};
datablock fxDTSBrickData(brickPipeCapEndVerticalUpData)
{
	brickFile = "./bricks/vertical/cap_end_up.blb";
	uiName = "Pipe Cap End Vertical Up";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_cap_end_up";
};
datablock fxDTSBrickData(brickPipeEndVerticalDownData)
{
	brickFile = "./bricks/vertical/end_down.blb";
	uiName = "Pipe End Vertical Down";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_end_down";
};
datablock fxDTSBrickData(brickPipeEndVerticalUpData)
{
	brickFile = "./bricks/vertical/end_up.blb";
	uiName = "Pipe End Vertical Up";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_end_up";
};
datablock fxDTSBrickData(brickPipe1fDoubleEndVerticalDownData)
{
	brickFile = "./bricks/vertical/1f_dend_down.blb";
	uiName = "Pipe 1f Double End Vertical Down";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1f_dend_down";
};
datablock fxDTSBrickData(brickPipe1fDoubleEndVerticalUpData)
{
	brickFile = "./bricks/vertical/1f_dend_up.blb";
	uiName = "Pipe 1f Double End Vertical Up";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1f_dend_up";
};
datablock fxDTSBrickData(brickPipe1fSingleEndVerticalDownData)
{
	brickFile = "./bricks/vertical/1f_end_down.blb";
	uiName = "Pipe 1f Single End Vertical Down";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1f_end_down";
};
datablock fxDTSBrickData(brickPipe1fSingleEndVerticalUpData)
{
	brickFile = "./bricks/vertical/1f_end_up.blb";
	uiName = "Pipe 1f Single End Vertical Up";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1f_end_up";
};
datablock fxDTSBrickData(brickPipe1fVerticalData)
{
	brickFile = "./bricks/vertical/1f.blb";
	uiName = "Pipe 1f Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1f";
};
datablock fxDTSBrickData(brickPipe2fVerticalData)
{
	brickFile = "./bricks/vertical/2f.blb";
	uiName = "Pipe 2f Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_2f";
};
datablock fxDTSBrickData(brickPipe1xVerticalData)
{
	brickFile = "./bricks/vertical/1x.blb";
	uiName = "Pipe 1x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_1x";
};
datablock fxDTSBrickData(brickPipe2xVerticalData)
{
	brickFile = "./bricks/vertical/2x.blb";
	uiName = "Pipe 2x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_2x";
};
datablock fxDTSBrickData(brickPipe3xVerticalData)
{
	brickFile = "./bricks/vertical/3x.blb";
	uiName = "Pipe 3x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_3x";
};
datablock fxDTSBrickData(brickPipe4xVerticalData)
{
	brickFile = "./bricks/vertical/4x.blb";
	uiName = "Pipe 4x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_4x";
};
datablock fxDTSBrickData(brickPipe5xVerticalData)
{
	brickFile = "./bricks/vertical/5x.blb";
	uiName = "Pipe 5x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_5x";
};
datablock fxDTSBrickData(brickPipe6xVerticalData)
{
	brickFile = "./bricks/vertical/6x.blb";
	uiName = "Pipe 6x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_6x";
};
datablock fxDTSBrickData(brickPipe7xVerticalData)
{
	brickFile = "./bricks/vertical/7x.blb";
	uiName = "Pipe 7x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_7x";
};
datablock fxDTSBrickData(brickPipe8xVerticalData)
{
	brickFile = "./bricks/vertical/8x.blb";
	uiName = "Pipe 8x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_8x";
};
datablock fxDTSBrickData(brickPipe9xVerticalData)
{
	brickFile = "./bricks/vertical/9x.blb";
	uiName = "Pipe 9x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_9x";
};
datablock fxDTSBrickData(brickPipe10xVerticalData)
{
	brickFile = "./bricks/vertical/10x.blb";
	uiName = "Pipe 10x Vertical";

	category = "Special";
	subCategory = "New Pipes";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_10x";
};

//joints
datablock fxDTSBrickData(brickPipeLJointHorizontalData)
{
	brickFile = "./bricks/horizontal/l.blb";
	uiName = "Pipe L Joint Horizontal";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_l";
};
datablock fxDTSBrickData(brickPipeLJointVerticalDownData)
{
	brickFile = "./bricks/vertical/l_down.blb";
	uiName = "Pipe L Joint Vertical Down";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_l_down";
};
datablock fxDTSBrickData(brickPipeLJointVerticalUpData)
{
	brickFile = "./bricks/vertical/l_up.blb";
	uiName = "Pipe L Joint Vertical Up";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_l_up";
};
datablock fxDTSBrickData(brickPipeTJointHorizontalData)
{
	brickFile = "./bricks/horizontal/t.blb";
	uiName = "Pipe T Joint Horizontal";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_t";
};
datablock fxDTSBrickData(brickPipeTJointVerticalDownData)
{
	brickFile = "./bricks/vertical/t_down.blb";
	uiName = "Pipe T Joint Vertical Down";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_t_down";
};
datablock fxDTSBrickData(brickPipeTJointVerticalUpData)
{
	brickFile = "./bricks/vertical/t_up.blb";
	uiName = "Pipe T Joint Vertical Up";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_t_up";
};
datablock fxDTSBrickData(brickPipeFJointVerticalData)
{
	brickFile = "./bricks/vertical/f.blb";
	uiName = "Pipe F Joint Vertical";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_f";
};
datablock fxDTSBrickData(brickPipeXJointHorizontalData)
{
	brickFile = "./bricks/horizontal/x.blb";
	uiName = "Pipe X Joint Horizontal";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/horizontal/icon_x";
};
datablock fxDTSBrickData(brickPipeXJointVerticalData)
{
	brickFile = "./bricks/vertical/x.blb";
	uiName = "Pipe X Joint Vertical";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_x";
};
datablock fxDTSBrickData(brickPipeYJointVerticalDownData)
{
	brickFile = "./bricks/vertical/y_down.blb";
	uiName = "Pipe Y Joint Vertical Down";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_y_down";
};
datablock fxDTSBrickData(brickPipeYJointVerticalUpData)
{
	brickFile = "./bricks/vertical/y_up.blb";
	uiName = "Pipe Y Joint Vertical Up";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/vertical/icon_y_up";
};
datablock fxDTSBrickData(brickPipeSprinklerJointLeftData)
{
	brickFile = "./bricks/special/sprinkler_left.blb";
	uiName = "Sprinkler Joint Left";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/special/icon_sprinkler_left";
};
datablock fxDTSBrickData(brickPipeSprinklerJointRightData)
{
	brickFile = "./bricks/special/sprinkler_right.blb";
	uiName = "Sprinkler Joint Right";

	category = "Special";
	subCategory = "New Pipe Joints";
	iconName = "Add-Ons/Brick_NewPipes/icons/special/icon_sprinkler_right";
};