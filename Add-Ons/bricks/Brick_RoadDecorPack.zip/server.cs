// Traffic Lights, bases, frames and supports
datablock fxDTSBrickData (brick1x1x1hTrafficLightBaseData)
{
	brickFile = "./1x1x1hTLBase.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x1h TL Base";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x1htlb";
	collisionShapeName = "./1x1x1hb.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x1hTrafficLightFrameData)
{
	brickFile = "./1x1x1hTLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x1h TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x1htlf";
	collisionShapeName = "./1x1x1hf.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x1hTrafficLightSupportData)
{
	brickFile = "./1x1x1hTLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x1h TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x1htls";
	orientationFix = 2;
	isWaterBrick = true;
};

datablock fxDTSBrickData (brick1x1x2TrafficLightBaseData)
{
	brickFile = "./1x1x2TLBase.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x2 TL Base";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x2tlb";
	collisionShapeName = "./1x1x2b.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x2TrafficLightFrameData)
{
	brickFile = "./1x1x2TLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x2 TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x2tlf";
	collisionShapeName = "./1x1x2f.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x2TrafficLightSupportData)
{
	brickFile = "./1x1x2TLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x2 TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x2tls";
	orientationFix = 2;
	isWaterBrick = true;
};

datablock fxDTSBrickData (brick1x1x4hTrafficLightBaseData)
{
	brickFile = "./1x1x4hTLBase.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x4h TL Base";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x4htlb";
	collisionShapeName = "./1x1x4hb.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x4hTrafficLightFrameData)
{
	brickFile = "./1x1x4hTLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x4h TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x4htlf";
	collisionShapeName = "./1x1x4hf.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x1x4hTrafficLightSupportData)
{
	brickFile = "./1x1x4hTLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x1x4h TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x1x4htls";
	orientationFix = 2;
	isWaterBrick = true;
};
	
datablock fxDTSBrickData (brick1x2x2TrafficLightBaseAData)
{
	brickFile = "./1x2x2TLBaseA.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x2x2 TL Base A";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x2x2tlba";
	collisionShapeName = "./1x2x2b.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x2x2TrafficLightBaseBData)
{
	brickFile = "./1x2x2TLBaseB.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x2x2 TL Base B";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x2x2tlbb";
	collisionShapeName = "./1x2x2b.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x2x2TrafficLightFrameData)
{
	brickFile = "./1x2x2TLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x2x2 TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x2x2tlf";
	collisionShapeName = "./1x2x2f.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x2x2TrafficLightSupportData)
{
	brickFile = "./1x2x2TLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x2x2 TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x2x2tls";
	orientationFix = 2;
	isWaterBrick = true;
};

datablock fxDTSBrickData (brick1x3x1hTrafficLightBaseData)
{
	brickFile = "./1x3x1hTLBase.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x3x1h TL Base";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x3x1htlb";
	collisionShapeName = "./1x3x1hb.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x3x1hTrafficLightFrameData)
{
	brickFile = "./1x3x1hTLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x3x1h TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x3x1htlf";
	collisionShapeName = "./1x3x1hf.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x3x1hTrafficLightSupportData)
{
	brickFile = "./1x3x1hTLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x3x1h TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x3x1htls";
	orientationFix = 2;
	isWaterBrick = true;
};

datablock fxDTSBrickData (brick1x4x1hTrafficLightBaseData)
{
	brickFile = "./1x4x1hTLBase.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x4x1h TL Base";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x4x1htlb";
	collisionShapeName = "./1x4x1hb.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x4x1hTrafficLightFrameData)
{
	brickFile = "./1x4x1hTLFrame.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x4x1h TL Frame";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x4x1htlf";
	collisionShapeName = "./1x4x1hf.dts";
	orientationFix = 2;
};

datablock fxDTSBrickData (brick1x4x1hTrafficLightSupportData)
{
	brickFile = "./1x4x1hTLSupport.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "1x4x1h TL Support";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/1x4x1htls";
	orientationFix = 2;
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickTrafficLightLEDData)
{
	brickFile = "./TL.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tl";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

datablock fxDTSBrickData (brickTrafficLightLEDCenteredData)
{
	brickFile = "./TLCentered.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED Centered";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tlc";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

datablock fxDTSBrickData (brickTrafficLightLEDLeftData)
{
	brickFile = "./TLLeft.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED Left";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tll";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

datablock fxDTSBrickData (brickTrafficLightLEDLeftCenteredData)
{
	brickFile = "./TLLeftCentered.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED Left Centered";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tllc";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

datablock fxDTSBrickData (brickTrafficLightLEDRightData)
{
	brickFile = "./TLRight.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED Right";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tlr";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

datablock fxDTSBrickData (brickTrafficLightLEDRightCenteredData)
{
	brickFile = "./TLRightCentered.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Light LED Right Centered";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tlrc";
	collisionShapeName = "./LED.dts";
	isWaterBrick = true;
	orientationFix = 2;
};

// Cones + poles
datablock fxDTSBrickData (brickTrafficConeAData)
{
	brickFile = "./ConeA.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Cone";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tc_a";
	collisionShapeName = "./coneA.dts";
};

datablock fxDTSBrickData (brickTrafficConeBData)
{
	brickFile = "./ConeB.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Cone 22.5 deg";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tc_b";
	collisionShapeName = "./coneB.dts";
};

datablock fxDTSBrickData (brickTrafficConeCData)
{
	brickFile = "./ConeC.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Cone 45 deg";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tc_c";
	collisionShapeName = "./coneC.dts";
};

datablock fxDTSBrickData (brickTrafficPoleAData)
{
	brickFile = "./PoleA.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Pole";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tp_a";
};

datablock fxDTSBrickData (brickTrafficPoleBData)
{
	brickFile = "./PoleB.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Pole 22.5 deg";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tp_b";
};

datablock fxDTSBrickData (brickTrafficPoleCData)
{
	brickFile = "./PoleC.blb";
	category = "Special";
	subCategory = "Road Decoration Pack";
	uiName = "Traffic Pole 45 deg";
	iconName = "Add-ons/Brick_RoadDecorPack/PNG/tp_c";
};