//server.cs -- for Brick_Doors, execute all things in here

// test door thing
// datablock fxDTSBrickData ( brickDoorTestData )
// {
	// brickFile = "./dev/testDoor.blb";
	// category = "special";
	// subCategory = "misc";
	// uiName = "Door Test";
	// iconName = "./placeholder";
	// orientationFix = 1;
// };

%error = ForceRequiredAddOn( "Support_Doors" );

if( %error == $Error::AddOn_NotFound )
{
	error("Brick Doors: Support_Doors is missing somehow, what did you do?");
}
else
{
	exec( "./bricks/window1x2x3_2pane.cs" );
	exec( "./bricks/window1x2x3_4pane.cs" );
	exec( "./bricks/window1x2x3_6pane.cs" );
	exec( "./bricks/window1x3x4_3pane.cs" );
	exec( "./bricks/window1x3x4_6pane.cs" );
	exec( "./bricks/window1x3x4_xpane.cs" );
	exec( "./bricks/window1x4x4_4pane.cs" );
	exec( "./bricks/window1x4x4_6pane.cs" );
	exec( "./bricks/window1x4x5_3pane.cs" );
	exec( "./bricks/window1x4x5_6pane.cs" );
	exec( "./bricks/window1x4x5_8pane.cs" );
	exec( "./bricks/window1x4x5_xpane.cs" );
	
}