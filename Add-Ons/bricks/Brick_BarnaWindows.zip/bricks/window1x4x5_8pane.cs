datablock fxDTSBrickData ( brickWindow1x4x5_8PaneOpenCWData )
{
	brickFile = "./Window1x4x5_8Paneopen.blb";
	uiName = "Window 1x4x5 8 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x5_8PaneCWData";
	openCW = "brickWindow1x4x5_8PaneOpenCWData";
	
	closedCCW = "brickWindow1x4x5_8PaneCWData";
	openCCW = "brickWindow1x4x5_8PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x4x5_8PaneCWData : brickWindow1x4x5_8PaneOpenCWData )
{
	brickFile = "./window1x4x5_8pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x4x5 8 pane";
	
	isOpen = 0;
};