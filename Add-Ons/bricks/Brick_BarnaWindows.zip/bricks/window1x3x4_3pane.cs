datablock fxDTSBrickData ( brickWindow1x3x4_3PaneOpenCWData )
{
	brickFile = "./Window1x3x4_3Paneopen.blb";
	uiName = "Window 1x3x4 3 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x3x4_3PaneCWData";
	openCW = "brickWindow1x3x4_3PaneOpenCWData";
	
	closedCCW = "brickWindow1x3x4_3PaneCWData";
	openCCW = "brickWindow1x3x4_3PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x3x4_3PaneCWData : brickWindow1x3x4_3PaneOpenCWData )
{
	brickFile = "./window1x3x4_3pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x3x4 3 pane";
	
	isOpen = 0;
};