datablock fxDTSBrickData ( brickWindow1x2x3_6PaneOpenCWData )
{
	brickFile = "./Window1x2x3_6Paneopen.blb";
	uiName = "Window 1x2x3 6 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x2x3_6PaneCWData";
	openCW = "brickWindow1x2x3_6PaneOpenCWData";
	
	closedCCW = "brickWindow1x2x3_6PaneCWData";
	openCCW = "brickWindow1x2x3_6PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x2x3_6PaneCWData : brickWindow1x2x3_6PaneOpenCWData )
{
	brickFile = "./window1x2x3_6pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x2x3 6 pane";
	
	isOpen = 0;
};