datablock fxDTSBrickData ( brickWindow1x4x5_3PaneOpenCWData )
{
	brickFile = "./Window1x4x5_3Paneopen.blb";
	uiName = "Window 1x4x5 3 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x5_3PaneCWData";
	openCW = "brickWindow1x4x5_3PaneOpenCWData";
	
	closedCCW = "brickWindow1x4x5_3PaneCWData";
	openCCW = "brickWindow1x4x5_3PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x4x5_3PaneCWData : brickWindow1x4x5_3PaneOpenCWData )
{
	brickFile = "./window1x4x5_3pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x4x5 3 pane";
	
	isOpen = 0;
};