datablock fxDTSBrickData ( brickWindow1x2x3_2PaneOpenCWData )
{
	brickFile = "./Window1x2x3_2PaneopenCW.blb";
	uiName = "Window 1x2x3 2 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x2x3_2PaneCWData";
	openCW = "brickWindow1x2x3_2PaneOpenCWData";
	
	closedCCW = "brickWindow1x2x3_2PaneCWData";
	openCCW = "brickWindow1x2x3_2PaneOpenCCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x2x3_2PaneOpenCCWData : brickWindow1x2x3_2PaneOpenCWData )
{
	brickFile = "./Window1x2x3_2PaneopenCCW.blb";

	isOpen = 1;
};

datablock fxDTSBrickData ( brickWindow1x2x3_2PaneCWData : brickWindow1x2x3_2PaneOpenCWData )
{
	brickFile = "./window1x2x3_2pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x2x3 2 pane";
	
	isOpen = 0;
};