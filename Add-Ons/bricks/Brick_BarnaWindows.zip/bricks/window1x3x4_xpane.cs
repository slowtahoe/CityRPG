datablock fxDTSBrickData ( brickWindow1x3x4_XPaneOpenCWData )
{
	brickFile = "./Window1x3x4_XPaneopen.blb";
	uiName = "Window 1x3x4 X pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x3x4_XPaneData";
	openCW = "brickWindow1x3x4_XPaneOpenCWData";
	
	closedCCW = "brickWindow1x3x4_XPaneData";
	openCCW = "brickWindow1x3x4_XPaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x3x4_XPaneData : brickWindow1x3x4_XPaneOpenCWData )
{
	brickFile = "./window1x3x4_Xpane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x3x4 X pane";
	
	isOpen = 0;
};