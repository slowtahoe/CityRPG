datablock fxDTSBrickData ( brickWindow1x4x4_6PaneOpenCWData )
{
	brickFile = "./Window1x4x4_6Paneopen.blb";
	uiName = "Window 1x4x4 6 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x4_6PaneCWData";
	openCW = "brickWindow1x4x4_6PaneOpenCWData";
	
	closedCCW = "brickWindow1x4x4_6PaneCWData";
	openCCW = "brickWindow1x4x4_6PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x4x4_6PaneCWData : brickWindow1x4x4_6PaneOpenCWData )
{
	brickFile = "./window1x4x4_6pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x4x4 6 pane";
	
	isOpen = 0;
};