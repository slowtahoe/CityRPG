datablock fxDTSBrickData ( brickWindow1x4x5_xPaneOpenCWData )
{
	brickFile = "./Window1x4x5_xPaneopen.blb";
	uiName = "Window 1x4x5 X pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x5_xPaneCWData";
	openCW = "brickWindow1x4x5_xPaneOpenCWData";
	
	closedCCW = "brickWindow1x4x5_xPaneCWData";
	openCCW = "brickWindow1x4x5_xPaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x4x5_xPaneCWData : brickWindow1x4x5_xPaneOpenCWData )
{
	brickFile = "./window1x4x5_xpane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x4x5 x pane";
	
	isOpen = 0;
};