datablock fxDTSBrickData ( brickWindow1x4x4_4PaneOpenCWData )
{
	brickFile = "./Window1x4x4_4Paneopen.blb";
	uiName = "Window 1x4x4 4 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x4x4_4PaneCWData";
	openCW = "brickWindow1x4x4_4PaneOpenCWData";
	
	closedCCW = "brickWindow1x4x4_4PaneCWData";
	openCCW = "brickWindow1x4x4_4PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x4x4_4PaneCWData : brickWindow1x4x4_4PaneOpenCWData )
{
	brickFile = "./window1x4x4_4pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x4x4 4 pane";
	
	isOpen = 0;
};