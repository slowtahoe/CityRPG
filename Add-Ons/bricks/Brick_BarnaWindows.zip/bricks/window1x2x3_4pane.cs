datablock fxDTSBrickData ( brickWindow1x2x3_4PaneOpenCWData )
{
	brickFile = "./Window1x2x3_4Paneopen.blb";
	uiName = "Window 1x2x3 4 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x2x3_4PaneCWData";
	openCW = "brickWindow1x2x3_4PaneOpenCWData";
	
	closedCCW = "brickWindow1x2x3_4PaneCWData";
	openCCW = "brickWindow1x2x3_4PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x2x3_4PaneCWData : brickWindow1x2x3_4PaneOpenCWData )
{
	brickFile = "./window1x2x3_4pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x2x3 4 pane";
	
	isOpen = 0;
};