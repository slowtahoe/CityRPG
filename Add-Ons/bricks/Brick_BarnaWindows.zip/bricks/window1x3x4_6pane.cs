datablock fxDTSBrickData ( brickWindow1x3x4_6PaneOpenCWData )
{
	brickFile = "./Window1x3x4_6Paneopen.blb";
	uiName = "Window 1x3x4 6 pane";
	
	isDoor = 1;
	isOpen = 1;
	
	closedCW = "brickWindow1x3x4_6PaneCWData";
	openCW = "brickWindow1x3x4_6PaneOpenCWData";
	
	closedCCW = "brickWindow1x3x4_6PaneCWData";
	openCCW = "brickWindow1x3x4_6PaneOpenCWData";
	
	orientationFix = 3;
};

datablock fxDTSBrickData ( brickWindow1x3x4_6PaneCWData : brickWindow1x3x4_6PaneOpenCWData )
{
	brickFile = "./window1x3x4_6pane.blb";
	category = "Special";
	subCategory = "Windows";
	
	iconName = "Add-Ons/Brick_BarnaWindows/icons/Window 1x3x4 6 pane";
	
	isOpen = 0;
};