//it was hell doing all this copy and paste work, making sure the correct stuff is changed to the correct thing on the correct block
//the end result should be great though
//ive even separated the code into cs files named after their pack - amazing!!!1!!!11!!!1!

//prefs
if($Pref::Server::ModifiedModter::CategoryChange $= "")
	$Pref::Server::ModifiedModter::CategoryChange = true;

if($Pref::Server::ModifiedModter::FixInvetedModTer $= "")
	$Pref::Server::ModifiedModter::FixInvetedModTer = true;

if($Pref::Server::ModifiedModter::Fix4xModTer $= "")
	$Pref::Server::ModifiedModter::Fix4xModTer = true;
if($Pref::Server::ModifiedModter::Legacy4xModTer $= "")
	$Pref::Server::ModifiedModter::Legacy4xModTer = true;

if($Pref::Server::ModifiedModter::SibaMiscReorganise $= "")
	$Pref::Server::ModifiedModter::SibaMiscReorganise = true;

//rtb prefs
if($RTB::Hooks::ServerControl)
{
	RTB_registerPref("Change category of modter bricks to 'ModTer'",		"Modified Modter - All",				"$Pref::Server::ModifiedModter::CategoryChange",		"bool",	"Brick_ModifiedModter",	true,	true,	false,	false);
	
	RTB_registerPref("Apply Demian's inverted corner modter normals fix",	"Modified Modter - Inverted ModTer",	"$Pref::Server::ModifiedModter::FixInvetedModTer",		"bool",	"Brick_ModifiedModter",	true,	true,	false,	false);
	
	RTB_registerPref("Apply piber20's 4x modter print size change",			"Modified Modter - 4x ModTer",			"$Pref::Server::ModifiedModter::Fix4xModTer",			"bool",	"Brick_ModifiedModter",	true,	true,	false,	false);
	RTB_registerPref("Load legacy 4x modter (4x without any fixes)",		"Modified Modter - 4x ModTer",			"$Pref::Server::ModifiedModter::Legacy4xModTer",		"bool",	"Brick_ModifiedModter",	true,	true,	false,	false);
	
	RTB_registerPref("Reorganise misc subcategory",							"Modified Modter - Siba's ModTer",		"$Pref::Server::ModifiedModter::SibaMiscReorganise",	"bool",	"Brick_ModifiedModter",	true,	true,	false,	false);
}

//code files
exec("./modter_basic.cs");
exec("./modter_inverted.cs");
exec("./modter_4x.cs");
exec("./modter_siba.cs");