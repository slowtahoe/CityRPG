/////////////////////////////////////////////////////////////////////4x/////////////////////////////////////////////////////////////////////

if(isObject(brick4Cube1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4Cube1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4c.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4Cube1Data.category = "ModTer";
		brick4Cube1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4Cube1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4c.blb";
			category = "Baseplates";
			subCategory = "ModTer Legacy 4x";
			uiName = " 4x Cube Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4c";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4Cube1LegacyData.category = "ModTer";
			brick4Cube1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4Wedge1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4Wedge1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cW.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4Wedge1Data.category = "ModTer";
		brick4Wedge1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4Wedge1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cW.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x Wedge Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cW";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cWCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4Wedge1LegacyData.category = "ModTer";
			brick4Wedge1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4Ramp1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4Ramp1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cR.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4Ramp1Data.category = "ModTer";
		brick4Ramp1Data.subCategory = "4x";
	}

	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4Ramp1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cR.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x Ramp Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cR";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4Ramp1LegacyData.category = "ModTer";
			brick4Ramp1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4Ramp1invData))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4Ramp1invData.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cRinv.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4Ramp1invData.category = "ModTer";
		brick4Ramp1invData.subCategory = "4x Inv";
	}

	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4Ramp1invLegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cRinv.blb";
			category = "ModTer";
			subCategory = "Legacy 4x Inv";
			uiName = "4x Ramp Inv. Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cRinv";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cRinvCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4Ramp1invLegacyData.category = "ModTer";
			brick4Ramp1invLegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerA1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerA1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCA.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerA1Data.category = "ModTer";
		brick4CornerA1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerA1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCA.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x CornerA Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCA";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCACol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerA1LegacyData.category = "ModTer";
			brick4CornerA1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerA1invData))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerA1invData.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCAinv.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerA1invData.category = "ModTer";
		brick4CornerA1invData.subCategory = "4x Inv";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerA1invLegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCAinv.blb";
			category = "ModTer";
			subCategory = "Legacy 4x Inv";
			uiName = "4x CornerA Inv. Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCAinv";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCAinvCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerA1invLegacyData.category = "ModTer";
			brick4CornerA1invLegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerB1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerB1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCB.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerB1Data.category = "ModTer";
		brick4CornerB1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerB1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCB.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x CornerB Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCB";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerB1LegacyData.category = "ModTer";
			brick4CornerB1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerB1invData))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerB1invData.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCBinv.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerB1invData.category = "ModTer";
		brick4CornerB1invData.subCategory = "4x Inv";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerB1invLegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCBinv.blb";
			category = "ModTer";
			subCategory = "Legacy 4x Inv";
			uiName = "4x CornerB Inv. Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCBinv";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCBinvCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerB1invLegacyData.category = "ModTer";
			brick4CornerB1invLegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerC1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerC1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCC.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerC1Data.category = "ModTer";
		brick4CornerC1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerC1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCC.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x CornerC Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCC";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerC1LegacyData.category = "ModTer";
			brick4CornerC1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerC1invData))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerC1invData.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCCinv.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerC1invData.category = "ModTer";
		brick4CornerC1invData.subCategory = "4x Inv";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerC1invLegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCCinv.blb";
			category = "ModTer";
			subCategory = "Legacy 4x Inv";
			uiName = "4x CornerC Inv. Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCCinv";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCCinvCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerC1invLegacyData.category = "ModTer";
			brick4CornerC1invLegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerD1Data))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerD1Data.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCD.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerD1Data.category = "ModTer";
		brick4CornerD1Data.subCategory = "4x";
	}
	
	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerD1LegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCD.blb";
			category = "ModTer";
			subCategory = "Legacy 4x";
			uiName = "4x CornerD Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCD";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerD1LegacyData.category = "ModTer";
			brick4CornerD1LegacyData.subCategory = "Legacy 4x";
		}
	}
}

if(isObject(brick4CornerD1invData))
{
	if($Pref::Server::ModifiedModter::Fix4xModTer)
		brick4CornerD1invData.brickFile = "Add-Ons/Brick_Modified_ModTer/new4x/4cCDinv.blb";
	
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick4CornerD1invData.category = "ModTer";
		brick4CornerD1invData.subCategory = "4x Inv";
	}

	if($Pref::Server::ModifiedModter::Legacy4xModTer)
	{
		datablock fxDTSBrickData(brick4CornerD1invLegacyData)
		{
			brickFile = "Add-Ons/Brick_ModTer_4xPack/Bricks/4cCDinv.blb";
			category = "ModTer";
			subCategory = "Legacy 4x Inv";
			uiName = "4x CornerD Inv. Legacy";
			iconName = "Add-ons/Brick_ModTer_4xPack/BrickIcons/4cCDinv";
			collisionShapeName = "Add-Ons/Brick_ModTer_4xPack/Shapes/4cCDinvCol.dts";
			hasPrint = 1;
			printAspectRatio = "ModTer";
		};
		
		if($Pref::Server::ModifiedModter::CategoryChange)
		{
			brick4CornerD1invLegacyData.category = "ModTer";
			brick4CornerD1invLegacyData.subCategory = "Legacy 4x";
		}
	}
}