						      /////  /////  /////  /////  /////
						      //       //   //     //     // //
						      /////    //   /////  /////  /////
						         //    //   //     //     //
						      /////    //   /////  /////  //

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

//everything done in this file is only category changes, so we can safely return if the pref is disabled
if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick32Ramp5InvData))
	{
		brick32Ramp5InvData.category = "ModTer";
		brick32Ramp5InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerA5InvData))
	{
		brick32CornerA5InvData.category = "ModTer";
		brick32CornerA5InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerB5InvData))
	{
		brick32CornerB5InvData.category = "ModTer";
		brick32CornerB5InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerC5InvData))
	{
		brick32CornerC5InvData.category = "ModTer";
		brick32CornerC5InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerD5InvData))
	{
		brick32CornerD5InvData.category = "ModTer";
		brick32CornerD5InvData.subCategory = "32x Inv";
	}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

	if(isObject(brick16Ramp5InvData))
	{
		brick16Ramp5InvData.category = "ModTer";
		brick16Ramp5InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerA5InvData))
	{
		brick16CornerA5InvData.category = "ModTer";
		brick16CornerA5InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerB5InvData))
	{
		brick16CornerB5InvData.category = "ModTer";
		brick16CornerB5InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerC5InvData))
	{
		brick16CornerC5InvData.category = "ModTer";
		brick16CornerC5InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerD5InvData))
	{
		brick16CornerD5InvData.category = "ModTer";
		brick16CornerD5InvData.subCategory = "16x Inv";
	}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

	if(isObject(brick8Ramp5InvData))
	{
		brick8Ramp5InvData.category = "ModTer";
		brick8Ramp5InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerA5InvData))
	{
		brick8CornerA5InvData.category = "ModTer";
		brick8CornerA5InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerB5InvData))
	{
		brick8CornerB5InvData.category = "ModTer";
		brick8CornerB5InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerC5InvData))
	{
		brick8CornerC5InvData.category = "ModTer";
		brick8CornerC5InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerD5InvData))
	{
		brick8CornerD5InvData.category = "ModTer";
		brick8CornerD5InvData.subCategory = "8x Inv";
	}

							/////  // //  //     //
							//     // //  //     //
							/////  // //  //     //
							//     // //  //     //
							//     /////  /////  /////

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

	if(isObject(brick64Ramp1InvData))
	{
		brick64Ramp1InvData.category = "ModTer";
		brick64Ramp1InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerA1InvData))
	{
		brick64CornerA1InvData.category = "ModTer";
		brick64CornerA1InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerB1InvData))
	{
		brick64CornerB1InvData.category = "ModTer";
		brick64CornerB1InvData.subCategory = "64x Inv";
	}
}

if(isObject(brick64CornerC1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick64CornerC1InvData.category = "ModTer";
		brick64CornerC1InvData.subCategory = "64x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick64CornerC1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/64cCCinv.blb";
}

if(isObject(brick64CornerD1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick64CornerD1InvData.category = "ModTer";
		brick64CornerD1InvData.subCategory = "64x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick64CornerD1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/64cCDinv.blb";
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick32Ramp1InvData))
	{
		brick32Ramp1InvData.category = "ModTer";
		brick32Ramp1InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerA1InvData))
	{
		brick32CornerA1InvData.category = "ModTer";
		brick32CornerA1InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerB1InvData))
	{
		brick32CornerB1InvData.category = "ModTer";
		brick32CornerB1InvData.subCategory = "32x Inv";
	}
}

if(isObject(brick32CornerC1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick32CornerC1InvData.category = "ModTer";
		brick32CornerC1InvData.subCategory = "32x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick32CornerC1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/32cCCinv.blb";
}

if(isObject(brick32CornerD1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick32CornerD1InvData.category = "ModTer";
		brick32CornerD1InvData.subCategory = "32x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick32CornerD1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/32cCDinv.blb";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick16Ramp1InvData))
	{
		brick16Ramp1InvData.category = "ModTer";
		brick16Ramp1InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerA1InvData))
	{
		brick16CornerA1InvData.category = "ModTer";
		brick16CornerA1InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerB1InvData))
	{
		brick16CornerB1InvData.category = "ModTer";
		brick16CornerB1InvData.subCategory = "16x Inv";
	}
}

if(isObject(brick16CornerC1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick16CornerC1InvData.category = "ModTer";
		brick16CornerC1InvData.subCategory = "16x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick16CornerC1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/16cCCinv.blb";
}

if(isObject(brick16CornerD1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick16CornerD1InvData.category = "ModTer";
		brick16CornerD1InvData.subCategory = "16x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick16CornerD1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/16cCDinv.blb";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick8Ramp1InvData))
	{
		brick8Ramp1InvData.category = "ModTer";
		brick8Ramp1InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerA1InvData))
	{
		brick8CornerA1InvData.category = "ModTer";
		brick8CornerA1InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerB1InvData))
	{
		brick8CornerB1InvData.category = "ModTer";
		brick8CornerB1InvData.subCategory = "8x Inv";
	}
}

if(isObject(brick8CornerC1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick8CornerC1InvData.category = "ModTer";
		brick8CornerC1InvData.subCategory = "8x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick8CornerC1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/8cCCinv.blb";
}

if(isObject(brick8CornerD1InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick8CornerD1InvData.category = "ModTer";
		brick8CornerD1InvData.subCategory = "8x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick8CornerD1InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/8cCDinv.blb";
}

							  ////      //  // //
							     //    //   // //
							  ////    //    /////
							     //  //        //
							  ////  //         //

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick64Ramp2InvData))
	{
		brick64Ramp2InvData.category = "ModTer";
		brick64Ramp2InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerA2InvData))
	{
		brick64CornerA2InvData.category = "ModTer";
		brick64CornerA2InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerB2InvData))
	{
		brick64CornerB2InvData.category = "ModTer";
		brick64CornerB2InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerC2InvData))
	{
		brick64CornerC2InvData.category = "ModTer";
		brick64CornerC2InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerD2InvData))
	{
		brick64CornerD2InvData.category = "ModTer";
		brick64CornerD2InvData.subCategory = "64x Inv";
	}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

	if(isObject(brick32Ramp2InvData))
	{
		brick32Ramp2InvData.category = "ModTer";
		brick32Ramp2InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerA2InvData))
	{
		brick32CornerA2InvData.category = "ModTer";
		brick32CornerA2InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerB2InvData))
	{
		brick32CornerB2InvData.category = "ModTer";
		brick32CornerB2InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerC2InvData))
	{
		brick32CornerC2InvData.category = "ModTer";
		brick32CornerC2InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerD2InvData))
	{
		brick32CornerD2InvData.category = "ModTer";
		brick32CornerD2InvData.subCategory = "32x Inv";
	}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

	if(isObject(brick16Ramp2InvData))
	{
		brick16Ramp2InvData.category = "ModTer";
		brick16Ramp2InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerA2InvData))
	{
		brick16CornerA2InvData.category = "ModTer";
		brick16CornerA2InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerB2InvData))
	{
		brick16CornerB2InvData.category = "ModTer";
		brick16CornerB2InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerC2InvData))
	{
		brick16CornerC2InvData.category = "ModTer";
		brick16CornerC2InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerD2InvData))
	{
		brick16CornerD2InvData.category = "ModTer";
		brick16CornerD2InvData.subCategory = "16x Inv";
	}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

	if(isObject(brick8Ramp2InvData))
	{
		brick8Ramp2InvData.category = "ModTer";
		brick8Ramp2InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerA2InvData))
	{
		brick8CornerA2InvData.category = "ModTer";
		brick8CornerA2InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerB2InvData))
	{
		brick8CornerB2InvData.category = "ModTer";
		brick8CornerB2InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerC2InvData))
	{
		brick8CornerC2InvData.category = "ModTer";
		brick8CornerC2InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerD2InvData))
	{
		brick8CornerD2InvData.category = "ModTer";
		brick8CornerD2InvData.subCategory = "8x Inv";
	}

							      //     //  /////
							      //    //   // //
							      //   //      //
							      //  //      //
							      // //      /////

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

	if(isObject(brick64Ramp3InvData))
	{
		brick64Ramp3InvData.category = "ModTer";
		brick64Ramp3InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerA3InvData))
	{
		brick64CornerA3InvData.category = "ModTer";
		brick64CornerA3InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerB3InvData))
	{
		brick64CornerB3InvData.category = "ModTer";
		brick64CornerB3InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerC3InvData))
	{
		brick64CornerC3InvData.category = "ModTer";
		brick64CornerC3InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerD3InvData))
	{
		brick64CornerD3InvData.category = "ModTer";
		brick64CornerD3InvData.subCategory = "64x Inv";
	}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

	if(isObject(brick32Ramp3InvData))
	{
		brick32Ramp3InvData.category = "ModTer";
		brick32Ramp3InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerA3InvData))
	{
		brick32CornerA3InvData.category = "ModTer";
		brick32CornerA3InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerB3InvData))
	{
		brick32CornerB3InvData.category = "ModTer";
		brick32CornerB3InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerC3InvData))
	{
		brick32CornerC3InvData.category = "ModTer";
		brick32CornerC3InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerD3InvData))
	{
		brick32CornerD3InvData.category = "ModTer";
		brick32CornerD3InvData.subCategory = "32x Inv";
	}
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Ramp3InvData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
	{
		brick16Ramp3InvData.category = "ModTer";
		brick16Ramp3InvData.subCategory = "16x Inv";
	}
	
	if($Pref::Server::ModifiedModter::FixInvetedModTer)
		brick16Ramp3InvData.brickFile = "Add-Ons/Brick_Modified_ModTer/demianfix/16cRinv1-2.blb";
}

if($Pref::Server::ModifiedModter::CategoryChange)
{
	if(isObject(brick16CornerA3InvData))
	{
		brick16CornerA3InvData.category = "ModTer";
		brick16CornerA3InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerB3InvData))
	{
		brick16CornerB3InvData.category = "ModTer";
		brick16CornerB3InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerC3InvData))
	{
		brick16CornerC3InvData.category = "ModTer";
		brick16CornerC3InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerD3InvData))
	{
		brick16CornerD3InvData.category = "ModTer";
		brick16CornerD3InvData.subCategory = "16x Inv";
	}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

	if(isObject(brick8Ramp3InvData))
	{
		brick8Ramp3InvData.category = "ModTer";
		brick8Ramp3InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerA3InvData))
	{
		brick8CornerA3InvData.category = "ModTer";
		brick8CornerA3InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerB3InvData))
	{
		brick8CornerB3InvData.category = "ModTer";
		brick8CornerB3InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerC3InvData))
	{
		brick8CornerC3InvData.category = "ModTer";
		brick8CornerC3InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerD3InvData))
	{
		brick8CornerD3InvData.category = "ModTer";
		brick8CornerD3InvData.subCategory = "8x Inv";
	}

							      //     //  // //
							      //    //   // //
							      //   //    /////
							      //  //        //
							      // //         //

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

	if(isObject(brick64Ramp4InvData))
	{
		brick64Ramp4InvData.category = "ModTer";
		brick64Ramp4InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerA4InvData))
	{
		brick64CornerA4InvData.category = "ModTer";
		brick64CornerA4InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerB4InvData))
	{
		brick64CornerB4InvData.category = "ModTer";
		brick64CornerB4InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerC4InvData))
	{
		brick64CornerC4InvData.category = "ModTer";
		brick64CornerC4InvData.subCategory = "64x Inv";
	}

	if(isObject(brick64CornerD4InvData))
	{
		brick64CornerD4InvData.category = "ModTer";
		brick64CornerD4InvData.subCategory = "64x Inv";
	}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

	if(isObject(brick32Ramp4InvData))
	{
		brick32Ramp4InvData.category = "ModTer";
		brick32Ramp4InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerA4InvData))
	{
		brick32CornerA4InvData.category = "ModTer";
		brick32CornerA4InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerB4InvData))
	{
		brick32CornerB4InvData.category = "ModTer";
		brick32CornerB4InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerC4InvData))
	{
		brick32CornerC4InvData.category = "ModTer";
		brick32CornerC4InvData.subCategory = "32x Inv";
	}

	if(isObject(brick32CornerD4InvData))
	{
		brick32CornerD4InvData.category = "ModTer";
		brick32CornerD4InvData.subCategory = "32x Inv";
	}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

	if(isObject(brick16Ramp4InvData))
	{
		brick16Ramp4InvData.category = "ModTer";
		brick16Ramp4InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerA4InvData))
	{
		brick16CornerA4InvData.category = "ModTer";
		brick16CornerA4InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerB4InvData))
	{
		brick16CornerB4InvData.category = "ModTer";
		brick16CornerB4InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerC4InvData))
	{
		brick16CornerC4InvData.category = "ModTer";
		brick16CornerC4InvData.subCategory = "16x Inv";
	}

	if(isObject(brick16CornerD4InvData))
	{
		brick16CornerD4InvData.category = "ModTer";
		brick16CornerD4InvData.subCategory = "16x Inv";
	}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

	if(isObject(brick8Ramp4InvData))
	{
		brick8Ramp4InvData.category = "ModTer";
		brick8Ramp4InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerA4InvData))
	{
		brick8CornerA4InvData.category = "ModTer";
		brick8CornerA4InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerB4InvData))
	{
		brick8CornerB4InvData.category = "ModTer";
		brick8CornerB4InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerC4InvData))
	{
		brick8CornerC4InvData.category = "ModTer";
		brick8CornerC4InvData.subCategory = "8x Inv";
	}

	if(isObject(brick8CornerD4InvData))
	{
		brick8CornerD4InvData.category = "ModTer";
		brick8CornerD4InvData.subCategory = "8x Inv";
	}
}