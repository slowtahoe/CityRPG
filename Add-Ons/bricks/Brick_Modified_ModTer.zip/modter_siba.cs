if($Pref::Server::ModifiedModter::CategoryChange)
{
	//2x2x5
	if(isObject(brickModter2x2x5CubeData))
	{
		brickModter2x2x5CubeData.category = "Modter";
		brickModter2x2x5CubeData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5WedgeData))
	{
		brickModter2x2x5WedgeData.category = "Modter";
		brickModter2x2x5WedgeData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5RampData))
	{
		brickModter2x2x5RampData.category = "Modter";
		brickModter2x2x5RampData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5SlantUpData))
	{
		brickModter2x2x5SlantUpData.category = "Modter";
		brickModter2x2x5SlantUpData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5SlantUpInvData))
	{
		brickModter2x2x5SlantUpInvData.category = "Modter";
		brickModter2x2x5SlantUpInvData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5CornerUpData))
	{
		brickModter2x2x5CornerUpData.category = "Modter";
		brickModter2x2x5CornerUpData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5CornerUpInvData))
	{
		brickModter2x2x5CornerUpInvData.category = "Modter";
		brickModter2x2x5CornerUpInvData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x5RampInvData))
	{
		brickModter2x2x5RampInvData.category = "Modter";
		brickModter2x2x5RampInvData.subCategory = "2x Inv";
	}

	if(isObject(brickModter2x2x5SlantDownData))
	{
		brickModter2x2x5SlantDownData.category = "Modter";
		brickModter2x2x5SlantDownData.subCategory = "2x Inv";
	}

	if(isObject(brickModter2x2x5SlantDownInvData))
	{
		brickModter2x2x5SlantDownInvData.category = "Modter";
		brickModter2x2x5SlantDownInvData.subCategory = "2x Inv";
	}

	if(isObject(brickModter2x2x5CornerDownData))
	{
		brickModter2x2x5CornerDownData.category = "Modter";
		brickModter2x2x5CornerDownData.subCategory = "2x Inv";
	}

	if(isObject(brickModter2x2x5CornerDownInvData))
	{
		brickModter2x2x5CornerDownInvData.category = "Modter";
		brickModter2x2x5CornerDownInvData.subCategory = "2x Inv";
	}

	//2xFiller
	if(isObject(brickModter2x4x10CubeData))
	{
		brickModter2x4x10CubeData.category = "ModTer";
		brickModter2x4x10CubeData.subCategory = "2x";
	}

	if(isObject(brickModter2x8x5CubeData))
	{
		brickModter2x8x5CubeData.category = "ModTer";
		brickModter2x8x5CubeData.subCategory = "2x";
	}

	if(isObject(brickModter2x4x5CubeData))
	{
		brickModter2x4x5CubeData.category = "ModTer";
		brickModter2x4x5CubeData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x20CubeData))
	{
		brickModter2x2x20CubeData.category = "ModTer";
		brickModter2x2x20CubeData.subCategory = "2x";
	}

	if(isObject(brickModter2x2x10CubeData))
	{
		brickModter2x2x10CubeData.category = "ModTer";
		brickModter2x2x10CubeData.subCategory = "2x";
	}

	//4x4x5
	if(isObject(brickModter4x4x5CubeData))
	{
		brickModter4x4x5CubeData.category = "ModTer";
		brickModter4x4x5CubeData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5WedgeData))
	{
		brickModter4x4x5WedgeData.category = "ModTer";
		brickModter4x4x5WedgeData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5RampData))
	{
		brickModter4x4x5RampData.category = "ModTer";
		brickModter4x4x5RampData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5SlantUpData))
	{
		brickModter4x4x5SlantUpData.category = "ModTer";
		brickModter4x4x5SlantUpData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5SlantUpInvData))
	{
		brickModter4x4x5SlantUpInvData.category = "ModTer";
		brickModter4x4x5SlantUpInvData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5CornerUpData))
	{
		brickModter4x4x5CornerUpData.category = "ModTer";
		brickModter4x4x5CornerUpData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5CornerUpInvData))
	{
		brickModter4x4x5CornerUpInvData.category = "ModTer";
		brickModter4x4x5CornerUpInvData.subCategory = "4x";
	}

	if(isObject(brickModter4x4x5RampInvData))
	{
		brickModter4x4x5RampInvData.category = "ModTer";
		brickModter4x4x5RampInvData.subCategory = "4x Inv";
	}

	if(isObject(brickModter4x4x5SlantDownData))
	{
		brickModter4x4x5SlantDownData.category = "ModTer";
		brickModter4x4x5SlantDownData.subCategory = "4x Inv";
	}

	if(isObject(brickModter4x4x5SlantDownInvData))
	{
		brickModter4x4x5SlantDownInvData.category = "ModTer";
		brickModter4x4x5SlantDownInvData.subCategory = "4x Inv";
	}

	if(isObject(brickModter4x4x5CornerDownData))
	{
		brickModter4x4x5CornerDownData.category = "ModTer";
		brickModter4x4x5CornerDownData.subCategory = "4x Inv";
	}

	if(isObject(brickModter4x4x5CornerDownInvData))
	{
		brickModter4x4x5CornerDownInvData.category = "ModTer";
		brickModter4x4x5CornerDownInvData.subCategory = "4x Inv";
	}

	//4xFiller
	if(isObject(brickModter4x8x5Cubedata))
	{
		brickModter4x8x5Cubedata.category = "ModTer";
		brickModter4x8x5Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x12x5Cubedata))
	{
		brickModter4x12x5Cubedata.category = "ModTer";
		brickModter4x12x5Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x16x5Cubedata))
	{
		brickModter4x16x5Cubedata.category = "ModTer";
		brickModter4x16x5Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x8x5Rampdata))
	{
		brickModter4x8x5Rampdata.category = "ModTer";
		brickModter4x8x5Rampdata.subCategory = "4x";
	}

	if(isObject(brickModter4x12x5Rampdata))
	{
		brickModter4x12x5Rampdata.category = "ModTer";
		brickModter4x12x5Rampdata.subCategory = "4x";
	}

	if(isObject(brickModter4x16x5Rampdata))
	{
		brickModter4x16x5Rampdata.category = "ModTer";
		brickModter4x16x5Rampdata.subCategory = "4x";
	}

	if(isObject(brickModter4x8x20Cubedata))
	{
		brickModter4x8x20Cubedata.category = "ModTer";
		brickModter4x8x20Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x16x10Cubedata))
	{
		brickModter4x16x10Cubedata.category = "ModTer";
		brickModter4x16x10Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x8x10Cubedata))
	{
		brickModter4x8x10Cubedata.category = "ModTer";
		brickModter4x8x10Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x4x40Cubedata))
	{
		brickModter4x4x40Cubedata.category = "ModTer";
		brickModter4x4x40Cubedata.subCategory = "4x";
	}

	if(isObject(brickModter4x4x20Cubedata))
	{
		brickModter4x4x20Cubedata.category = "ModTer";
		brickModter4x4x20Cubedata.subCategory = "4x";
	}

	//fence
	if(isObject(brickModter2x2FenceEndData))
	{
		brickModter2x2FenceEndData.category = "ModTer";
		brickModter2x2FenceEndData.subCategory = "Fence";
	}

	if(isObject(brickModter2x2FenceData))
	{
		brickModter2x2FenceData.category = "ModTer";
		brickModter2x2FenceData.subCategory = "Fence";
	}

	if(isObject(brickModter2x4FenceData))
	{
		brickModter2x4FenceData.category = "ModTer";
		brickModter2x4FenceData.subCategory = "Fence";
	}

	if(isObject(brickModter2x6FenceData))
	{
		brickModter2x6FenceData.category = "ModTer";
		brickModter2x6FenceData.subCategory = "Fence";
	}

	if(isObject(brickModter2x8FenceData))
	{
		brickModter2x8FenceData.category = "ModTer";
		brickModter2x8FenceData.subCategory = "Fence";
	}

	if(isObject(brickModter2x16FenceData))
	{
		brickModter2x16FenceData.category = "ModTer";
		brickModter2x16FenceData.subCategory = "Fence";
	}

	if(isObject(brickModter2x2FenceCData))
	{
		brickModter2x2FenceCData.category = "ModTer";
		brickModter2x2FenceCData.subCategory = "Fence";
	}

	if(isObject(brickModter2x2FenceTData))
	{
		brickModter2x2FenceTData.category = "ModTer";
		brickModter2x2FenceTData.subCategory = "Fence";
	}

	//adapter
	if(isObject(brickModter2xto4xAdapterLData))
	{
		brickModter2xto4xAdapterLData.category = "ModTer";
		brickModter2xto4xAdapterLData.subCategory = "Adapter";
	}

	if(isObject(brickModter2xto4xAdapterRData))
	{
		brickModter2xto4xAdapterRData.category = "ModTer";
		brickModter2xto4xAdapterRData.subCategory = "Adapter";
	}

	if(isObject(brickModter4xto2xAdapterLData))
	{
		brickModter4xto2xAdapterLData.category = "ModTer";
		brickModter4xto2xAdapterLData.subCategory = "Adapter";
	}

	if(isObject(brickModter4xto2xAdapterRData))
	{
		brickModter4xto2xAdapterRData.category = "ModTer";
		brickModter4xto2xAdapterRData.subCategory = "Adapter";
	}

	if(isObject(brickModter4xto8xAdapterLData))
	{
		brickModter4xto8xAdapterLData.category = "ModTer";
		brickModter4xto8xAdapterLData.subCategory = "Adapter";
	}

	if(isObject(brickModter4xto8xAdapterRData))
	{
		brickModter4xto8xAdapterRData.category = "ModTer";
		brickModter4xto8xAdapterRData.subCategory = "Adapter";
	}

	if(isObject(brickModter8xto4xAdapterLData))
	{
		brickModter8xto4xAdapterLData.category = "ModTer";
		brickModter8xto4xAdapterLData.subCategory = "Adapter";
	}

	if(isObject(brickModter8xto4xAdapterRData))
	{
		brickModter8xto4xAdapterRData.category = "ModTer";
		brickModter8xto4xAdapterRData.subCategory = "Adapter";
	}
}

//misc
if(isObject(brickModter16x16x5CubeData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter16x16x5CubeData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter16x16x5CubeData.subCategory = "16x";
	else
		brickModter16x16x5CubeData.subCategory = "Misc";
}

if(isObject(brickModter32x32x5CubeData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter32x32x5CubeData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter32x32x5CubeData.subCategory = "32x";
	else
		brickModter32x32x5CubeData.subCategory = "Misc";
}

if(isObject(brickModter4x12x10BenchData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter4x12x10BenchData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter4x12x10BenchData.subCategory = "Street Props";
	else
		brickModter4x12x10BenchData.subCategory = "Misc";
}

if(isObject(brickModter32x2x25RailData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter32x2x25RailData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter32x2x25RailData.subCategory = "2x";
	else
		brickModter32x2x25RailData.subCategory = "Misc";
}

if(isObject(brickModter16x2x15RailData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter16x2x15RailData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter16x2x15RailData.subCategory = "2x";
	else
		brickModter16x2x15RailData.subCategory = "Misc";
}

if(isObject(brickModter8x2x10RailData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter8x2x10RailData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter8x2x10RailData.subCategory = "2x";
	else
		brickModter8x2x10RailData.subCategory = "Misc";
}

if(isObject(brickModter2x4x1StreetbulbData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter2x4x1StreetbulbData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter2x4x1StreetbulbData.subCategory = "Street Props";
	else
		brickModter2x4x1StreetbulbData.subCategory = "Misc";
}

if(isObject(brickModter2x26x46StreetlightData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter2x26x46StreetlightData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter2x26x46StreetlightData.subCategory = "Street Props";
	else
		brickModter2x26x46StreetlightData.subCategory = "Misc";
}

if(isObject(brickModter2x26x46StreetlightDoubleData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter2x26x46StreetlightDoubleData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter2x26x46StreetlightDoubleData.subCategory = "Street Props";
	else
		brickModter2x26x46StreetlightDoubleData.subCategory = "Misc";
}

if(isObject(brickModter8x8x5RailroadData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter8x8x5RailroadData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter8x8x5RailroadData.subCategory = "Railroad";
	else
		brickModter8x8x5RailroadData.subCategory = "Misc";
}

if(isObject(brickModter8x8x5RailroadCrossingData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter8x8x5RailroadCrossingData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter8x8x5RailroadCrossingData.subCategory = "Railroad";
	else
		brickModter8x8x5RailroadCrossingData.subCategory = "Misc";
}

if(isObject(brickModter8x8x5RailroadRampData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter8x8x5RailroadRampData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter8x8x5RailroadRampData.subCategory = "Railroad";
	else
		brickModter8x8x5RailroadRampData.subCategory = "Misc";
}

if(isObject(brickModter4xCubeWallData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter4xCubeWallData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter4xCubeWallData.subCategory = "4x";
	else
		brickModter4xCubeWallData.subCategory = "Misc";
}

if(isObject(brickModter8xCubeWallData))
{
	if($Pref::Server::ModifiedModter::CategoryChange)
		brickModter8xCubeWallData.category = "ModTer";
	
	if($Pref::Server::ModifiedModter::SibaMiscReorganise)
		brickModter8xCubeWallData.subCategory = "8x";
	else
		brickModter8xCubeWallData.subCategory = "Misc";
}
