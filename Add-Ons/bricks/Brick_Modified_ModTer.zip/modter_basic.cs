//everything done in this file is only category changes, so we can safely return if the pref is disabled
if(!$Pref::Server::ModifiedModter::CategoryChange)
	return;

						      /////  /////  /////  /////  /////
						      //       //   //     //     // //
						      /////    //   /////  /////  /////
						         //    //   //     //     //
						      /////    //   /////  /////  //

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if(isObject(brick32Cube5Data))
{
	brick32Cube5Data.category = "ModTer";
	brick32Cube5Data.subCategory = "32x";
}

if(isObject(brick32Wedge5Data))
{
	brick32Wedge5Data.category = "ModTer";
	brick32Wedge5Data.subCategory = "32x";
}

if(isObject(brick32Ramp5Data))
{
	brick32Ramp5Data.category = "ModTer";
	brick32Ramp5Data.subCategory = "32x";
}

if(isObject(brick32CornerA5Data))
{
	brick32CornerA5Data.category = "ModTer";
	brick32CornerA5Data.subCategory = "32x";
}

if(isObject(brick32CornerB5Data))
{
	brick32CornerB5Data.category = "ModTer";
	brick32CornerB5Data.subCategory = "32x";
}

if(isObject(brick32CornerC5Data))
{
	brick32CornerC5Data.category = "ModTer";
	brick32CornerC5Data.subCategory = "32x";
}

if(isObject(brick32CornerD5Data))
{
	brick32CornerD5Data.category = "ModTer";
	brick32CornerD5Data.subCategory = "32x";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Cube5Data))
{
	brick16Cube5Data.category = "ModTer";
	brick16Cube5Data.subCategory = "16x";
}

if(isObject(brick16Wedge5Data))
{
	brick16Wedge5Data.category = "ModTer";
	brick16Wedge5Data.subCategory = "16x";
}

if(isObject(brick16Ramp5Data))
{
	brick16Ramp5Data.category = "ModTer";
	brick16Ramp5Data.subCategory = "16x";
}

if(isObject(brick16CornerA5Data))
{
	brick16CornerA5Data.category = "ModTer";
	brick16CornerA5Data.subCategory = "16x";
}

if(isObject(brick16CornerB5Data))
{
	brick16CornerB5Data.category = "ModTer";
	brick16CornerB5Data.subCategory = "16x";
}

if(isObject(brick16CornerC5Data))
{
	brick16CornerC5Data.category = "ModTer";
	brick16CornerC5Data.subCategory = "16x";
}

if(isObject(brick16CornerD5Data))
{
	brick16CornerD5Data.category = "ModTer";
	brick16CornerD5Data.subCategory = "16x";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if(isObject(brick8Cube5Data))
{
	brick8Cube5Data.category = "ModTer";
	brick8Cube5Data.subCategory = "8x";
}

if(isObject(brick8Wedge5Data))
{
	brick8Wedge5Data.category = "ModTer";
	brick8Wedge5Data.subCategory = "8x";
}

if(isObject(brick8Ramp5Data))
{
	brick8Ramp5Data.category = "ModTer";
	brick8Ramp5Data.subCategory = "8x";
}

if(isObject(brick8CornerA5Data))
{
	brick8CornerA5Data.category = "ModTer";
	brick8CornerA5Data.subCategory = "8x";
}

if(isObject(brick8CornerB5Data))
{
	brick8CornerB5Data.category = "ModTer";
	brick8CornerB5Data.subCategory = "8x";
}

if(isObject(brick8CornerC5Data))
{
	brick8CornerC5Data.category = "ModTer";
	brick8CornerC5Data.subCategory = "8x";
}

if(isObject(brick8CornerD5Data))
{
	brick8CornerD5Data.category = "ModTer";
	brick8CornerD5Data.subCategory = "8x";
}

							/////  // //  //     //
							//     // //  //     //
							/////  // //  //     //
							//     // //  //     //
							//     /////  /////  /////

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if(isObject(brick64Cube1Data))
{
	brick64Cube1Data.category = "ModTer";
	brick64Cube1Data.subCategory = "64x";
}

if(isObject(brick64Wedge1Data))
{
	brick64Wedge1Data.category = "ModTer";
	brick64Wedge1Data.subCategory = "64x";
}

if(isObject(brick64Ramp1Data))
{
	brick64Ramp1Data.category = "ModTer";
	brick64Ramp1Data.subCategory = "64x";
}

if(isObject(brick64CornerA1Data))
{
	brick64CornerA1Data.category = "ModTer";
	brick64CornerA1Data.subCategory = "64x";
}

if(isObject(brick64CornerB1Data))
{
	brick64CornerB1Data.category = "ModTer";
	brick64CornerB1Data.subCategory = "64x";
}

if(isObject(brick64CornerC1Data))
{
	brick64CornerC1Data.category = "ModTer";
	brick64CornerC1Data.subCategory = "64x";
}

if(isObject(brick64CornerD1Data))
{
	brick64CornerD1Data.category = "ModTer";
	brick64CornerD1Data.subCategory = "64x";
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if(isObject(brick32Cube1Data))
{
	brick32Cube1Data.category = "ModTer";
	brick32Cube1Data.subCategory = "32x";
}

if(isObject(brick32Wedge1Data))
{
	brick32Wedge1Data.category = "ModTer";
	brick32Wedge1Data.subCategory = "32x";
}

if(isObject(brick32Ramp1Data))
{
	brick32Ramp1Data.category = "ModTer";
	brick32Ramp1Data.subCategory = "32x";
}

if(isObject(brick32CornerA1Data))
{
	brick32CornerA1Data.category = "ModTer";
	brick32CornerA1Data.subCategory = "32x";
}

if(isObject(brick32CornerB1Data))
{
	brick32CornerB1Data.category = "ModTer";
	brick32CornerB1Data.subCategory = "32x";
}

if(isObject(brick32CornerC1Data))
{
	brick32CornerC1Data.category = "ModTer";
	brick32CornerC1Data.subCategory = "32x";
}

if(isObject(brick32CornerD1Data))
{
	brick32CornerD1Data.category = "ModTer";
	brick32CornerD1Data.subCategory = "32x";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Cube1Data))
{
	brick16Cube1Data.category = "ModTer";
	brick16Cube1Data.subCategory = "16x";
}

if(isObject(brick16Wedge1Data))
{
	brick16Wedge1Data.category = "ModTer";
	brick16Wedge1Data.subCategory = "16x";
}

if(isObject(brick16Ramp1Data))
{
	brick16Ramp1Data.category = "ModTer";
	brick16Ramp1Data.subCategory = "16x";
}

if(isObject(brick16CornerA1Data))
{
	brick16CornerA1Data.category = "ModTer";
	brick16CornerA1Data.subCategory = "16x";
}

if(isObject(brick16CornerB1Data))
{
	brick16CornerB1Data.category = "ModTer";
	brick16CornerB1Data.subCategory = "16x";
}

if(isObject(brick16CornerC1Data))
{
	brick16CornerC1Data.category = "ModTer";
	brick16CornerC1Data.subCategory = "16x";
}

if(isObject(brick16CornerD1Data))
{
	brick16CornerD1Data.category = "ModTer";
	brick16CornerD1Data.subCategory = "16x";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if(isObject(brick8Cube1Data))
{
	brick8Cube1Data.category = "ModTer";
	brick8Cube1Data.subCategory = "8x";
}

if(isObject(brick8Wedge1Data))
{
	brick8Wedge1Data.category = "ModTer";
	brick8Wedge1Data.subCategory = "8x";
}

if(isObject(brick8Ramp1Data))
{
	brick8Ramp1Data.category = "ModTer";
	brick8Ramp1Data.subCategory = "8x";
}

if(isObject(brick8CornerA1Data))
{
	brick8CornerA1Data.category = "ModTer";
	brick8CornerA1Data.subCategory = "8x";
}
if(isObject(brick8CornerB1Data))
{
	brick8CornerB1Data.category = "ModTer";
	brick8CornerB1Data.subCategory = "8x";
}

if(isObject(brick8CornerC1Data))
{
	brick8CornerC1Data.category = "ModTer";
	brick8CornerC1Data.subCategory = "8x";
}

if(isObject(brick8CornerD1Data))
{
	brick8CornerD1Data.category = "ModTer";
	brick8CornerD1Data.subCategory = "8x";
}

							  ////      //  // //
							     //    //   // //
							  ////    //    /////
							     //  //        //
							  ////  //         //

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if(isObject(brick64Cube2Data))
{
	brick64Cube2Data.category = "ModTer";
	brick64Cube2Data.subCategory = "64x";
}

if(isObject(brick64Wedge2Data))
{
	brick64Wedge2Data.category = "ModTer";
	brick64Wedge2Data.subCategory = "64x";
}

if(isObject(brick64Ramp2Data))
{
	brick64Ramp2Data.category = "ModTer";
	brick64Ramp2Data.subCategory = "64x";
}

if(isObject(brick64CornerA2Data))
{
	brick64CornerA2Data.category = "ModTer";
	brick64CornerA2Data.subCategory = "64x";
}

if(isObject(brick64CornerB2Data))
{
	brick64CornerB2Data.category = "ModTer";
	brick64CornerB2Data.subCategory = "64x";
}

if(isObject(brick64CornerC2Data))
{
	brick64CornerC2Data.category = "ModTer";
	brick64CornerC2Data.subCategory = "64x";
}

if(isObject(brick64CornerD2Data))
{
	brick64CornerD2Data.category = "ModTer";
	brick64CornerD2Data.subCategory = "64x";
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if(isObject(brick32Cube2Data))
{
	brick32Cube2Data.category = "ModTer";
	brick32Cube2Data.subCategory = "32x";
}

if(isObject(brick32Wedge2Data))
{
	brick32Wedge2Data.category = "ModTer";
	brick32Wedge2Data.subCategory = "32x";
}

if(isObject(brick32Ramp2Data))
{
	brick32Ramp2Data.category = "ModTer";
	brick32Ramp2Data.subCategory = "32x";
}

if(isObject(brick32CornerA2Data))
{
	brick32CornerA2Data.category = "ModTer";
	brick32CornerA2Data.subCategory = "32x";
}

if(isObject(brick32CornerB2Data))
{
	brick32CornerB2Data.category = "ModTer";
	brick32CornerB2Data.subCategory = "32x";
}

if(isObject(brick32CornerC2Data))
{
	brick32CornerC2Data.category = "ModTer";
	brick32CornerC2Data.subCategory = "32x";
}

if(isObject(brick32CornerD2Data))
{
	brick32CornerD2Data.category = "ModTer";
	brick32CornerD2Data.subCategory = "32x";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Cube2Data))
{
	brick16Cube2Data.category = "ModTer";
	brick16Cube2Data.subCategory = "16x";
}

if(isObject(brick16Wedge2Data))
{
	brick16Wedge2Data.category = "ModTer";
	brick16Wedge2Data.subCategory = "16x";
}

if(isObject(brick16Ramp2Data))
{
	brick16Ramp2Data.category = "ModTer";
	brick16Ramp2Data.subCategory = "16x";
}

if(isObject(brick16CornerA2Data))
{
	brick16CornerA2Data.category = "ModTer";
	brick16CornerA2Data.subCategory = "16x";
}

if(isObject(brick16CornerB2Data))
{
	brick16CornerB2Data.category = "ModTer";
	brick16CornerB2Data.subCategory = "16x";
}

if(isObject(brick16CornerC2Data))
{
	brick16CornerC2Data.category = "ModTer";
	brick16CornerC2Data.subCategory = "16x";
}

if(isObject(brick16CornerD2Data))
{
	brick16CornerD2Data.category = "ModTer";
	brick16CornerD2Data.subCategory = "16x";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if(isObject(brick8Cube2Data))
{
	brick8Cube2Data.category = "ModTer";
	brick8Cube2Data.subCategory = "8x";
}

if(isObject(brick8Wedge2Data))
{
	brick8Wedge2Data.category = "ModTer";
	brick8Wedge2Data.subCategory = "8x";
}

if(isObject(brick8Ramp2Data))
{
	brick8Ramp2Data.category = "ModTer";
	brick8Ramp2Data.subCategory = "8x";
}

if(isObject(brick8CornerA2Data))
{
	brick8CornerA2Data.category = "ModTer";
	brick8CornerA2Data.subCategory = "8x";
}

if(isObject(brick8CornerB2Data))
{
	brick8CornerB2Data.category = "ModTer";
	brick8CornerB2Data.subCategory = "8x";
}

if(isObject(brick8CornerC2Data))
{
	brick8CornerC2Data.category = "ModTer";
	brick8CornerC2Data.subCategory = "8x";
}

if(isObject(brick8CornerD2Data))
{
	brick8CornerD2Data.category = "ModTer";
	brick8CornerD2Data.subCategory = "8x";
}

							      //     //  /////
							      //    //   // //
							      //   //      //
							      //  //      //
							      // //      /////

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if(isObject(brick64Cube3Data))
{
	brick64Cube3Data.category = "ModTer";
	brick64Cube3Data.subCategory = "64x";
}

if(isObject(brick64Wedge3Data))
{
	brick64Wedge3Data.category = "ModTer";
	brick64Wedge3Data.subCategory = "64x";
}

if(isObject(brick64Ramp3Data))
{
	brick64Ramp3Data.category = "ModTer";
	brick64Ramp3Data.subCategory = "64x";
}

if(isObject(brick64CornerA3Data))
{
	brick64CornerA3Data.category = "ModTer";
	brick64CornerA3Data.subCategory = "64x";
}

if(isObject(brick64CornerB3Data))
{
	brick64CornerB3Data.category = "ModTer";
	brick64CornerB3Data.subCategory = "64x";
}

if(isObject(brick64CornerC3Data))
{
	brick64CornerC3Data.category = "ModTer";
	brick64CornerC3Data.subCategory = "64x";
}

if(isObject(brick64CornerD3Data))
{
	brick64CornerD3Data.category = "ModTer";
	brick64CornerD3Data.subCategory = "64x";
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if(isObject(brick32Cube3Data))
{
	brick32Cube3Data.category = "ModTer";
	brick32Cube3Data.subCategory = "32x";
}

if(isObject(brick32Wedge3Data))
{
	brick32Wedge3Data.category = "ModTer";
	brick32Wedge3Data.subCategory = "32x";
}

if(isObject(brick32Ramp3Data))
{
	brick32Ramp3Data.category = "ModTer";
	brick32Ramp3Data.subCategory = "32x";
}

if(isObject(brick32CornerA3Data))
{
	brick32CornerA3Data.category = "ModTer";
	brick32CornerA3Data.subCategory = "32x";
}

if(isObject(brick32CornerB3Data))
{
	brick32CornerB3Data.category = "ModTer";
	brick32CornerB3Data.subCategory = "32x";
}

if(isObject(brick32CornerC3Data))
{
	brick32CornerC3Data.category = "ModTer";
	brick32CornerC3Data.subCategory = "32x";
}

if(isObject(brick32CornerD3Data))
{
	brick32CornerD3Data.category = "ModTer";
	brick32CornerD3Data.subCategory = "32x";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Cube3Data))
{
	brick16Cube3Data.category = "ModTer";
	brick16Cube3Data.subCategory = "16x";
}

if(isObject(brick16Wedge3Data))
{
	brick16Wedge3Data.category = "ModTer";
	brick16Wedge3Data.subCategory = "16x";
}

if(isObject(brick16Ramp3Data))
{
	brick16Ramp3Data.category = "ModTer";
	brick16Ramp3Data.subCategory = "16x";
}

if(isObject(brick16CornerA3Data))
{
	brick16CornerA3Data.category = "ModTer";
	brick16CornerA3Data.subCategory = "16x";
}

if(isObject(brick16CornerB3Data))
{
	brick16CornerB3Data.category = "ModTer";
	brick16CornerB3Data.subCategory = "16x";
}

if(isObject(brick16CornerC3Data))
{
	brick16CornerC3Data.category = "ModTer";
	brick16CornerC3Data.subCategory = "16x";
}

if(isObject(brick16CornerD3Data))
{
	brick16CornerD3Data.category = "ModTer";
	brick16CornerD3Data.subCategory = "16x";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if(isObject(brick8Cube3Data))
{
	brick8Cube3Data.category = "ModTer";
	brick8Cube3Data.subCategory = "8x";
}

if(isObject(brick8Wedge3Data))
{
	brick8Wedge3Data.category = "ModTer";
	brick8Wedge3Data.subCategory = "8x";
}

if(isObject(brick8Ramp3Data))
{
	brick8Ramp3Data.category = "ModTer";
	brick8Ramp3Data.subCategory = "8x";
}

if(isObject(brick8CornerA3Data))
{
	brick8CornerA3Data.category = "ModTer";
	brick8CornerA3Data.subCategory = "8x";
}

if(isObject(brick8CornerB3Data))
{
	brick8CornerB3Data.category = "ModTer";
	brick8CornerB3Data.subCategory = "8x";
}

if(isObject(brick8CornerC3Data))
{
	brick8CornerC3Data.category = "ModTer";
	brick8CornerC3Data.subCategory = "8x";
}

if(isObject(brick8CornerD3Data))
{
	brick8CornerD3Data.category = "ModTer";
	brick8CornerD3Data.subCategory = "8x";
}

							      //     //  // //
							      //    //   // //
							      //   //    /////
							      //  //        //
							      // //         //

/////////////////////////////////////////////////////////////////////64x////////////////////////////////////////////////////////////////////

if(isObject(brick64Cube4Data))
{
	brick64Cube4Data.category = "ModTer";
	brick64Cube4Data.subCategory = "64x";
}

if(isObject(brick64Wedge4Data))
{
	brick64Wedge4Data.category = "ModTer";
	brick64Wedge4Data.subCategory = "64x";
}

if(isObject(brick64Ramp4Data))
{
	brick64Ramp4Data.category = "ModTer";
	brick64Ramp4Data.subCategory = "64x";
}

if(isObject(brick64CornerA4Data))
{
	brick64CornerA4Data.category = "ModTer";
	brick64CornerA4Data.subCategory = "64x";
}

if(isObject(brick64CornerB4Data))
{
	brick64CornerB4Data.category = "ModTer";
	brick64CornerB4Data.subCategory = "64x";
}

if(isObject(brick64CornerC4Data))
{
	brick64CornerC4Data.category = "ModTer";
	brick64CornerC4Data.subCategory = "64x";
}

if(isObject(brick64CornerD4Data))
{
	brick64CornerD4Data.category = "ModTer";
	brick64CornerD4Data.subCategory = "64x";
}

/////////////////////////////////////////////////////////////////////32x////////////////////////////////////////////////////////////////////

if(isObject(brick32Cube4Data))
{
	brick32Cube4Data.category = "ModTer";
	brick32Cube4Data.subCategory = "32x";
}

if(isObject(brick32Wedge4Data))
{
	brick32Wedge4Data.category = "ModTer";
	brick32Wedge4Data.subCategory = "32x";
}

if(isObject(brick32Ramp4Data))
{
	brick32Ramp4Data.category = "ModTer";
	brick32Ramp4Data.subCategory = "32x";
}

if(isObject(brick32CornerA4Data))
{
	brick32CornerA4Data.category = "ModTer";
	brick32CornerA4Data.subCategory = "32x";
}

if(isObject(brick32CornerB4Data))
{
	brick32CornerB4Data.category = "ModTer";
	brick32CornerB4Data.subCategory = "32x";
}

if(isObject(brick32CornerC4Data))
{
	brick32CornerC4Data.category = "ModTer";
	brick32CornerC4Data.subCategory = "32x";
}

if(isObject(brick32CornerD4Data))
{
	brick32CornerD4Data.category = "ModTer";
	brick32CornerD4Data.subCategory = "32x";
}

/////////////////////////////////////////////////////////////////////16x////////////////////////////////////////////////////////////////////

if(isObject(brick16Cube4Data))
{
	brick16Cube4Data.category = "ModTer";
	brick16Cube4Data.subCategory = "16x";
}

if(isObject(brick16Wedge4Data))
{
	brick16Wedge4Data.category = "ModTer";
	brick16Wedge4Data.subCategory = "16x";
}

if(isObject(brick16Ramp4Data))
{
	brick16Ramp4Data.category = "ModTer";
	brick16Ramp4Data.subCategory = "16x";
}

if(isObject(brick16CornerA4Data))
{
	brick16CornerA4Data.category = "ModTer";
	brick16CornerA4Data.subCategory = "16x";
}

if(isObject(brick16CornerB4Data))
{
	brick16CornerB4Data.category = "ModTer";
	brick16CornerB4Data.subCategory = "16x";
}

if(isObject(brick16CornerC4Data))
{
	brick16CornerC4Data.category = "ModTer";
	brick16CornerC4Data.subCategory = "16x";
}

if(isObject(brick16CornerD4Data))
{
	brick16CornerD4Data.category = "ModTer";
	brick16CornerD4Data.subCategory = "16x";
}

/////////////////////////////////////////////////////////////////////8x/////////////////////////////////////////////////////////////////////

if(isObject(brick8Cube4Data))
{
	brick8Cube4Data.category = "ModTer";
	brick8Cube4Data.subCategory = "8x";
}

if(isObject(brick8Wedge4Data))
{
	brick8Wedge4Data.category = "ModTer";
	brick8Wedge4Data.subCategory = "8x";
}

if(isObject(brick8Ramp4Data))
{
	brick8Ramp4Data.category = "ModTer";
	brick8Ramp4Data.subCategory = "8x";
}

if(isObject(brick8CornerA4Data))
{
	brick8CornerA4Data.category = "ModTer";
	brick8CornerA4Data.subCategory = "8x";
}

if(isObject(brick8CornerB4Data))
{
	brick8CornerB4Data.category = "ModTer";
	brick8CornerB4Data.subCategory = "8x";
}

if(isObject(brick8CornerC4Data))
{
	brick8CornerC4Data.category = "ModTer";
	brick8CornerC4Data.subCategory = "8x";
}

if(isObject(brick8CornerD4Data))
{
	brick8CornerD4Data.category = "ModTer";
	brick8CornerD4Data.subCategory = "8x";
}
