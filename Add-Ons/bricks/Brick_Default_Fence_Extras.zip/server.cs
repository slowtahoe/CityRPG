datablock fxDTSBrickData(brick4x1x2FenceData)
{
	brickFile = "./shapes/4x1x2Fence.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x2 Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/4x1x2Fence";
};

datablock fxDTSBrickData(brick1x2x3UpsideDownFenceData)
{
	brickFile = "./shapes/fenceupsidedown.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "Upside Down Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/fenceupsidedown";
};

datablock fxDTSBrickData(brick1x2x3VerticalFenceData)
{
	brickFile = "./shapes/fencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "Vertical Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/fencevert";
};

datablock fxDTSBrickData(brick1x2x3VerticalFenceRoundedData)
{
	brickFile = "./shapes/fencevertrounded.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "Vertical Fence Rounded";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/fencevertrounded";
};

datablock fxDTSBrickData(brick1x2x3VerticalFencePointedData)
{
	brickFile = "./shapes/fencevertpointed.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "Vertical Fence Pointed";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/fencevertpointed";
};

datablock fxDTSBrickData(brick1x2x3HorizontalFenceData)
{
	brickFile = "./shapes/fencehorizontal.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "Horizontal Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/fencehorizontal";
};

datablock fxDTSBrickData(brick1x2x2FenceData)
{
	brickFile = "./shapes/1x2x2Fence.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x2 Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x2x2Fence";
};

datablock fxDTSBrickData(brick1x2x2UpsideDownFenceData)
{
	brickFile = "./shapes/1x2x2fenceupsidedown.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x2 Upside Down Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x2x2fenceupsidedown";
};

datablock fxDTSBrickData(brick1x2x2VerticleFenceData)
{
	brickFile = "./shapes/1x2x2fencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x2 Verticle Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x2x2fencevert";
};

datablock fxDTSBrickData(brick1x2x2VerticleFenceRoundedData)
{
	brickFile = "./shapes/1x2x2fencevertrounded.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x2 Verticle Fence Rounded";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x2x2fencevertrounded";
};

datablock fxDTSBrickData(brick1x2x2VerticleFencePointedData)
{
	brickFile = "./shapes/1x2x2fencevertpointed.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x2 Verticle Fence Pointed";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x2x2fencevertpointed";
};

datablock fxDTSBrickData(brick1x3x5VerticleFenceData)
{
	brickFile = "./shapes/1x3x5fencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x3x5 Verticle Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x3x5fencevert";
};

datablock fxDTSBrickData(brick1x3x5VerticleFenceRoundedData)
{
	brickFile = "./shapes/1x3x5fencevertrounded.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x3x5 Verticle Fence Rounded";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x3x5fencevertrounded";
};

datablock fxDTSBrickData(brick1x4x9VerticalFenceData)
{
	brickFile = "./shapes/1x4x9fencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x9 Vertical Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x4x9fencevert";
};

datablock fxDTSBrickData(brick1x4x10FenceUpsideDownData)
{
	brickFile = "./shapes/1x4x10fenceupsidedown.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x10 Fence Upside Down";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x4x10fenceupsidedown";
};

datablock fxDTSBrickData(brick1x4x10FenceData)
{
	brickFile = "./shapes/1x4x10fence.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x10 Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/1x4x10fence";
};

datablock fxDTSBrickData(brick1x2x18VerticalFenceData)
{
	brickFile = "./shapes/6heightfencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x18 Vertical Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6heightfencevert";
};

datablock fxDTSBrickData(brick1x2x18VerticalFenceRoundedData)
{
	brickFile = "./shapes/6heightfencevertrounded.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x18 Vertical Fence Rounded";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6heightfencevertrounded";
};

datablock fxDTSBrickData(brick1x2x18VerticalFencePointedData)
{
	brickFile = "./shapes/6heightfencevertpointed.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x18 Vertical Fence Pointed";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6heightfencevertpointed";
};

datablock fxDTSBrickData(brick1x2x18VerticalFencePointed2Data)
{
	brickFile = "./shapes/6heightfencevertpointed2.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x2x18 Vertical Fence Pointed 2";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6heightfencevertpointed2";
};

datablock fxDTSBrickData(brick1x4x18VerticalFenceData)
{
	brickFile = "./shapes/6height4xfencevert.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x18 Vertical Fence";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6height4xfencevert";
};

datablock fxDTSBrickData(brick1x4x18VerticalFenceRoundedData)
{
	brickFile = "./shapes/6height4xfencevertrounded.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x18 Vertical Fence Rounded";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6height4xfencevertrounded";
};

datablock fxDTSBrickData(brick1x4x18VerticalFencePointedData)
{
	brickFile = "./shapes/6height4xfencevertpointed.blb";
	category = "Special";
	subCategory = "Fence Extras";
	uiName = "1x4x18 Vertical Fence Pointed";
	iconName = "Add-Ons/Brick_Default_Fence_Extras/Icons/6height4xfencevertpointed";
};