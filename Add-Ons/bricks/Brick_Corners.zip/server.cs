datablock fxDTSBrickData (brick1x1CornerData){
	brickFile = "./1x1Corner.blb";
	collisionShapeName = "./1x1Corner.dts";
	category = "Bricks";
	subCategory = "Corners";
	uiName = "1x1 Corner";
	iconName = "add-ons/Brick_Corners/1x1Corner";
};

datablock fxDTSBrickData (brick1x1x5CornerData){
	brickFile = "./1x1x5Corner.blb";
	collisionShapeName = "./1x1x5Corner.dts";
	category = "Bricks";
	subCategory = "Corners";
	uiName = "1x1x5 Corner";
	iconName = "add-ons/Brick_Corners/1x1x5Corner";
};

datablock fxDTSBrickData (brick2x2CornerData){
	brickFile = "./bricks/2x2Corner.blb";
	collisionShapeName = "./Shapes/bricks/2x2Corner.dts";
	category = "Bricks";
	subCategory = "Corners";
	uiName = "2x2 Corner";
	iconName = "add-ons/Brick_Corners/2x2Corner";
};

datablock fxDTSBrickData (brick2x2x5CornerData){
	brickFile = "./2x2x5Corner.blb";
	collisionShapeName = "./2x2x5Corner.dts";
	category = "Bricks";
	subCategory = "Corners";
	uiName = "2x2x5 Corner";
	iconName = "add-ons/Brick_Corners/2x2x5Corner";
};

datablock fxDTSBrickData (brick1x1FCornerData){
	brickFile = "./1x1FCorner.blb";
	collisionShapeName = "./1x1FCorner.dts";
	category = "Plates";
	subCategory = "Corners";
	uiName = "1x1F Corner";
	iconName = "add-ons/Brick_Corners/1x1FCorner";
};

datablock fxDTSBrickData (brick2x2FCornerData){
	brickFile = "./2x2FCorner.blb";
	collisionShapeName = "./2x2FCorner.dts";
	category = "Plates";
	subCategory = "Corners";
	uiName = "2x2F Corner";
	iconName = "add-ons/Brick_Corners/2x2FCorner";
};