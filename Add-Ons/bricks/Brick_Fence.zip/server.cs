datablock fxDTSBrickData(brick1x4FenceData)
{
	brickFile = "./Bricks/1x4fence.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x4 Fence";
	iconName = "Add-Ons/Brick_Fence/Icons/1x4fence";
};

///////////////////////////////////////////////////////
//Brick removed due to release in V15//////////////////
///////////////////////////////////////////////////////
//datablock fxDTSBrickData(brick1x4x2PicketFenceData)//
//{                                                  //
//	brickFile = "./Bricks/1x4x2picketFence.blb"; //
//	category = "Special";                        //
//	subCategory = "Walls";                       //
//	uiName = "1x4x2 Picket Fence";               //
//	iconName = "";                               //
//};                                                 //
///////////////////////////////////////////////////////

datablock fxDTSBrickData(brick1x6x2ArchedFenceData)
{
	brickFile = "./Bricks/1x6x2archedFence.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x6x2 Arched Fence";
	iconName = "Add-Ons/Brick_Fence/Icons/1x6x2archedFence";
};

datablock fxDTSBrickData(brick1x8CountryFenceData)
{
	brickFile = "./Bricks/1x8countryFence.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x8 Country Fence";
	iconName = "Add-Ons/Brick_Fence/Icons/1x8countryFence";
};

/////////////////////////////////////////////////////////
//Brick removed due to release in V15////////////////////
/////////////////////////////////////////////////////////
//datablock fxDTSBrickData(brick1x4x2SpindledFenceData)//
//{                                                    //
//	brickFile = "./Bricks/1x4x2spindledFence.blb"; //
//	category = "Special";                          //
//	subCategory = "Walls";                         //
//	uiName = "1x4x2 Spindled Fence";               //
//	iconName = "";                                 //
//};                                                   //
/////////////////////////////////////////////////////////

datablock fxDTSBrickData(brick4x4x2RoundCornerBarsData)
{
	brickFile = "./Bricks/4x4x2roundCornerBars.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "4x4x2 Corner Bars";
	iconName = "Add-Ons/Brick_Fence/Icons/4x4x2roundCornerBars";
	collisionShapeName = "./Collisions/4x4x2roundCornerBars.dts";
};

datablock fxDTSBrickData(brick1x6x2TrainFenceData)
{
	brickFile = "./Bricks/1x6x2trainFence.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x6x2 Train Fence";
	iconName = "Add-Ons/Brick_Fence/Icons/1x6x2trainFence";
};



/////////////////////////////////
//New generation 09/07/2012/////////
////////////////(DD/MM/YYYY)//////////
///////////////////////////////////////
                            ////////////
                             ///////////
                             ///////////
                        /////////////////////
                          /////////////////
                            /////////////
                              /////////
                                /////
                                 ///



datablock fxDTSBrickData(brick1x4x2StuddedRailData)
{
	brickFile = "./Bricks/1x4x2studdedRail.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x4x2 Studded Rail";
	iconName = "Add-Ons/Brick_Fence/Icons/1x4x2studdedRail";
};

datablock fxDTSBrickData(brick1x6RailData)
{
	brickFile = "./Bricks/1x6rail.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x6 Rail";
	iconName = "Add-Ons/Brick_Fence/Icons/1x6rail";
};

datablock fxDTSBrickData(brick1x8x2RailData)
{
	brickFile = "./Bricks/1x8x2rail.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x8x2 Rail";
	iconName = "Add-Ons/Brick_Fence/Icons/1x8x2rail";
};

datablock fxDTSBrickData(brick1x4x2RailData)
{
	brickFile = "./Bricks/1x4x2rail.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x4x2 Rail";
	iconName = "Add-Ons/Brick_Fence/Icons/1x4x2rail";
};