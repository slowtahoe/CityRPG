datablock fxDTSBrickData(brick4x1x5windowprintData)
{
	brickFile = "./4x1x5windowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "4x1x5 Window Print";
	iconName = "Add-Ons/Brick_Window_Prints/4x1x5windowprint";
	orientationFix = 3;

	hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick2x4x5WindowprintData)
{
	brickFile = "./2x4x5windowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "2x4x5 Window Slanted Print";
	iconName = "Add-Ons/Brick_Window_Prints/2x4x5windowprint";
	orientationFix = 3;
	collisionShapeName = "./2x4x5window.dts";

	hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick3x4x6WindowprintData)
{
	brickFile = "./3x4x6windowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "3x4x6 Window Slanted Print";
	iconName = "Add-Ons/Brick_Window_Prints/3x4x6windowprint";
	orientationFix = 3;
	collisionShapeName = "./3x4x6window.dts";

	hasPrint = 1;
	printAspectRatio = "1x1";
};


datablock fxDTSBrickData(brick4x4x3WindowprintData)
{
	brickFile = "./4x4x3windowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "4x4x3 Window Slanted Print";
	iconName = "Add-Ons/Brick_Window_Prints/4x4x3windowprint";
	orientationFix = 3;
	collisionShapeName = "./4x4x3window.dts";

	hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick4x5x2WindowprintData)
{
	brickFile = "./4x5x2windowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "4x5x2 Window Slanted Print";
	iconName = "Add-Ons/Brick_Window_Prints/4x5x2windowprint";
	orientationFix = 3;
	collisionShapeName = "./4x5x2window.dts";

	hasPrint = 1;
	printAspectRatio = "1x1";
};

datablock fxDTSBrickData(brick3x8x6BayWindowprintData)
{
	brickFile = "./3x8x6baywindowprint.blb";
	category = "Special";
	subCategory = "Print Windows";
	uiName = "Bay Window Print";
	iconName = "Add-Ons/Brick_Window_Prints/3x8x6baywindowprint";
	orientationFix = 1;
	collisionShapeName = "./3x8x6baywindow.dts";

	hasPrint = 1;
	printAspectRatio = "1x1";
};