datablock fxDTSBrickData(brick1x6curvedrampData)
{
	brickFile = "./1x6curvedramp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "1x6 Curved Ramp";
	iconName = "Add-Ons/Brick_ExtraRamps/1x6curvedramp";
	collisionShapeName = "./1x6curvedramp.dts";
};

datablock fxDTSBrickData(brick2x6curvedrampData)
{
	brickFile = "./2x6curvedramp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "2x6 Curved Ramp";
	iconName = "Add-Ons/Brick_ExtraRamps/2x6curvedramp";
	collisionShapeName = "./2x6curvedramp.dts";
};

datablock fxDTSBrickData(brick1x6curvedrampUpData)
{
	brickFile = "./1x6curvedrampUp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "1x6 Curved Inverted";
	iconName = "Add-Ons/Brick_ExtraRamps/1x6curvedrampup";
	collisionShapeName = "./1x6curvedrampUp.dts";
};


datablock fxDTSBrickData(brick2x6curvedrampUpData)
{
	brickFile = "./2x6curvedrampUp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "2x6 Curved Inverted";
	iconName = "Add-Ons/Brick_ExtraRamps/2x6curvedrampUp";
	collisionShapeName = "./2x6curvedrampUp.dts";
};


datablock fxDTSBrickData(brick2x4curvedrampData)
{
	brickFile = "./2x4curvedramp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "2x4 Curved Ramp";
	iconName = "Add-Ons/Brick_ExtraRamps/2x4curvedramp";
	collisionShapeName = "./2x4curvedramp.dts";
};

datablock fxDTSBrickData(brick1x3curvedrampData)
{
	brickFile = "./1x3curvedramp.blb";
	category = "Ramps";
	subCategory = "Curved";
	uiName = "1x3 Curved Ramp";
	iconName = "Add-Ons/Brick_ExtraRamps/1x3curvedramp";
	collisionShapeName = "./1x3curvedramp.dts";
};

datablock fxDTSBrickData(brick1x1rampData)
{
	brickFile = "./1x1ramp.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "30� Ramp 1x";
	iconName = "Add-Ons/Brick_ExtraRamps/1x1ramp";
	collisionShapeName = "./1x1ramp.dts";
};

datablock fxDTSBrickData(brick6x8rampData)
{
	brickFile = "./6x8ramp.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "10� Ramp 8x";
	iconName = "Add-Ons/Brick_ExtraRamps/6x8ramp";
	collisionShapeName = "./6x8ramp.dts";
};

datablock fxDTSBrickData(brick1x2x2rampData)
{
	brickFile = "./1x2x2ramp.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65� Ramp 1x";
	iconName = "Add-Ons/Brick_ExtraRamps/1x2x2ramp";
	collisionShapeName = "./1x2x2ramp.dts";
};

datablock fxDTSBrickData(brick2x2x2rampData)
{
	brickFile = "./2x2x2ramp.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65� Ramp 2x";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x2ramp";
	collisionShapeName = "./2x2x2ramp.dts";
};

datablock fxDTSBrickData(brick2x2x2rampCornerData)
{
	brickFile = "./2x2x2rampCorner.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65� Ramp Corner";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x2rampCorner";
	collisionShapeName = "./2x2x2rampCorner.dts";
};

datablock fxDTSBrickData(brick1x2x2rampUpData)
{
	brickFile = "./1x2x2rampUp.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "-65� Ramp 1x";
	iconName = "Add-Ons/Brick_ExtraRamps/1x2x2rampUp";
	collisionShapeName = "./1x2x2rampUp.dts";
};

datablock fxDTSBrickData(brick2x2x2rampUpData)
{
	brickFile = "./2x2x2rampUp.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "-65� Ramp 2x";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x2rampUp";
	collisionShapeName = "./2x2x2rampUp.dts";
};

datablock fxDTSBrickData(brick2x2x2rampUpCornerData)
{
	brickFile = "./2x2x2rampUpCorner.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "-65� Ramp Corner";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x2rampUpCorner";
	collisionShapeName = "./2x2x2rampUpCorner.dts";
};

datablock fxDTSBrickData(brick2x2x2rampConeData)
{
	brickFile = "./2x2x2rampCone.blb";
	category = "Ramps";
	subCategory = "72 Degree";
	uiName = "72� Ramp Cone";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x2rampCone";
	collisionShapeName = "./2x2x2rampCone.dts";
};

datablock fxDTSBrickData(brick2x2x3rampConeData)
{
	brickFile = "./2x2x3rampCone.blb";
	category = "Ramps";
	subCategory = "80 Degree";
	uiName = "80� Ramp Cone";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2x3rampCone";
	collisionShapeName = "./2x2x3rampCone.dts";
};

datablock fxDTSBrickData(brick2x2rampConeData)
{
	brickFile = "./2x2rampCone.blb";
	category = "Ramps";
	subCategory = "65 Degree";
	uiName = "65� Ramp Cone";
	iconName = "Add-Ons/Brick_ExtraRamps/2x2rampCone";
	collisionShapeName = "./2x2rampCone.dts";
};

datablock fxDTSBrickData(brick3x4rampCapData)
{
	brickFile = "./3x4rampCap.blb";
	category = "Ramps";
	subCategory = "Misc";
	uiName = "45� / 25�  Ramp Cap";
	iconName = "Add-Ons/Brick_ExtraRamps/3x4rampCap";
	collisionShapeName = "./3x4rampCap.dts";
};