//default bricks
if(!isObject(brick2x2cornerData))
{
	echo("Brick_V15 isn't activated, creating default 2x2 corner datablock ourselves");
	if(isFile("Add-Ons/Brick_V15/2x2corner.blb"))
	{
		datablock fxDTSBrickData(brick2x2cornerData)
		{
			brickFile = "Add-Ons/Brick_V15/2x2corner.blb";
			category = "Bricks";
			subCategory = "2x";
			uiName = "2x2 Corner";
			iconName = "Add-Ons/Brick_V15/2x2 Corner";
		};
	}
	else
		error("Add-Ons/Brick_V15/2x2corner.blb doesn't exist. What did you do?");
}

//normal bricks
datablock fxDTSBrickData(brick2x2fcornerData)
{
	brickFile = "./bricks/2x2FLshape.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x2F L-Shaped";
	iconName = "Add-Ons/Brick_LShaped/icons/2x2FLshapeicon";
};

datablock fxDTSBrickData(brick2x2x3cornerData)
{
	brickFile = "./bricks/2x2x3Lshape.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x2x3 L-Shaped";
	iconName = "Add-Ons/Brick_LShaped/icons/2x2x3Lshapeicon";
};

datablock fxDTSBrickData(brick2x2x5cornerData)
{
	brickFile = "./bricks/2x2x5Lshape.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x2x5 L-Shaped";
	iconName = "Add-Ons/Brick_LShaped/icons/2x2x5Lshapeicon";
};

//print bricks
datablock fxDTSBrickData(brick2x2FcornerprintData)
{
	brickFile = "./bricks/2x2FLshapeprint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F L-Shaped Print";
	iconName = "Add-Ons/Brick_LShaped/icons/2x2FLshapeprinticon";
	
	hasPrint = true;
	printAspectRatio = "2x2fL";
	orientationFix = 3;
};

datablock fxDTSBrickData(brick2x2cornerprintData)
{
	brickFile = "./bricks/2x2Lshapeprint.blb";
	category = "Bricks";
	subCategory = "Prints";
	uiName = "2x2 L-Shaped Print";
	iconName = "Add-Ons/Brick_LShaped/icons/2x2Lshapeprinticon";
	
	hasPrint = true;
	printAspectRatio = "2x2L";
	orientationFix = 3;
};