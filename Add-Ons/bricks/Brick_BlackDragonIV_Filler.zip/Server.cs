datablock fxDTSBrickData (brick1x5x2BrickData)
{
	brickFile = "./1x5H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x5H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5H";
};

datablock fxDTSBrickData (brick1x7x2BrickData)
{
	brickFile = "./1x7H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x7H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7H";
};

datablock fxDTSBrickData (brick1x9x2BrickData)
{
	brickFile = "./1x9H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x9H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9H";
};

datablock fxDTSBrickData (brick1x11x2BrickData)
{
	brickFile = "./1x11H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x11H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11H";
};

datablock fxDTSBrickData (brick1x13x2BrickData)
{
	brickFile = "./1x13H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x13H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13H";
};

datablock fxDTSBrickData (brick1x14x2BrickData)
{
	brickFile = "./1x14H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x14H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14H";
};

datablock fxDTSBrickData (brick1x15x2BrickData)
{
	brickFile = "./1x15H.blb";
	category = "Bricks";
	subCategory = "Half";
	uiName = "1x15H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15H";
};

datablock fxDTSBrickData (brick2x5x2BrickData)
{
	brickFile = "./2x5H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x5H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5H";
};

datablock fxDTSBrickData (brick2x7x2BrickData)
{
	brickFile = "./2x7H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x7H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7H";
};

datablock fxDTSBrickData (brick2x9x2BrickData)
{
	brickFile = "./2x9H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x9H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9H";
};

datablock fxDTSBrickData (brick2x11x2BrickData)
{
	brickFile = "./2x11H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x11H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11H";
};

datablock fxDTSBrickData (brick2x13x2BrickData)
{
	brickFile = "./2x13H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x13H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13H";
};

datablock fxDTSBrickData (brick2x14x2BrickData)
{
	brickFile = "./2x14H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x14H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14H";
};

datablock fxDTSBrickData (brick2x15x2BrickData)
{
	brickFile = "./2x15H.blb";
	category = "Bricks";
	subCategory = Half;
	uiName = "2x15H";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15H";
};

datablock fxDTSBrickData (brick1x5x6BrickData)
{
	brickFile = "./1x5x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x5x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5x2";
};

datablock fxDTSBrickData (brick1x7x6BrickData)
{
	brickFile = "./1x7x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x7x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7x2";
};

datablock fxDTSBrickData (brick1x9x6BrickData)
{
	brickFile = "./1x9x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x9x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9x2";
};

datablock fxDTSBrickData (brick1x11x6BrickData)
{
	brickFile = "./1x11x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x11x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11x2";
};

datablock fxDTSBrickData (brick1x13x6BrickData)
{
	brickFile = "./1x13x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x13x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13x2";
};

datablock fxDTSBrickData (brick1x14x6BrickData)
{
	brickFile = "./1x14x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x14x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14x2";
};

datablock fxDTSBrickData (brick1x15x6BrickData)
{
	brickFile = "./1x15x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "1x15x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15x2";
};

datablock fxDTSBrickData (brick2x5x6BrickData)
{
	brickFile = "./2x5x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x5x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5x2";
};

datablock fxDTSBrickData (brick2x7x6BrickData)
{
	brickFile = "./2x7x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x7x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7x2";
};

datablock fxDTSBrickData (brick2x9x6BrickData)
{
	brickFile = "./2x9x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x9x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9x2";
};

datablock fxDTSBrickData (brick2x11x6BrickData)
{
	brickFile = "./2x11x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x11x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11x2";
};

datablock fxDTSBrickData (brick2x13x6BrickData)
{
	brickFile = "./2x13x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x13x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13x2";
};

datablock fxDTSBrickData (brick2x14x6BrickData)
{
	brickFile = "./2x14x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x14x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14x2";
};

datablock fxDTSBrickData (brick2x15x6BrickData)
{
	brickFile = "./2x15x2.blb";
	category = "Bricks";
	subCategory = "2x Height";
	uiName = "2x15x2";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15x2";
};

datablock fxDTSBrickData (brick1x5x9BrickData)
{
	brickFile = "./1x5x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x5x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5x3";
};

datablock fxDTSBrickData (brick1x7x9BrickData)
{
	brickFile = "./1x7x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x7x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7x3";
};

datablock fxDTSBrickData (brick1x9x9BrickData)
{
	brickFile = "./1x9x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x9x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9x3";
};

datablock fxDTSBrickData (brick1x11x9BrickData)
{
	brickFile = "./1x11x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x11x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11x3";
};

datablock fxDTSBrickData (brick1x13x9BrickData)
{
	brickFile = "./1x13x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x13x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13x3";
};

datablock fxDTSBrickData (brick1x14x9BrickData)
{
	brickFile = "./1x14x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x14x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14x3";
};

datablock fxDTSBrickData (brick1x15x9BrickData)
{
	brickFile = "./1x15x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x15x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15x3";
};

datablock fxDTSBrickData (brick2x5x9BrickData)
{
	brickFile = "./2x5x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x5x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5x3";
};

datablock fxDTSBrickData (brick2x7x9BrickData)
{
	brickFile = "./2x7x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x7x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7x3";
};

datablock fxDTSBrickData (brick2x9x9BrickData)
{
	brickFile = "./2x9x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x9x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9x3";
};

datablock fxDTSBrickData (brick2x11x9BrickData)
{
	brickFile = "./2x11x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x11x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11x3";
};

datablock fxDTSBrickData (brick2x13x9BrickData)
{
	brickFile = "./2x13x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x13x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13x3";
};

datablock fxDTSBrickData (brick2x14x9BrickData)
{
	brickFile = "./2x14x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x14x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14x3";
};

datablock fxDTSBrickData (brick2x15x9BrickData)
{
	brickFile = "./2x15x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x15x3";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15x3";
};

datablock fxDTSBrickData (brick1x5x15BrickData)
{
	brickFile = "./1x5x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x5x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5x5";
};

datablock fxDTSBrickData (brick1x7x15BrickData)
{
	brickFile = "./1x7x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x7x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7x5";
};

datablock fxDTSBrickData (brick1x9x15BrickData)
{
	brickFile = "./1x9x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x9x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9x5";
};

datablock fxDTSBrickData (brick1x11x15BrickData)
{
	brickFile = "./1x11x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x11x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11x5";
};

datablock fxDTSBrickData (brick1x13x15BrickData)
{
	brickFile = "./1x13x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x13x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13x5";
};

datablock fxDTSBrickData (brick1x14x15BrickData)
{
	brickFile = "./1x14x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x14x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14x5";
};

datablock fxDTSBrickData (brick1x15x15BrickData)
{
	brickFile = "./1x15x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "1x15x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15x5";
};

datablock fxDTSBrickData (brick2x5x15BrickData)
{
	brickFile = "./2x5x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x5x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5x5";
};

datablock fxDTSBrickData (brick2x7x15BrickData)
{
	brickFile = "./2x7x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x7x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7x5";
};

datablock fxDTSBrickData (brick2x9x15BrickData)
{
	brickFile = "./2x9x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x9x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9x5";
};

datablock fxDTSBrickData (brick2x11x15BrickData)
{
	brickFile = "./2x11x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x11x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11x5";
};

datablock fxDTSBrickData (brick2x13x15BrickData)
{
	brickFile = "./2x13x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x13x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13x5";
};

datablock fxDTSBrickData (brick2x14x15BrickData)
{
	brickFile = "./2x14x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x14x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14x5";
};

datablock fxDTSBrickData (brick2x15x15BrickData)
{
	brickFile = "./2x15x5.blb";
	category = "Bricks";
	subCategory = "5x Height";
	uiName = "2x15x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15x5";
};

datablock fxDTSBrickData (brick12x13x3BrickData)
{
	brickFile = "./12x13.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/12x13";
};

datablock fxDTSBrickData (brick12x14x3BrickData)
{
	brickFile = "./12x14.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/12x14";
};

datablock fxDTSBrickData (brick12x15x3BrickData)
{
	brickFile = "./12x15.blb";
	category = "Bricks";
	subCategory = "12x";
	uiName = "12x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/12x15";
};

datablock fxDTSBrickData (brick10x11x3BrickData)
{
	brickFile = "./10x11.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/10x11";
};

datablock fxDTSBrickData (brick10x13x3BrickData)
{
	brickFile = "./10x13.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/10x13";
};

datablock fxDTSBrickData (brick10x14x3BrickData)
{
	brickFile = "./10x14.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/10x14";
};

datablock fxDTSBrickData (brick10x15x3BrickData)
{
	brickFile = "./10x15.blb";
	category = "Bricks";
	subCategory = "10x";
	uiName = "10x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/10x15";
};

datablock fxDTSBrickData (brick8x9x3BrickData)
{
	brickFile = "./8x9.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x9";
};

datablock fxDTSBrickData (brick8x11x3BrickData)
{
	brickFile = "./8x11.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x11";
};

datablock fxDTSBrickData (brick8x13x3BrickData)
{
	brickFile = "./8x13.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x13";
};

datablock fxDTSBrickData (brick8x14x3BrickData)
{
	brickFile = "./8x14.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x14";
};

datablock fxDTSBrickData (brick8x15x3BrickData)
{
	brickFile = "./8x15.blb";
	category = "Bricks";
	subCategory = "8x";
	uiName = "8x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x15";
};

datablock fxDTSBrickData (brick6x7x3BrickData)
{
	brickFile = "./6x7.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x7";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x7";
};

datablock fxDTSBrickData (brick6x9x3BrickData)
{
	brickFile = "./6x9.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x9";
};

datablock fxDTSBrickData (brick6x11x3BrickData)
{
	brickFile = "./6x11.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x11";
};

datablock fxDTSBrickData (brick6x13x3BrickData)
{
	brickFile = "./6x13.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x13";
};

datablock fxDTSBrickData (brick6x14x3BrickData)
{
	brickFile = "./6x14.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x14";
};

datablock fxDTSBrickData (brick6x15x3BrickData)
{
	brickFile = "./6x15.blb";
	category = "Bricks";
	subCategory = "6x";
	uiName = "6x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x15";
};

datablock fxDTSBrickData (brick4x5x3BrickData)
{
	brickFile = "./4x5.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x5";
};

datablock fxDTSBrickData (brick4x7x3BrickData)
{
	brickFile = "./4x7.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x7";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x7";
};

datablock fxDTSBrickData (brick4x9x3BrickData)
{
	brickFile = "./4x9.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x9";
};

datablock fxDTSBrickData (brick4x11x3BrickData)
{
	brickFile = "./4x11.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x11";
};

datablock fxDTSBrickData (brick4x13x3BrickData)
{
	brickFile = "./4x13.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x13";
};

datablock fxDTSBrickData (brick4x14x3BrickData)
{
	brickFile = "./4x14.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x14";
};

datablock fxDTSBrickData (brick4x15x3BrickData)
{
	brickFile = "./4x15.blb";
	category = "Bricks";
	subCategory = "4x";
	uiName = "4x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x15";
};

datablock fxDTSBrickData (brick3x5x3BrickData)
{
	brickFile = "./3x5.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x5";
};

datablock fxDTSBrickData (brick3x7x3BrickData)
{
	brickFile = "./3x7.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x7";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x7";
};

datablock fxDTSBrickData (brick3x9x3BrickData)
{
	brickFile = "./3x9.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x9";
};

datablock fxDTSBrickData (brick3x11x3BrickData)
{
	brickFile = "./3x11.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x11";
};

datablock fxDTSBrickData (brick3x13x3BrickData)
{
	brickFile = "./3x13.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x13";
};

datablock fxDTSBrickData (brick3x14x3BrickData)
{
	brickFile = "./3x14.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x14";
};

datablock fxDTSBrickData (brick3x15x3BrickData)
{
	brickFile = "./3x15.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x15";
};

datablock fxDTSBrickData (brick2x5x3BrickData)
{
	brickFile = "./2x5.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5";
};

datablock fxDTSBrickData (brick2x7x3BrickData)
{
	brickFile = "./2x7.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x7";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7";
};

datablock fxDTSBrickData (brick2x9x3BrickData)
{
	brickFile = "./2x9.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9";
};

datablock fxDTSBrickData (brick2x11x3BrickData)
{
	brickFile = "./2x11.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11";
};

datablock fxDTSBrickData (brick2x13x3BrickData)
{
	brickFile = "./2x13.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13";
};

datablock fxDTSBrickData (brick2x14x3BrickData)
{
	brickFile = "./2x14.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14";
};

datablock fxDTSBrickData (brick2x15x3BrickData)
{
	brickFile = "./2x15.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15";
};

datablock fxDTSBrickData (brick1x5x3BrickData)
{
	brickFile = "./1x5.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x5";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5";
};

datablock fxDTSBrickData (brick1x7x3BrickData)
{
	brickFile = "./1x7.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x7";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7";
};

datablock fxDTSBrickData (brick1x9x3BrickData)
{
	brickFile = "./1x9.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x9";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9";
};

datablock fxDTSBrickData (brick1x11x3BrickData)
{
	brickFile = "./1x11.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x11";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11";
};

datablock fxDTSBrickData (brick1x13x3BrickData)
{
	brickFile = "./1x13.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x13";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13";
};

datablock fxDTSBrickData (brick1x14x3BrickData)
{
	brickFile = "./1x14.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x14";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14";
};

datablock fxDTSBrickData (brick1x15x3BrickData)
{
	brickFile = "./1x15.blb";
	category = "Bricks";
	subCategory = "1x";
	uiName = "1x15";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15";
};

datablock fxDTSBrickData (brick8x9x1BrickData)
{
	brickFile = "./8x9F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x9F";
};

datablock fxDTSBrickData (brick8x11x1BrickData)
{
	brickFile = "./8x11F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x11F";
};

datablock fxDTSBrickData (brick8x13x1BrickData)
{
	brickFile = "./8x13F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x13F";
};

datablock fxDTSBrickData (brick8x14x1BrickData)
{
	brickFile = "./8x14F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x14F";
};

datablock fxDTSBrickData (brick8x15x1BrickData)
{
	brickFile = "./8x15F.blb";
	category = "Plates";
	subCategory = "8x";
	uiName = "8x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/8x15F";
};

datablock fxDTSBrickData (brick6x7x1BrickData)
{
	brickFile = "./6x7F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x7F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x7F";
};

datablock fxDTSBrickData (brick6x9x1BrickData)
{
	brickFile = "./6x9F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x9F";
};

datablock fxDTSBrickData (brick6x11x1BrickData)
{
	brickFile = "./6x11F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x11F";
};

datablock fxDTSBrickData (brick6x13x1BrickData)
{
	brickFile = "./6x13F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x13F";
};

datablock fxDTSBrickData (brick6x14x1BrickData)
{
	brickFile = "./6x14F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x14F";
};

datablock fxDTSBrickData (brick6x15x1BrickData)
{
	brickFile = "./6x15F.blb";
	category = "Plates";
	subCategory = "6x";
	uiName = "6x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/6x15F";
};

datablock fxDTSBrickData (brick4x5x1BrickData)
{
	brickFile = "./4x5F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x5F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x5F";
};

datablock fxDTSBrickData (brick4x7x1BrickData)
{
	brickFile = "./4x7F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x7F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x7F";
};

datablock fxDTSBrickData (brick4x9x1BrickData)
{
	brickFile = "./4x9F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x9F";
};

datablock fxDTSBrickData (brick4x11x1BrickData)
{
	brickFile = "./4x11F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x11F";
};

datablock fxDTSBrickData (brick4x13x1BrickData)
{
	brickFile = "./4x13F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x13F";
};

datablock fxDTSBrickData (brick4x14x1BrickData)
{
	brickFile = "./4x14F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x14F";
};

datablock fxDTSBrickData (brick4x15x1BrickData)
{
	brickFile = "./4x15F.blb";
	category = "Plates";
	subCategory = "4x";
	uiName = "4x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/4x15F";
};

datablock fxDTSBrickData (brick3x5x1BrickData)
{
	brickFile = "./3x5F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x5F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x5F";
};

datablock fxDTSBrickData (brick3x7x1BrickData)
{
	brickFile = "./3x7F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x7F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x7F";
};

datablock fxDTSBrickData (brick3x9x1BrickData)
{
	brickFile = "./3x9F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x9F";
};

datablock fxDTSBrickData (brick3x11x1BrickData)
{
	brickFile = "./3x11F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x11F";
};

datablock fxDTSBrickData (brick3x13x1BrickData)
{
	brickFile = "./3x13F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x13F";
};

datablock fxDTSBrickData (brick3x14x1BrickData)
{
	brickFile = "./3x14F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x14F";
};

datablock fxDTSBrickData (brick3x15x1BrickData)
{
	brickFile = "./3x15F.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/3x15F";
};

datablock fxDTSBrickData (brick2x5x1BrickData)
{
	brickFile = "./2x5F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x5F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x5F";
};

datablock fxDTSBrickData (brick2x7x1BrickData)
{
	brickFile = "./2x7F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x7F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x7F";
};

datablock fxDTSBrickData (brick2x9x1BrickData)
{
	brickFile = "./2x9F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x9F";
};

datablock fxDTSBrickData (brick2x11x1BrickData)
{
	brickFile = "./2x11F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x11F";
};

datablock fxDTSBrickData (brick2x13x1BrickData)
{
	brickFile = "./2x13F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x13F";
};

datablock fxDTSBrickData (brick2x14x1BrickData)
{
	brickFile = "./2x14F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x14F";
};

datablock fxDTSBrickData (brick2x15x1BrickData)
{
	brickFile = "./2x15F.blb";
	category = "Plates";
	subCategory = "2x";
	uiName = "2x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/2x15F";
};

datablock fxDTSBrickData (brick1x5x1BrickData)
{
	brickFile = "./1x5F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x5F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x5F";
};

datablock fxDTSBrickData (brick1x7x1BrickData)
{
	brickFile = "./1x7F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x7F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x7F";
};

datablock fxDTSBrickData (brick1x9x1BrickData)
{
	brickFile = "./1x9F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x9F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x9F";
};

datablock fxDTSBrickData (brick1x11x1BrickData)
{
	brickFile = "./1x11F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x11F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x11F";
};

datablock fxDTSBrickData (brick1x13x1BrickData)
{
	brickFile = "./1x13F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x13F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x13F";
};

datablock fxDTSBrickData (brick1x14x1BrickData)
{
	brickFile = "./1x14F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x14F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x14F";
};

datablock fxDTSBrickData (brick1x15x1BrickData)
{
	brickFile = "./1x15F.blb";
	category = "Plates";
	subCategory = "1x";
	uiName = "1x15F";
	iconName = "Add-Ons/Brick_BlackDragonIV_Filler/1x15F";
};