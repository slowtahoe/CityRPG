datablock fxDTSBrickData(brickVendingMachineData)
{
	brickFile = "Add-Ons/Brick_VendingMachine/VendingMachine.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Vending Machine";
	iconName = "Add-ons/Brick_VendingMachine/VendingMachine";
};

datablock fxDTSBrickData(brickSodaMachineData)
{
	brickFile = "Add-Ons/Brick_VendingMachine/SodaMachine.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "Soda Machine";
	iconName = "Add-ons/Brick_VendingMachine/SodaMachine";
	
	hasPrint = 1;
	printAspectRatio = "2x2f";
};