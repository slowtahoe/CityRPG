datablock fxDTSBrickData(brick64x64AdvRoadStraightData)
{
	brickFile = "./64x64AdvRoadStraight.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Straight ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadStraight";
};

datablock fxDTSBrickData(brick64x64AdvRoadIntersectionData)
{
	brickFile = "./64x64AdvRoadIntersection.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Intersection ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadIntersection";
};

datablock fxDTSBrickData(brick64x64AdvRoadCrosswalkData)
{
	brickFile = "./64x64AdvRoadCrosswalk.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Crosswalk ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadCrosswalk";
};

datablock fxDTSBrickData(brick64x64AdvRoadBlankData)
{
	brickFile = "./64x64AdvRoadBlank.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Blank ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadBlank";
};

//Ramp
datablock fxDTSBrickData(brick64x64AdvRoadRampAData)
{
	brickFile = "./64x64AdvRoadRampA.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Ramp A ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadRampA";

	collisionShapeName = "./64x64AdvRoadRampA.dts";
};

datablock fxDTSBrickData(brick64x64AdvRoadRampBData)
{
	brickFile = "./64x64AdvRoadRampB.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Ramp B ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadRampB";

	collisionShapeName = "./64x64AdvRoadRampB.dts";
};

datablock fxDTSBrickData(brick64x64AdvRoadRampCData)
{
	brickFile = "./64x64AdvRoadRampC.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Ramp C ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadRampC";

	collisionShapeName = "./64x64AdvRoadRampC.dts";
};

datablock fxDTSBrickData(brick64x64AdvRoadRampDData)
{
	brickFile = "./64x64AdvRoadRampD.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Ramp D ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadRampD";

	collisionShapeName = "./64x64AdvRoadRampD.dts";
};

datablock fxDTSBrickData(brick64x64AdvRoadRampEData)
{
	brickFile = "./64x64AdvRoadRampE.blb";
	category = "Baseplates";
	subCategory = "Adv Roads";
	uiName = "64x Road Ramp E ";
	iconName = "Add-Ons/Brick_AdvancedRoads/64x64AdvRoadRampE";

	collisionShapeName = "./64x64AdvRoadRampE.dts";
};