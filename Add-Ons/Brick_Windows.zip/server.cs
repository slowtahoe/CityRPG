//Three new window bricks!!! All made by Slezak.

//Tinted Window, a mod of the window by Slezak. Window is tinted and less transparent
datablock fxDTSBrickData (brickTintedWindowdata)
{
	brickFile = "./4x1x5WindowT.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "Tinted Window";
	iconName = "base/client/ui/brickIcons/1x4x5 Window";
};

//Clean Window, a mod of the window by Slezak. Window is very clear, like just-cleaned glass.
datablock fxDTSBrickData (brickCleanWindowdata)
{
	brickFile = "./4x1x5WindowC.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "Clean Window";
	iconName = "base/client/ui/brickIcons/1x4x5 Window";
};

//One-Way Window, a mod of the window by Slezak. You can only see out the concave end.
datablock fxDTSBrickData (brickOneWayWindowdata)
{
	brickFile = "./4x1x5WindowO.blb";
	category = "Special";
	subCategory = "Windows";
	uiName = "One Way Window";
	iconName = "base/client/ui/brickIcons/1x4x5 Window";
};